import {
  UserAccessRecord,
  UserRole,
  MasterLetterTemplate,
  LetterHistoryRecord,
  ModuleActionPermission,
} from '../types/hrms';
import { INITIAL_EMPLOYEES } from './seedData';

export const MODULE_LIST: { id: string; label: string }[] = [
  { id: 'people', label: 'People & Directory' },
  { id: 'attendance', label: 'Attendance Management' },
  { id: 'leave', label: 'Leave Requests & Balances' },
  { id: 'payroll', label: 'Payroll & Compensation' },
  { id: 'company-info', label: 'Company Settings & Rules' },
  { id: 'departments-mgmt', label: 'Department Management' },
  { id: 'org-tree', label: 'Organization Tree' },
  { id: 'considerations', label: 'Considerations & Waivers' },
  { id: 'documents', label: 'Document Vault & Letters' },
  { id: 'reports', label: 'Reports & Analytics' },
  { id: 'calendar', label: 'Calendar & Shifts' },
];

export const getDefaultPermissionsForRole = (
  role: UserRole,
  level: 'Viewer' | 'Controller'
): Record<string, ModuleActionPermission> => {
  const result: Record<string, ModuleActionPermission> = {};

  MODULE_LIST.forEach((m) => {
    if (role === UserRole.ADMIN) {
      result[m.id] = {
        view: true,
        create: true,
        edit: true,
        approve: true,
        delete: true,
        export: true,
      };
    } else if (role === UserRole.HR) {
      const isSensitiveAdminOnly = m.id === 'manage-access';
      result[m.id] = {
        view: true,
        create: level === 'Controller' && !isSensitiveAdminOnly,
        edit: level === 'Controller' && !isSensitiveAdminOnly,
        approve: level === 'Controller' && !isSensitiveAdminOnly,
        delete: false,
        export: true,
      };
    } else if (role === UserRole.MANAGER) {
      const isManagerOperational = ['attendance', 'leave', 'considerations', 'org-tree', 'people'].includes(m.id);
      result[m.id] = {
        view: true,
        create: isManagerOperational && level === 'Controller',
        edit: isManagerOperational && level === 'Controller',
        approve: isManagerOperational && level === 'Controller',
        delete: false,
        export: ['attendance', 'leave', 'reports'].includes(m.id),
      };
    } else {
      // EMPLOYEE
      result[m.id] = {
        view: ['attendance', 'leave', 'considerations', 'documents', 'company-info', 'calendar', 'org-tree'].includes(m.id),
        create: ['leave', 'considerations'].includes(m.id) && level === 'Controller',
        edit: false,
        approve: false,
        delete: false,
        export: ['attendance', 'documents'].includes(m.id),
      };
    }
  });

  return result;
};

export const INITIAL_USER_ACCESS: UserAccessRecord[] = INITIAL_EMPLOYEES.map((emp) => {
  const isSuperAdmin = emp.id === 'EMP-1001';
  const role = isSuperAdmin ? UserRole.ADMIN : emp.role;
  const accessLevel = role === UserRole.ADMIN || role === UserRole.HR || role === UserRole.MANAGER ? 'Controller' : 'Viewer';

  return {
    employeeId: emp.id,
    fullName: emp.fullName,
    email: emp.email,
    role,
    accessLevel,
    accountStatus: 'Active',
    department: emp.department,
    designation: emp.designation,
    managerId: emp.managerId,
    managerName: emp.managerName,
    lastLogin: '2026-10-06 09:30 AM',
    invitationStatus: 'Accepted',
    modulePermissions: getDefaultPermissionsForRole(role, accessLevel),
    updatedAt: '2026-10-01 10:00:00',
    updatedBy: 'System SuperAdmin',
    adminNote: isSuperAdmin ? 'Primary Argos Enterprise Super Administrator' : 'Standard onboarding assignment',
  };
});

export const INITIAL_MASTER_LETTER_TEMPLATES: MasterLetterTemplate[] = [
  {
    id: 'TMPL-01',
    title: 'Executive Offer Letter',
    type: 'Offer',
    subject: 'Official Offer of Employment — {{companyName}}',
    bodyTemplate: `Date: {{date}}
Reference: ARG/HR/OFR/{{year}}/{{sequence}}

To,
{{fullName}}
{{address}}

Dear {{firstName}},

We are pleased to offer you the position of {{designation}} in the {{department}} Department at {{companyName}} ({{legalEntityName}}).

1. APPOINTMENT & COMMENCEMENT
Your joining date will be {{joiningDate}}. You will report to {{reportingManager}}.

2. COMPENSATION & BENEFITS
Your gross annual compensation will be {{currencySymbol}}{{annualCTC}} ({{currencySymbol}}{{grossMonthly}} per month), subject to standard statutory withholdings.

3. PROBATION & CONFIRMATION
You will be placed on a probation period of {{probationDurationMonths}} months starting {{joiningDate}} and expected to conclude on {{probationEndDate}}. Upon successful performance review, permanent confirmation will be issued.

Welcome to the Argos Watch Family.

Sincerely,
{{issuerName}}
{{issuerDesignation}}
{{companyName}}`,
    placeholders: [
      '{{fullName}}',
      '{{firstName}}',
      '{{designation}}',
      '{{department}}',
      '{{companyName}}',
      '{{legalEntityName}}',
      '{{joiningDate}}',
      '{{reportingManager}}',
      '{{annualCTC}}',
      '{{grossMonthly}}',
      '{{probationDurationMonths}}',
      '{{probationEndDate}}',
      '{{date}}',
    ],
    version: 1,
    status: 'Active',
    createdBy: 'Chaitanya Katare',
    updatedAt: '2026-10-01',
  },
  {
    id: 'TMPL-02',
    title: 'Horological Apprenticeship & Internship Letter',
    type: 'Internship',
    subject: 'Internship Engagement Letter — {{companyName}}',
    bodyTemplate: `Date: {{date}}
Ref: ARG/INT/{{year}}/{{sequence}}

To,
{{fullName}}

Dear {{firstName}},

We are pleased to confirm your Internship Engagement as {{designation}} in the {{department}} Department at {{companyName}} starting from {{joiningDate}} until {{internshipEndDate}}.

Your assigned industry mentor will be {{reportingManager}}. You will receive a monthly stipend of {{currencySymbol}}{{stipendAmount}}.

Warm regards,
{{issuerName}}
{{issuerDesignation}}
{{companyName}}`,
    placeholders: [
      '{{fullName}}',
      '{{firstName}}',
      '{{designation}}',
      '{{department}}',
      '{{joiningDate}}',
      '{{internshipEndDate}}',
      '{{reportingManager}}',
      '{{stipendAmount}}',
      '{{date}}',
    ],
    version: 1,
    status: 'Active',
    createdBy: 'Chaitanya Katare',
    updatedAt: '2026-10-01',
  },
  {
    id: 'TMPL-03',
    title: 'Probation Confirmation & Permanent Employment Letter',
    type: 'Confirmation',
    subject: 'Confirmation of Employment — {{companyName}}',
    bodyTemplate: `Date: {{date}}
Ref: ARG/CONF/{{year}}/{{sequence}}

To,
{{fullName}}
Employee ID: {{employeeId}}
{{designation}} · {{department}}

Dear {{firstName}},

Consequent to the successful completion of your probation period and recommendation from {{reportingManager}}, we take great pleasure in confirming your appointment as a Permanent Employee of {{companyName}}, effective {{confirmationDate}}.

All other terms and conditions of your employment contract remain unchanged.

Congratulations and best wishes for continued success.

Warm regards,
{{issuerName}}
{{issuerDesignation}}
{{companyName}}`,
    placeholders: [
      '{{fullName}}',
      '{{firstName}}',
      '{{employeeId}}',
      '{{designation}}',
      '{{department}}',
      '{{reportingManager}}',
      '{{confirmationDate}}',
      '{{date}}',
    ],
    version: 1,
    status: 'Active',
    createdBy: 'Chaitanya Katare',
    updatedAt: '2026-10-01',
  },
  {
    id: 'TMPL-04',
    title: 'Standard Experience & Relieving Certificate',
    type: 'Experience',
    subject: 'Experience & Relieving Certificate — {{fullName}}',
    bodyTemplate: `Date: {{date}}
TO WHOMSOEVER IT MAY CONCERN

This is to certify that {{fullName}} (Employee ID: {{employeeId}}) was employed with {{companyName}} from {{joiningDate}} to {{relievingDate}}.

During this tenure, {{firstName}} served as {{designation}} in the {{department}} Department. {{firstName}} demonstrated exemplary dedication, technical craftsmanship, and professionalism.

We relieve {{fullName}} of all official duties and wish them every success in their future endeavors.

Authorized Signatory,
{{issuerName}}
{{issuerDesignation}}
{{companyName}}`,
    placeholders: [
      '{{fullName}}',
      '{{firstName}}',
      '{{employeeId}}',
      '{{designation}}',
      '{{department}}',
      '{{joiningDate}}',
      '{{relievingDate}}',
      '{{date}}',
    ],
    version: 1,
    status: 'Active',
    createdBy: 'Chaitanya Katare',
    updatedAt: '2026-10-01',
  },
  {
    id: 'TMPL-05',
    title: 'Official Termination & Separation Notice',
    type: 'Termination',
    subject: 'Formal Separation Notice — {{companyName}}',
    bodyTemplate: `Date: {{date}}
STRICTLY CONFIDENTIAL

To,
{{fullName}}
Employee ID: {{employeeId}}
{{designation}} · {{department}}

Dear {{firstName}},

This letter serves as formal notification that your employment with {{companyName}} will terminate on {{terminationEffectiveDate}} in accordance with the terms of your contract.

Please ensure all company assets, intellectual property, movement components, and keys are surrendered to HR before your final day. Full and final settlement will be disbursed pursuant to company guidelines.

Sincerely,
{{issuerName}}
{{issuerDesignation}}
{{companyName}}`,
    placeholders: [
      '{{fullName}}',
      '{{firstName}}',
      '{{employeeId}}',
      '{{designation}}',
      '{{department}}',
      '{{terminationEffectiveDate}}',
      '{{date}}',
    ],
    version: 1,
    status: 'Active',
    createdBy: 'Chaitanya Katare',
    updatedAt: '2026-10-01',
  },
];

export const INITIAL_LETTER_HISTORY: LetterHistoryRecord[] = [
  {
    id: 'LH-2026-001',
    employeeId: 'EMP-1005',
    employeeName: 'Aliasger Channiwala',
    letterType: 'Offer',
    templateName: 'Executive Offer Letter',
    templateVersion: 1,
    content: 'Official Offer of Employment issued on onboarding. Gross compensation ₹35,000/mo.',
    generatedBy: 'EMP-1001',
    generatedByName: 'Chaitanya Katare',
    generatedAt: '2023-08-10 11:30 AM',
    sentBy: 'EMP-1001',
    sentByName: 'Chaitanya Katare',
    sentAt: '2023-08-10 11:35 AM',
    deliveryStatus: 'Delivered',
    exportCount: 2,
    lastExportedAt: '2026-09-12 04:10 PM',
    status: 'Active',
  },
  {
    id: 'LH-2026-002',
    employeeId: 'EMP-1006',
    employeeName: 'Mayur Israni',
    letterType: 'Confirmation',
    templateName: 'Probation Confirmation & Permanent Employment Letter',
    templateVersion: 1,
    content: 'Successful probation completion. Permanent employment status confirmed.',
    generatedBy: 'EMP-1001',
    generatedByName: 'Chaitanya Katare',
    generatedAt: '2024-02-15 03:00 PM',
    sentBy: 'EMP-1001',
    sentByName: 'Chaitanya Katare',
    sentAt: '2024-02-15 03:05 PM',
    deliveryStatus: 'Delivered',
    exportCount: 1,
    lastExportedAt: '2024-02-15 03:00 PM',
    status: 'Active',
  },
  {
    id: 'LH-2026-003',
    employeeId: 'EMP-1007',
    employeeName: 'Kavita Lelinwala',
    letterType: 'Offer',
    templateName: 'Executive Offer Letter',
    templateVersion: 1,
    content: 'Official Offer of Employment issued on joining. Gross compensation ₹32,000/mo.',
    generatedBy: 'EMP-1001',
    generatedByName: 'Chaitanya Katare',
    generatedAt: '2024-04-12 10:15 AM',
    sentBy: 'EMP-1001',
    sentByName: 'Chaitanya Katare',
    sentAt: '2024-04-12 10:20 AM',
    deliveryStatus: 'Delivered',
    exportCount: 3,
    lastExportedAt: '2026-08-01 02:45 PM',
    status: 'Active',
  },
];
