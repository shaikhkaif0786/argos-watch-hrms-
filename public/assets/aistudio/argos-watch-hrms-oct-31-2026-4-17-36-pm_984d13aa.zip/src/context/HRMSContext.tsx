import React, { createContext, useContext, useState, useEffect, useMemo } from 'react';
import {
  signInWithPopup,
  signOut as firebaseSignOut,
  onAuthStateChanged,
  User as FirebaseUser,
} from 'firebase/auth';
import {
  doc,
  setDoc,
  serverTimestamp,
} from 'firebase/firestore';
import {
  auth,
  db,
  googleProvider,
  handleFirestoreError,
  OperationType,
} from '../lib/firebase';
import {
  UserRole,
  PrimaryModuleId,
  MoreSubModuleId,
  Employee,
  Department,
  AttendanceRecord,
  LeaveRequest,
  ConsiderationRequest,
  PayrollRecord,
  CompanyPolicy,
  Announcement,
  EmployeeDocument,
  GeneratedLetter,
  InternshipRecord,
  HolidayRecord,
  NotificationItem,
  ActivityLogEntry,
  CompanySettings,
  CustomCompanyRule,
  UserAccessRecord,
  MasterLetterTemplate,
  LetterHistoryRecord,
  ModuleActionPermission,
  NoticePeriodDetails,
  FinalExitDetails,
  PunchEvent,
  PunchSource,
} from '../types/hrms';
import {
  getNormalizedPunchesForRecord,
  calculateLateDeduction,
} from '../lib/attendanceCalculations';
import {
  INITIAL_USER_ACCESS,
  INITIAL_MASTER_LETTER_TEMPLATES,
  INITIAL_LETTER_HISTORY,
  getDefaultPermissionsForRole,
} from '../data/accessAndOrgData';
import { SupportedLanguage, getTranslation } from '../lib/i18n';
import {
  TODAY_DATE,
  INITIAL_COMPANY_SETTINGS,
  INITIAL_DEPARTMENTS,
  INITIAL_EMPLOYEES,
  INITIAL_ATTENDANCE,
  INITIAL_LEAVES,
  INITIAL_CONSIDERATIONS,
  INITIAL_PAYROLLS,
  INITIAL_POLICIES,
  INITIAL_ANNOUNCEMENTS,
  INITIAL_DOCUMENTS,
  INITIAL_LETTERS,
  INITIAL_INTERNSHIPS,
  INITIAL_HOLIDAYS,
  INITIAL_NOTIFICATIONS,
  INITIAL_ACTIVITY_LOGS,
} from '../data/seedData';
import {
  isAssignedTeamMember,
  scopeEmployees,
  scopeAttendance,
  scopeLeaves,
  scopeConsiderations,
  scopePayrolls,
  scopeDocuments,
  scopeLetters,
  scopePolicies,
  scopeAnnouncements,
  scopeActivityLogs,
} from '../lib/rbac';

export interface ToastMessage {
  id: string;
  title: string;
  description?: string;
  type: 'success' | 'error' | 'info';
}

export interface ReportFilterPreset {
  reportType?: string;
  department?: string;
  status?: string;
}

interface HRMSContextValue {
  // Auth & Role Persona State
  firebaseUser: FirebaseUser | null;
  authLoading: boolean;
  currentRole: UserRole;
  currentEmployee: Employee;
  switchRolePersona: (role: UserRole) => void;
  switchEmployeePersona: (employeeId: string) => void;
  signInWithGoogle: () => Promise<void>;
  signOutUser: () => Promise<void>;

  // Navigation State
  activeModule: PrimaryModuleId;
  activeSubModule: MoreSubModuleId | null;
  selectedEmployeeId: string | null;
  reportPreset: ReportFilterPreset | null;
  navigateTo: (
    module: PrimaryModuleId,
    subModule?: MoreSubModuleId | null,
    employeeId?: string | null,
    preset?: ReportFilterPreset | null
  ) => void;
  openEmployeeProfile: (employeeId: string) => void;

  // Raw & Role-Scoped Data
  allEmployees: Employee[];
  scopedEmployees: Employee[];
  departments: Department[];
  scopedAttendance: AttendanceRecord[];
  scopedLeaves: LeaveRequest[];
  scopedConsiderations: ConsiderationRequest[];
  scopedPayrolls: PayrollRecord[];
  scopedDocuments: EmployeeDocument[];
  scopedLetters: GeneratedLetter[];
  scopedPolicies: CompanyPolicy[];
  scopedAnnouncements: Announcement[];
  internships: InternshipRecord[];
  holidays: HolidayRecord[];
  notifications: NotificationItem[];
  scopedActivityLogs: ActivityLogEntry[];
  settings: CompanySettings;
  companySettings: CompanySettings;

  // Smart Workflows & Actions
  checkInToday: (notes?: string) => void;
  checkOutToday: () => void;
  logOrUpdateAttendanceForEmployee: (payload: {
    employeeId: string;
    date: string;
    checkIn?: string;
    checkOut?: string | null;
    punchIn?: string | null;
    punchOut?: string | null;
    status: AttendanceRecord['status'];
    lateByMinutes?: number;
    notes: string;
    [key: string]: any;
  }) => void;
  logManualAttendance: (payload: {
    employeeId: string;
    date: string;
    punchIn?: string | null;
    punchOut?: string | null;
    status: AttendanceRecord['status'];
    reason: string;
    notes?: string;
    lateByMinutes?: number;
  }) => void;
  archiveEmployee: (employeeId: string, reasonNote?: string) => void;
  deactivateEmployee: (employeeId: string, reason?: string) => void;
  initiateFinalExit: (
    employeeIdOrData: string | FinalExitDetails,
    exitData?: FinalExitDetails
  ) => void;
  updateNoticePeriod: (employeeId: string, noticeData: NoticePeriodDetails) => void;
  addNewEmployee: (
    newEmp: Omit<Employee, 'id' | 'uid' | 'managerUid' | 'salaryHistory' | 'leaveBalance'>,
    generateOffer: boolean
  ) => Employee;
  updateEmployeeStatus: (employeeId: string, status: Employee['status']) => void;
  applyLeave: (payload: {
    targetEmployeeId?: string;
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    days: number;
    isHalfDay: boolean;
    halfDaySession?: LeaveRequest['halfDaySession'];
    reason: string;
    autoApprove?: boolean;
  }) => void;
  decideLeave: (leaveId: string, status: 'Approved' | 'Rejected', decisionNote: string) => void;
  submitConsideration: (payload: {
    employeeId: string;
    date: string;
    type: ConsiderationRequest['type'];
    customType?: string;
    title?: string;
    category?: string;
    reason: string;
    supportingNote?: string;
    supportingDocument: string;
    forwardToHRImmediately?: boolean;
  }) => void;
  decideConsideration: (
    considerationId: string,
    status: 'Approved' | 'Rejected',
    decisionNote: string,
    options?: {
      affectsAttendancePenalty?: boolean;
      affectsSalaryDeduction?: boolean;
    }
  ) => void;
  acknowledgePolicy: (policyId: string) => void;
  createOrUpdatePolicy: (
    policy: Omit<CompanyPolicy, 'id' | 'versions' | 'acknowledgements'>,
    existingId?: string
  ) => void;
  createAnnouncement: (ann: any) => void;
  generateAndSaveLetter: (payload: {
    employeeId: string;
    templateType: GeneratedLetter['templateType'];
    subject: string;
    content: string;
  }) => GeneratedLetter;
  uploadEmployeeDocument: (payload: {
    employeeId: string;
    title: string;
    category: EmployeeDocument['category'];
    fileName: string;
    fileSize: string;
    expiryDate?: string;
  }) => void;
  deleteEmployeeDocument: (docId: string) => void;
  addHoliday: (holiday: Omit<HolidayRecord, 'id'>) => void;
  updateHoliday: (id: string, holiday: Omit<HolidayRecord, 'id'>) => void;
  deleteHoliday: (id: string) => void;
  addOrUpdateCustomRule: (
    rule: Omit<CustomCompanyRule, 'id' | 'updatedBy'>,
    existingId?: string
  ) => void;
  deleteCustomRule: (ruleId: string) => void;
  addDepartment: (dept: Omit<Department, 'id'>) => void;
  updateDepartment: (deptId: string, updates: Partial<Department>) => void;
  deleteDepartmentSafely: (deptId: string) => { success: boolean; message: string };
  reassignDepartmentEmployees: (fromDeptName: string, toDeptName: string) => void;
  confirmEmployeeProbation: (employeeId: string, note?: string) => void;
  userAccessList: UserAccessRecord[];
  updateUserAccess: (employeeId: string, updates: Partial<UserAccessRecord>, reasonNote?: string) => void;
  revokeUserAccess: (employeeId: string, reasonNote?: string) => void;
  masterLetterTemplates: MasterLetterTemplate[];
  letterHistory: LetterHistoryRecord[];
  createLetterTemplate: (template: Omit<MasterLetterTemplate, 'id' | 'version' | 'updatedAt'>) => void;
  updateLetterTemplate: (id: string, updates: Partial<MasterLetterTemplate>) => void;
  deleteLetterTemplate: (id: string) => void;
  recordLetterHistory: (record: Omit<LetterHistoryRecord, 'id' | 'generatedAt' | 'exportCount'>) => void;
  incrementLetterExportCount: (id: string) => void;
  addInternship: (intern: any) => void;
  processMonthlyPayroll: (payrollId?: string) => void;
  updateCompanySettings: (newSettings: Partial<CompanySettings>) => void;
  markAllNotificationsRead: () => void;
  markNotificationRead: (id: string) => void;

  // UI Feedback
  toasts: ToastMessage[];
  addToast: (title: string, description?: string, type?: 'success' | 'error' | 'info') => void;
  dismissToast: (id: string) => void;

  // Apple Design System: Theme & I18n
  theme: 'light' | 'dark' | 'system';
  setTheme: (theme: 'light' | 'dark' | 'system') => void;
  language: SupportedLanguage;
  setLanguage: (lang: SupportedLanguage) => void;
  t: (key: string, fallback?: string) => string;

  // App Lock & Security
  appLockEnabled: boolean;
  isAppLocked: boolean;
  lockTimeoutMinutes: number;
  setLockTimeoutMinutes: (mins: number) => void;
  setAppLockEnabled: (enabled: boolean, pin?: string) => Promise<boolean>;
  changeAppLockPin: (currentPin: string, newPin: string) => Promise<{ success: boolean; error?: string }>;
  unlockApp: (pin: string) => Promise<boolean>;
  lockAppNow: () => void;
  resetAppLockWithIdentity: (ver: { email: string; employeeId: string; newPin: string }) => Promise<{ success: boolean; error?: string }>;

  // Normalized Module Adapter Properties
  [key: string]: any;
}

const HRMSContext = createContext<HRMSContextValue | undefined>(undefined);

const ROLE_TO_PERSONA_EMP_ID: Record<UserRole, string> = {
  [UserRole.ADMIN]: 'EMP-1001', // Chaitanya Katare (Admin / HR Head)
  [UserRole.HR]: 'EMP-1001', // Chaitanya Katare (Head of People : Performance & Culture)
  [UserRole.MANAGER]: 'EMP-1003', // Sohail Derolwala (Head of Operations & Development)
  [UserRole.EMPLOYEE]: 'EMP-1005', // Aliasger Channiwala (Inventory Coordinator)
};

export const HRMSProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [firebaseUser, setFirebaseUser] = useState<FirebaseUser | null>(null);
  const [authLoading, setAuthLoading] = useState<boolean>(true);
  const [currentRole, setCurrentRole] = useState<UserRole>(UserRole.HR);
  const [personaEmpId, setPersonaEmpId] = useState<string>('EMP-1001');

  // Navigation State
  const [activeModule, setActiveModule] = useState<PrimaryModuleId>('dashboard');
  const [activeSubModule, setActiveSubModule] = useState<MoreSubModuleId | null>(null);
  const [selectedEmployeeId, setSelectedEmployeeId] = useState<string | null>(null);
  const [reportPreset, setReportPreset] = useState<ReportFilterPreset | null>(null);

  // Helper for safe localStorage reading
  const readCached = <T,>(key: string, fallback: T): T => {
    try {
      const stored = localStorage.getItem(key);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(fallback)) {
          if (Array.isArray(parsed) && parsed.length > 0) return parsed as unknown as T;
        } else if (parsed && typeof parsed === 'object') {
          return { ...fallback, ...parsed } as T;
        }
      }
    } catch (err) {
      console.warn(`Failed reading ${key} from storage:`, err);
    }
    return fallback;
  };

  // Domain State (Persisted across refreshes)
  const [allEmployees, setAllEmployees] = useState<Employee[]>(() =>
    readCached('hrms_persisted_employees', INITIAL_EMPLOYEES)
  );
  const [departments, setDepartments] = useState<Department[]>(() =>
    readCached('hrms_persisted_departments', INITIAL_DEPARTMENTS)
  );
  const [attendance, setAttendance] = useState<AttendanceRecord[]>(() =>
    readCached('hrms_persisted_attendance', INITIAL_ATTENDANCE)
  );
  const [leaves, setLeaves] = useState<LeaveRequest[]>(() =>
    readCached('hrms_persisted_leaves', INITIAL_LEAVES)
  );
  const [considerations, setConsiderations] = useState<ConsiderationRequest[]>(() =>
    readCached('hrms_persisted_considerations', INITIAL_CONSIDERATIONS)
  );
  const [payrolls, setPayrolls] = useState<PayrollRecord[]>(() =>
    readCached('hrms_persisted_payrolls', INITIAL_PAYROLLS)
  );
  const [policies, setPolicies] = useState<CompanyPolicy[]>(() =>
    readCached('hrms_persisted_policies', INITIAL_POLICIES)
  );
  const [announcements, setAnnouncements] = useState<Announcement[]>(() =>
    readCached('hrms_persisted_announcements', INITIAL_ANNOUNCEMENTS)
  );
  const [documents, setDocuments] = useState<EmployeeDocument[]>(() =>
    readCached('hrms_persisted_documents', INITIAL_DOCUMENTS)
  );
  const [letters, setLetters] = useState<GeneratedLetter[]>(() =>
    readCached('hrms_persisted_letters', INITIAL_LETTERS)
  );
  const [internships, setInternships] = useState<InternshipRecord[]>(() =>
    readCached('hrms_persisted_internships', INITIAL_INTERNSHIPS)
  );
  const [holidays, setHolidays] = useState<HolidayRecord[]>(() =>
    readCached('hrms_persisted_holidays', INITIAL_HOLIDAYS)
  );
  const [notifications, setNotifications] = useState<NotificationItem[]>(() =>
    readCached('hrms_persisted_notifications', INITIAL_NOTIFICATIONS)
  );
  const [activityLogs, setActivityLogs] = useState<ActivityLogEntry[]>(() =>
    readCached('hrms_persisted_activity_logs', INITIAL_ACTIVITY_LOGS)
  );
  const [settings, setSettings] = useState<CompanySettings>(() =>
    readCached('hrms_persisted_settings', INITIAL_COMPANY_SETTINGS)
  );
  const [userAccessList, setUserAccessList] = useState<UserAccessRecord[]>(() =>
    readCached('hrms_persisted_user_access', INITIAL_USER_ACCESS)
  );
  const [masterLetterTemplates, setMasterLetterTemplates] = useState<MasterLetterTemplate[]>(() =>
    readCached('hrms_persisted_letter_templates', INITIAL_MASTER_LETTER_TEMPLATES)
  );
  const [letterHistory, setLetterHistory] = useState<LetterHistoryRecord[]>(() =>
    readCached('hrms_persisted_letter_history', INITIAL_LETTER_HISTORY)
  );
  const [toasts, setToasts] = useState<ToastMessage[]>([]);

  // Persistent storage sync effects
  useEffect(() => {
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(allEmployees));
  }, [allEmployees]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_attendance', JSON.stringify(attendance));
  }, [attendance]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_leaves', JSON.stringify(leaves));
  }, [leaves]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_considerations', JSON.stringify(considerations));
  }, [considerations]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_activity_logs', JSON.stringify(activityLogs));
  }, [activityLogs]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_departments', JSON.stringify(departments));
  }, [departments]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_settings', JSON.stringify(settings));
  }, [settings]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_holidays', JSON.stringify(holidays));
  }, [holidays]);

  useEffect(() => {
    localStorage.setItem('hrms_persisted_policies', JSON.stringify(policies));
  }, [policies]);

  const addToast = (
    title: string,
    description?: string,
    type: 'success' | 'error' | 'info' = 'success'
  ) => {
    const id = `toast-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    setToasts((prev) => [...prev, { id, title, description, type }]);
    setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
    }, 4000);
  };

  const dismissToast = (id: string) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  };

  // Apple Design System: Theme State & Persistence
  const [theme, setThemeState] = useState<'light' | 'dark' | 'system'>(() => {
    return (localStorage.getItem('argos_theme_mode') as 'light' | 'dark' | 'system') || 'light';
  });

  const setTheme = (newTheme: 'light' | 'dark' | 'system') => {
    setThemeState(newTheme);
    localStorage.setItem('argos_theme_mode', newTheme);
  };

  useEffect(() => {
    const applyTheme = () => {
      const isDark =
        theme === 'dark' ||
        (theme === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);
      if (isDark) {
        document.documentElement.classList.add('dark');
      } else {
        document.documentElement.classList.remove('dark');
      }
    };
    applyTheme();

    if (theme === 'system') {
      const media = window.matchMedia('(prefers-color-scheme: dark)');
      const listener = () => applyTheme();
      media.addEventListener('change', listener);
      return () => media.removeEventListener('change', listener);
    }
  }, [theme]);

  // Centralized Language State & Translation Helper
  const [language, setLanguageState] = useState<SupportedLanguage>(() => {
    return (localStorage.getItem('argos_language') as SupportedLanguage) || 'en';
  });

  const setLanguage = (lang: SupportedLanguage) => {
    setLanguageState(lang);
    localStorage.setItem('argos_language', lang);
  };

  const t = (key: string, fallback?: string): string => {
    return getTranslation(language, key, fallback);
  };

  // App Lock & Security State
  const [appLockEnabled, setAppLockEnabledState] = useState<boolean>(() => {
    return localStorage.getItem('argos_app_lock_enabled') === 'true';
  });
  const [isAppLocked, setIsAppLocked] = useState<boolean>(false);
  const [lockTimeoutMinutes, setLockTimeoutMinutesState] = useState<number>(() => {
    return Number(localStorage.getItem('argos_app_lock_timeout')) || 5;
  });

  const setLockTimeoutMinutes = (mins: number) => {
    setLockTimeoutMinutesState(mins);
    localStorage.setItem('argos_app_lock_timeout', String(mins));
  };

  const hashPin = async (pin: string): Promise<string> => {
    const enc = new TextEncoder();
    const data = enc.encode('argos_vault_salt_2026_' + pin);
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);
    return Array.from(new Uint8Array(hashBuffer))
      .map((b) => b.toString(16).padStart(2, '0'))
      .join('');
  };

  const setAppLockEnabled = async (enabled: boolean, pin?: string): Promise<boolean> => {
    if (enabled) {
      if (!pin || pin.length < 4) return false;
      const hashed = await hashPin(pin);
      localStorage.setItem('argos_app_lock_pin_hash', hashed);
      localStorage.setItem('argos_app_lock_enabled', 'true');
      setAppLockEnabledState(true);
      addToast('App Lock Enabled', 'Your 4-digit passcode has been set securely.', 'success');
      return true;
    } else {
      localStorage.removeItem('argos_app_lock_pin_hash');
      localStorage.setItem('argos_app_lock_enabled', 'false');
      setAppLockEnabledState(false);
      setIsAppLocked(false);
      addToast('App Lock Disabled', 'Passcode lock has been turned off.', 'info');
      return true;
    }
  };

  const changeAppLockPin = async (
    currentPin: string,
    newPin: string
  ): Promise<{ success: boolean; error?: string }> => {
    const savedHash = localStorage.getItem('argos_app_lock_pin_hash');
    if (!savedHash) {
      return { success: false, error: 'App lock is not enabled.' };
    }
    const currentHash = await hashPin(currentPin);
    if (currentHash !== savedHash) {
      return { success: false, error: 'Incorrect current passcode.' };
    }
    if (!newPin || newPin.length < 4) {
      return { success: false, error: 'New passcode must be at least 4 digits.' };
    }
    const newHash = await hashPin(newPin);
    localStorage.setItem('argos_app_lock_pin_hash', newHash);
    addToast('Passcode Changed', 'Your new passcode is now active.', 'success');
    return { success: true };
  };

  const unlockApp = async (pin: string): Promise<boolean> => {
    const savedHash = localStorage.getItem('argos_app_lock_pin_hash');
    if (!savedHash) {
      setIsAppLocked(false);
      return true;
    }
    const enteredHash = await hashPin(pin);
    if (enteredHash === savedHash) {
      setIsAppLocked(false);
      addToast('Application Unlocked', 'Welcome back.', 'success');
      return true;
    }
    return false;
  };

  const lockAppNow = () => {
    if (appLockEnabled) {
      setIsAppLocked(true);
    }
  };

  const resetAppLockWithIdentity = async (ver: {
    email: string;
    employeeId: string;
    newPin: string;
  }): Promise<{ success: boolean; error?: string }> => {
    const emp = allEmployees.find(
      (e) =>
        e.id.toLowerCase() === ver.employeeId.trim().toLowerCase() &&
        (e.email.toLowerCase() === ver.email.trim().toLowerCase() ||
          (e.officialEmail && e.officialEmail.toLowerCase() === ver.email.trim().toLowerCase()))
    );
    if (!emp) {
      return {
        success: false,
        error:
          'Verification failed: Employee ID and Official Email do not match active enterprise records.',
      };
    }
    if (!ver.newPin || ver.newPin.length < 4) {
      return { success: false, error: 'New passcode must be at least 4 digits.' };
    }
    const newHash = await hashPin(ver.newPin);
    localStorage.setItem('argos_app_lock_pin_hash', newHash);
    localStorage.setItem('argos_app_lock_enabled', 'true');
    setAppLockEnabledState(true);
    setIsAppLocked(false);
    addToast(
      'Passcode Reset Successful',
      'Your identity was verified and new passcode applied.',
      'success'
    );
    return { success: true };
  };

  // Inactivity auto-lock listener
  useEffect(() => {
    if (!appLockEnabled || isAppLocked) return;

    let timeoutId: any;
    const resetTimer = () => {
      clearTimeout(timeoutId);
      timeoutId = setTimeout(() => {
        setIsAppLocked(true);
      }, lockTimeoutMinutes * 60 * 1000);
    };

    const events = ['mousemove', 'keydown', 'click', 'scroll', 'touchstart'];
    events.forEach((ev) => window.addEventListener(ev, resetTimer));
    resetTimer();

    return () => {
      clearTimeout(timeoutId);
      events.forEach((ev) => window.removeEventListener(ev, resetTimer));
    };
  }, [appLockEnabled, isAppLocked, lockTimeoutMinutes]);

  // Sync Firebase Auth & Bootstrap User Profile in Firestore
  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (user) => {
      setFirebaseUser(user);
      setAuthLoading(false);
      if (user && user.emailVerified) {
        const isOwnerAdmin =
          user.email === 'shaikhkaif@carterfarrago.com' ||
          user.email === 'chaitanyakatare@argos.watch';
        const assignedRole = isOwnerAdmin ? UserRole.ADMIN : UserRole.EMPLOYEE;
        const assignedEmpId = isOwnerAdmin ? 'EMP-1001' : 'EMP-1005';

        try {
          if (isOwnerAdmin) {
            await setDoc(doc(db, 'admins', user.uid), {
              uid: user.uid,
              email: (user.email || 'chaitanyakatare@argos.watch').slice(0, 160),
              createdAt: serverTimestamp(),
            });
          }
          await setDoc(doc(db, 'users', user.uid), {
            uid: user.uid,
            email: (user.email || 'chaitanyakatare@argos.watch').slice(0, 160),
            name: (user.displayName || 'Chaitanya Katare').slice(0, 120),
            role: assignedRole,
            employeeId: assignedEmpId,
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (error) {
          if (
            error instanceof Error &&
            error.message.toLowerCase().includes('missing or insufficient permissions')
          ) {
            handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
          }
        }
      }
    });
    return () => unsubscribe();
  }, []);

  const currentEmployee = useMemo(() => {
    return allEmployees.find((e) => e.id === personaEmpId) || allEmployees[0];
  }, [allEmployees, personaEmpId]);

  const appendAuditLog = async (
    action: string,
    module: ActivityLogEntry['module'],
    targetRecord: string,
    targetEmployeeId?: string,
    previousValue?: string,
    newValue?: string
  ) => {
    const nowStr = new Date().toISOString().replace('T', ' ').slice(0, 19);
    const logId = `LOG-${Date.now()}`;
    const newEntry: ActivityLogEntry = {
      id: logId,
      actorUid: firebaseUser?.uid || currentEmployee.uid,
      actorName: currentEmployee.fullName,
      actorRole: currentRole,
      action,
      module,
      targetRecord,
      targetEmployeeId,
      previousValue: previousValue || '',
      newValue: newValue || '',
      timestamp: nowStr,
      ipDevice: 'Argos Watch Enterprise Session',
    };
    setActivityLogs((prev) => [newEntry, ...prev]);

    if (firebaseUser && firebaseUser.emailVerified) {
      try {
        await setDoc(doc(db, 'activity_logs', logId), {
          id: logId,
          actorUid: firebaseUser.uid,
          actorName: currentEmployee.fullName.slice(0, 120),
          action: action.slice(0, 200),
          module: module.slice(0, 80),
          targetRecord: targetRecord.slice(0, 200),
          createdAt: serverTimestamp(),
        });
      } catch (error) {
        if (
          error instanceof Error &&
          error.message.toLowerCase().includes('missing or insufficient permissions')
        ) {
          handleFirestoreError(error, OperationType.CREATE, `activity_logs/${logId}`);
        }
      }
    }
  };

  const switchRolePersona = (role: UserRole) => {
    setCurrentRole(role);
    const targetEmpId = ROLE_TO_PERSONA_EMP_ID[role];
    setPersonaEmpId(targetEmpId);
    setSelectedEmployeeId(null);
    setActiveSubModule(null);
    setActiveModule('dashboard');
    const personaEmp =
      allEmployees.find((e) => e.id === targetEmpId) || allEmployees[0];
    addToast(
      `Switched to ${role} View`,
      `Viewing as ${personaEmp.fullName} (${personaEmp.designation})`,
      'info'
    );
  };

  const switchEmployeePersona = (employeeId: string) => {
    const emp = allEmployees.find((e) => e.id === employeeId);
    if (!emp) return;
    setPersonaEmpId(emp.id);
    setCurrentRole(emp.role);
    setSelectedEmployeeId(null);
    setActiveSubModule(null);
    setActiveModule('dashboard');
    addToast(
      `Switched to ${emp.fullName}`,
      `${emp.designation} · ${emp.department} (${emp.role})`,
      'info'
    );
  };

  const signInWithGoogle = async () => {
    try {
      await signInWithPopup(auth, googleProvider);
      addToast('Signed in with Google', 'Connected to Firebase Auth & Firestore.');
    } catch (error) {
      addToast(
        'Sign-in Cancelled',
        error instanceof Error ? error.message : 'Unable to complete sign-in',
        'error'
      );
    }
  };

  const signOutUser = async () => {
    await firebaseSignOut(auth);
    addToast('Signed out', 'Switched to local role preview session.', 'info');
  };

  const navigateTo = (
    module: PrimaryModuleId,
    subModule: MoreSubModuleId | null = null,
    employeeId: string | null = null,
    preset: ReportFilterPreset | null = null
  ) => {
    setActiveModule(module);
    setActiveSubModule(subModule);
    setSelectedEmployeeId(employeeId);
    if (preset !== undefined) {
      setReportPreset(preset);
    }
  };

  const openEmployeeProfile = (employeeId: string) => {
    if (!employeeId) {
      setSelectedEmployeeId(null);
      return;
    }
    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;
    if (currentRole === UserRole.EMPLOYEE && employeeId !== currentEmployee.id) {
      addToast('Access Restricted', 'You can only view your own profile.', 'error');
      return;
    }
    if (
      currentRole === UserRole.MANAGER &&
      employeeId !== currentEmployee.id &&
      target.managerId !== currentEmployee.id
    ) {
      addToast(
        'Access Restricted',
        'Managers can only access profiles of employees assigned to their team.',
        'error'
      );
      return;
    }
    setSelectedEmployeeId(employeeId);
    if (currentRole === UserRole.EMPLOYEE) {
      setActiveModule('my-profile');
    } else if (currentRole === UserRole.MANAGER) {
      if (employeeId === currentEmployee.id) {
        setActiveModule('my-profile');
      } else {
        setActiveModule('my-team');
      }
    } else {
      setActiveModule('people');
    }
  };

  // Role-Scoped Collections via RBAC
  const scopedEmployees = useMemo(
    () => scopeEmployees(allEmployees, currentRole, currentEmployee.id),
    [allEmployees, currentRole, currentEmployee.id]
  );

  const scopedAttendance = useMemo(
    () => scopeAttendance(attendance, currentRole, currentEmployee.id, activeModule),
    [attendance, currentRole, currentEmployee.id, activeModule]
  );

  const scopedLeaves = useMemo(
    () => scopeLeaves(leaves, currentRole, currentEmployee.id, activeModule),
    [leaves, currentRole, currentEmployee.id, activeModule]
  );

  const scopedConsiderations = useMemo(
    () => scopeConsiderations(considerations, currentRole, currentEmployee.id, activeModule),
    [considerations, currentRole, currentEmployee.id, activeModule]
  );

  const scopedPayrolls = useMemo(
    () => scopePayrolls(payrolls, currentRole, currentEmployee.id, settings),
    [payrolls, currentRole, currentEmployee.id, settings]
  );

  const scopedDocuments = useMemo(
    () => scopeDocuments(documents, currentRole, currentEmployee.id, settings),
    [documents, currentRole, currentEmployee.id, settings]
  );

  const scopedLetters = useMemo(() => {
    const teamIds = scopedEmployees.map((e) => e.id);
    return scopeLetters(letters, currentRole, currentEmployee.id, teamIds);
  }, [letters, currentRole, currentEmployee.id, scopedEmployees]);

  const scopedPolicies = useMemo(
    () => scopePolicies(policies, currentRole, currentEmployee.department),
    [policies, currentRole, currentEmployee.department]
  );

  const scopedAnnouncements = useMemo(
    () => scopeAnnouncements(announcements, currentRole, currentEmployee.department),
    [announcements, currentRole, currentEmployee.department]
  );

  const scopedActivityLogs = useMemo(
    () => scopeActivityLogs(activityLogs, currentRole),
    [activityLogs, currentRole]
  );

  // Live Working Duration Timer State (ticking every 1s, persisted across refreshes)
  const [liveWorkingSeconds, setLiveWorkingSeconds] = useState<number>(0);

  useEffect(() => {
    const updateTimer = () => {
      const myRec = attendance.find(
        (a) => a.employeeId === currentEmployee.id && a.date === TODAY_DATE
      );
      if (!myRec || !myRec.checkIn) {
        setLiveWorkingSeconds(0);
        return;
      }
      if (myRec.checkOut) {
        // Shift concluded: show saved working duration in seconds
        const durationSec = Math.round((myRec.workingHours || 9.0) * 3600);
        setLiveWorkingSeconds(durationSec);
        return;
      }

      // Actively clocked in: calculate elapsed seconds from timestamp
      const storedStart = localStorage.getItem(`hrms_punch_start_${currentEmployee.id}`);
      const startMs = storedStart ? Number(storedStart) : null;
      if (startMs && !isNaN(startMs)) {
        const elapsed = Math.max(0, Math.floor((Date.now() - startMs) / 1000));
        setLiveWorkingSeconds(elapsed);
      } else {
        // Fallback: reconstruct from checkIn time string (e.g. "09:30")
        const [h, m] = myRec.checkIn.split(':').map(Number);
        const now = new Date();
        const punchDate = new Date(now.getFullYear(), now.getMonth(), now.getDate(), h || 9, m || 30, 0);
        const elapsed = Math.max(0, Math.floor((now.getTime() - punchDate.getTime()) / 1000));
        setLiveWorkingSeconds(elapsed);
        localStorage.setItem(`hrms_punch_start_${currentEmployee.id}`, String(punchDate.getTime()));
      }
    };

    updateTimer();
    const timerInterval = setInterval(updateTimer, 1000);
    return () => clearInterval(timerInterval);
  }, [attendance, currentEmployee.id]);

  const liveWorkingDuration = useMemo(() => {
    const s = liveWorkingSeconds;
    const hh = String(Math.floor(s / 3600)).padStart(2, '0');
    const mm = String(Math.floor((s % 3600) / 60)).padStart(2, '0');
    const ss = String(s % 60).padStart(2, '0');
    return `${hh}:${mm}:${ss}`;
  }, [liveWorkingSeconds]);

  // Workflow 1: Check-In & Check-Out with Multiple Punches & Live Timer
  const checkInToday = (notes = 'Checked in via Argos Watch Web Portal') => {
    const existing = attendance.find(
      (a) => a.employeeId === currentEmployee.id && a.date === TODAY_DATE
    );
    const existingPunches = existing?.punches || (existing?.checkIn ? [
      {
        id: `PUNCH-${existing.id}-1`,
        employeeId: currentEmployee.id,
        timestamp: `${TODAY_DATE}T${existing.checkIn}:00`,
        time: existing.checkIn,
        type: 'IN' as const,
        source: (existing.source === 'MANUAL' ? 'Manual Correction' : 'Web Portal') as PunchSource,
        isFirstIn: true,
        isLastOut: false,
        isIntermediate: false,
      },
      ...(existing.checkOut ? [{
        id: `PUNCH-${existing.id}-2`,
        employeeId: currentEmployee.id,
        timestamp: `${TODAY_DATE}T${existing.checkOut}:00`,
        time: existing.checkOut,
        type: 'OUT' as const,
        source: (existing.source === 'MANUAL' ? 'Manual Correction' : 'Web Portal') as PunchSource,
        isFirstIn: false,
        isLastOut: true,
        isIntermediate: false,
      }] : [])
    ] : []);

    const lastPunch = existingPunches.length > 0 ? existingPunches[existingPunches.length - 1] : null;
    if (lastPunch && lastPunch.type === 'IN') {
      addToast('Already Punched In', 'You are currently punched in. Punch out before recording a subsequent punch-in.', 'info');
      return;
    }

    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const timeStr = `${hh}:${mm}`;
    const nowMs = Date.now();
    localStorage.setItem(`hrms_punch_start_${currentEmployee.id}`, String(nowMs));

    const [startH, startM] = settings.workStartTime.split(':').map(Number);
    const startTotalMins = startH * 60 + startM + settings.gracePeriodMinutes;
    const currentTotalMins = now.getHours() * 60 + now.getMinutes();
    const isFirstIn = existingPunches.filter((p) => p.type === 'IN').length === 0;
    const isLate = isFirstIn && currentTotalMins > startTotalMins;
    const lateMinutes = isLate ? Math.max(0, currentTotalMins - (startH * 60 + startM)) : (existing?.lateMinutes || 0);

    const newPunch: PunchEvent = {
      id: `PUNCH-${currentEmployee.id}-${Date.now()}`,
      employeeId: currentEmployee.id,
      timestamp: `${TODAY_DATE}T${timeStr}:00`,
      time: timeStr,
      type: 'IN',
      source: 'Web Portal',
      isFirstIn,
      isLastOut: false,
      isIntermediate: !isFirstIn,
    };

    const combinedPunches = [...existingPunches, newPunch];
    const firstInPunch = combinedPunches.find((p) => p.type === 'IN');
    const firstInTime = firstInPunch?.time || timeStr;

    const interimRecord: AttendanceRecord = {
      id: existing?.id || `ATT-${TODAY_DATE.replace(/-/g, '')}-${currentEmployee.id.replace('EMP-', '')}`,
      employeeId: currentEmployee.id,
      employeeName: currentEmployee.fullName,
      employeeCode: currentEmployee.id,
      department: currentEmployee.department,
      managerId: currentEmployee.managerId,
      uid: currentEmployee.uid,
      managerUid: currentEmployee.managerUid,
      date: TODAY_DATE,
      checkIn: firstInTime,
      checkOut: null,
      punchIn: firstInTime,
      punchOut: null,
      status: isLate ? 'Late' : (existing?.status || 'Present'),
      isLate: isLate || existing?.isLate || false,
      lateMinutes,
      lateByMinutes: lateMinutes,
      earlyDepartureMinutes: 0,
      workingHours: existing?.workingHours || 0.1,
      totalHours: existing?.totalHours || 0.1,
      workHours: existing?.workHours || 0.1,
      overtimeHours: existing?.overtimeHours || 0,
      punches: combinedPunches,
      totalPunchIns: combinedPunches.filter((p) => p.type === 'IN').length,
      totalPunchOuts: combinedPunches.filter((p) => p.type === 'OUT').length,
      firstInTime,
      lastOutTime: null,
      notes,
    };

    const lateCalc = calculateLateDeduction(currentEmployee, interimRecord, settings);
    const finalRecord: AttendanceRecord = {
      ...interimRecord,
      chargeableLateMinutes: lateCalc.chargeableLateMinutes,
      perMinuteDeductionRate: lateCalc.perMinuteRate,
      dailySalaryUsed: lateCalc.dailySalary,
      monthlySalaryUsed: lateCalc.monthlySalary,
      salaryBasisUsed: lateCalc.salaryBasis,
      lateSalaryDeduction: lateCalc.deductionAmount,
      payrollAdjustmentStatus: lateCalc.status,
    };

    if (existing) {
      setAttendance((prev) => prev.map((a) => (a.id === existing.id ? finalRecord : a)));
    } else {
      setAttendance((prev) => [finalRecord, ...prev]);
    }

    appendAuditLog(
      `Punched in at ${timeStr}${isFirstIn ? ' (FIRST IN)' : ' (Intermediate IN)'}${isLate ? ` (Late by ${lateMinutes}m)` : ''}`,
      'Attendance',
      `${currentEmployee.fullName} (${currentEmployee.id})`,
      currentEmployee.id,
      isFirstIn ? 'Not Checked In' : 'On Break',
      `Checked In at ${timeStr}`
    );
    addToast(
      `Punched in at ${timeStr} (${isFirstIn ? 'First In' : `Punch-In #${combinedPunches.filter(p => p.type === 'IN').length}`})`,
      isLate
        ? `Marked Late (${lateMinutes}m past ${settings.workStartTime}). Late deduction: ₹${lateCalc.deductionAmount.toFixed(2)}.`
        : 'Punch-in recorded successfully.'
    );
  };

  const checkOutToday = () => {
    const existing = attendance.find(
      (a) => a.employeeId === currentEmployee.id && a.date === TODAY_DATE
    );
    if (!existing) {
      addToast('Cannot Punch Out', 'You must punch in first before punching out.', 'error');
      return;
    }
    const norm = getNormalizedPunchesForRecord(existing, currentEmployee.id);
    const lastPunch = norm.punches.length > 0 ? norm.punches[norm.punches.length - 1] : null;
    if (!lastPunch || lastPunch.type !== 'IN') {
      addToast('Cannot Punch Out', 'You must punch in before punching out.', 'error');
      return;
    }

    const now = new Date();
    const hh = String(now.getHours()).padStart(2, '0');
    const mm = String(now.getMinutes()).padStart(2, '0');
    const outTimeStr = `${hh}:${mm}`;

    const newOutPunch: PunchEvent = {
      id: `PUNCH-${currentEmployee.id}-${Date.now()}`,
      employeeId: currentEmployee.id,
      timestamp: `${TODAY_DATE}T${outTimeStr}:00`,
      time: outTimeStr,
      type: 'OUT',
      source: 'Web Portal',
      isFirstIn: false,
      isLastOut: true,
      isIntermediate: false,
    };

    const updatedPunches = [...norm.punches, newOutPunch];
    const interim: AttendanceRecord = {
      ...existing,
      punches: updatedPunches,
      punchOut: outTimeStr,
      checkOut: outTimeStr,
    };
    const finalNorm = getNormalizedPunchesForRecord(interim, currentEmployee.id);
    const workedHours = finalNorm.workedHours;
    const lateCalc = calculateLateDeduction(currentEmployee, interim, settings);

    const updatedRecord: AttendanceRecord = {
      ...interim,
      punches: finalNorm.punches,
      totalPunchIns: finalNorm.totalPunchIns,
      totalPunchOuts: finalNorm.totalPunchOuts,
      firstInTime: finalNorm.firstIn?.time || existing.checkIn || null,
      lastOutTime: outTimeStr,
      validPunchPairsCount: finalNorm.validPairsCount,
      hasUnmatchedPunch: finalNorm.hasUnmatchedPunch,
      unmatchedPunchNote: finalNorm.unmatchedNote,
      workingHours: workedHours,
      totalHours: workedHours,
      workHours: workedHours,
      overtimeHours: Math.max(0, Number((workedHours - 9).toFixed(1))),
      chargeableLateMinutes: lateCalc.chargeableLateMinutes,
      perMinuteDeductionRate: lateCalc.perMinuteRate,
      dailySalaryUsed: lateCalc.dailySalary,
      monthlySalaryUsed: lateCalc.monthlySalary,
      salaryBasisUsed: lateCalc.salaryBasis,
      lateSalaryDeduction: lateCalc.deductionAmount,
      payrollAdjustmentStatus: lateCalc.status,
    };

    setAttendance((prev) => prev.map((a) => (a.id === existing.id ? updatedRecord : a)));

    appendAuditLog(
      `Punched out at ${outTimeStr} (Worked duration: ${workedHours}h across ${finalNorm.validPairsCount} punch pairs)`,
      'Attendance',
      `${currentEmployee.fullName} (${currentEmployee.id})`,
      currentEmployee.id,
      `Punched In at ${lastPunch.time}`,
      `Punched Out at ${outTimeStr}`
    );
    addToast('Punched out successfully', `Departure saved: ${outTimeStr} (${workedHours}h worked from valid punch pairs).`);
  };

  const logOrUpdateAttendanceForEmployee = (payload: {
    employeeId: string;
    date: string;
    checkIn: string;
    checkOut: string | null;
    status: AttendanceRecord['status'];
    notes: string;
  }) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast(
        'Permission Denied',
        'Only HR or Admin users can add or modify employee attendance records.',
        'error'
      );
      return;
    }
    const targetEmp = allEmployees.find((e) => e.id === payload.employeeId) || currentEmployee;
    const [startH, startM] = settings.workStartTime.split(':').map(Number);
    const [inH, inM] = (payload.checkIn || '09:30').split(':').map(Number);
    const startTotalMins = startH * 60 + startM + settings.gracePeriodMinutes;
    const inTotalMins = inH * 60 + inM;
    const isLate = payload.status === 'Late' || inTotalMins > startTotalMins;
    const lateMinutes = isLate ? Math.max(0, inTotalMins - (startH * 60 + startM)) : 0;

    const existingIdx = attendance.findIndex(
      (a) => a.employeeId === targetEmp.id && a.date === payload.date
    );
    const existing = existingIdx >= 0 ? attendance[existingIdx] : null;

    const interimRecord: AttendanceRecord = {
      id: existing?.id || `ATT-${payload.date.replace(/-/g, '')}-${targetEmp.id.replace('EMP-', '')}`,
      employeeId: targetEmp.id,
      employeeName: targetEmp.fullName,
      employeeCode: targetEmp.id,
      department: targetEmp.department,
      managerId: targetEmp.managerId,
      uid: targetEmp.uid,
      managerUid: targetEmp.managerUid,
      date: payload.date,
      checkIn: payload.checkIn || null,
      checkOut: payload.checkOut || null,
      punchIn: payload.checkIn || null,
      punchOut: payload.checkOut || null,
      status: payload.status,
      isLate,
      lateMinutes,
      lateByMinutes: lateMinutes,
      earlyDepartureMinutes: 0,
      workingHours: payload.status === 'Half Day' ? 4.5 : 8.5,
      totalHours: payload.status === 'Half Day' ? 4.5 : 8.5,
      workHours: payload.status === 'Half Day' ? 4.5 : 8.5,
      overtimeHours: 0,
      notes: payload.notes || `Updated by ${currentEmployee.fullName} (${currentRole})`,
      source: 'MANUAL',
      isManualCorrection: true,
      manualCorrectionReason: payload.notes || 'Administrative Attendance Update',
      correctedBy: currentEmployee.fullName,
      correctedAt: new Date().toISOString(),
    };

    const norm = getNormalizedPunchesForRecord(interimRecord, targetEmp.id);
    const lateCalc = calculateLateDeduction(targetEmp, interimRecord, settings);

    const record: AttendanceRecord = {
      ...interimRecord,
      punches: norm.punches,
      totalPunchIns: norm.totalPunchIns,
      totalPunchOuts: norm.totalPunchOuts,
      firstInTime: norm.firstIn?.time || payload.checkIn || null,
      lastOutTime: norm.lastOut?.time || payload.checkOut || null,
      validPunchPairsCount: norm.validPairsCount,
      hasUnmatchedPunch: norm.hasUnmatchedPunch,
      unmatchedPunchNote: norm.unmatchedNote,
      workingHours: norm.workedHours || (payload.status === 'Half Day' ? 4.5 : 8.5),
      totalHours: norm.workedHours || (payload.status === 'Half Day' ? 4.5 : 8.5),
      workHours: norm.workedHours || (payload.status === 'Half Day' ? 4.5 : 8.5),
      chargeableLateMinutes: lateCalc.chargeableLateMinutes,
      perMinuteDeductionRate: lateCalc.perMinuteRate,
      dailySalaryUsed: lateCalc.dailySalary,
      monthlySalaryUsed: lateCalc.monthlySalary,
      salaryBasisUsed: lateCalc.salaryBasis,
      lateSalaryDeduction: lateCalc.deductionAmount,
      payrollAdjustmentStatus: lateCalc.status,
    };

    if (existingIdx >= 0) {
      setAttendance((prev) =>
        prev.map((item, idx) => (idx === existingIdx ? record : item))
      );
    } else {
      setAttendance((prev) => [record, ...prev]);
    }

    appendAuditLog(
      `HR/Admin Updated Attendance (${payload.date} · ${payload.status})`,
      'Attendance',
      `${targetEmp.fullName} (${targetEmp.id})`,
      targetEmp.id,
      'Previous Attendance',
      `${payload.checkIn || '--'} to ${payload.checkOut || '--'} (${payload.status})`
    );
    addToast(
      `Attendance Logged for ${targetEmp.fullName}`,
      `${payload.date} marked as ${payload.status} (${record.workingHours}h). Late deduction: ₹${lateCalc.deductionAmount}.`
    );
  };

  // Workflow 2A: Manual Attendance Correction (HR & Admin)
  const logManualAttendance = (payload: {
    employeeId: string;
    date: string;
    punchIn?: string | null;
    punchOut?: string | null;
    status: AttendanceRecord['status'];
    reason: string;
    notes?: string;
    lateByMinutes?: number;
  }) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast(
        'Permission Denied',
        'Only HR or Admin users have authorized access to manually log or correct attendance.',
        'error'
      );
      return;
    }
    if (!payload.reason || !payload.reason.trim()) {
      addToast(
        'Reason Required',
        'A mandatory explanation/reason must be provided for manual attendance records and corrections.',
        'error'
      );
      return;
    }

    const targetEmp = allEmployees.find((e) => e.id === payload.employeeId) || currentEmployee;
    const existing = attendance.find(
      (a) => a.employeeId === targetEmp.id && a.date === payload.date
    );

    const prevIn = existing?.punchIn || existing?.checkIn || null;
    const prevOut = existing?.punchOut || existing?.checkOut || null;

    const recordId =
      existing?.id ||
      `ATT-MANUAL-${payload.date.replace(/-/g, '')}-${targetEmp.id.replace('EMP-', '')}-${Date.now().toString().slice(-4)}`;
    const nowIso = new Date().toISOString();

    const manualRecordRaw: AttendanceRecord = {
      id: recordId,
      employeeId: targetEmp.id,
      employeeName: targetEmp.fullName,
      employeeCode: targetEmp.id,
      department: targetEmp.department,
      managerId: targetEmp.managerId,
      uid: targetEmp.uid,
      managerUid: targetEmp.managerUid,
      date: payload.date,
      checkIn: payload.punchIn || null,
      checkOut: payload.punchOut || null,
      punchIn: payload.punchIn || null,
      punchOut: payload.punchOut || null,
      status: payload.status,
      isLate: payload.status === 'Late' || (payload.lateByMinutes ? payload.lateByMinutes > 0 : false),
      lateMinutes: payload.lateByMinutes || 0,
      lateByMinutes: payload.lateByMinutes || 0,
      earlyDepartureMinutes: 0,
      workingHours: payload.status === 'Half Day' ? 4.5 : 8.5,
      workHours: payload.status === 'Half Day' ? 4.5 : 8.5,
      totalHours: payload.status === 'Half Day' ? 4.5 : 8.5,
      overtimeHours: 0,
      notes: `${payload.notes || ''} [Manual: ${payload.reason}]`.trim(),
      source: 'MANUAL',
      isManualCorrection: true,
      manualCorrectionReason: payload.reason.trim(),
      correctedBy: currentEmployee.fullName,
      correctedAt: nowIso,
      previousPunchIn: prevIn,
      previousPunchOut: prevOut,
    };

    const norm = getNormalizedPunchesForRecord(manualRecordRaw, targetEmp.id);
    const lateCalc = calculateLateDeduction(targetEmp, manualRecordRaw, settings);

    const manualRecord: AttendanceRecord = {
      ...manualRecordRaw,
      punches: norm.punches,
      totalPunchIns: norm.totalPunchIns,
      totalPunchOuts: norm.totalPunchOuts,
      firstInTime: norm.firstIn?.time || payload.punchIn || null,
      lastOutTime: norm.lastOut?.time || payload.punchOut || null,
      validPunchPairsCount: norm.validPairsCount,
      hasUnmatchedPunch: norm.hasUnmatchedPunch,
      unmatchedPunchNote: norm.unmatchedNote,
      workingHours: norm.workedHours || (payload.status === 'Half Day' ? 4.5 : 8.5),
      totalHours: norm.workedHours || (payload.status === 'Half Day' ? 4.5 : 8.5),
      workHours: norm.workedHours || (payload.status === 'Half Day' ? 4.5 : 8.5),
      chargeableLateMinutes: lateCalc.chargeableLateMinutes,
      perMinuteDeductionRate: lateCalc.perMinuteRate,
      dailySalaryUsed: lateCalc.dailySalary,
      monthlySalaryUsed: lateCalc.monthlySalary,
      salaryBasisUsed: lateCalc.salaryBasis,
      lateSalaryDeduction: lateCalc.deductionAmount,
      payrollAdjustmentStatus: lateCalc.status,
    };

    const nextAttendance = existing
      ? attendance.map((a) => (a.id === existing.id ? manualRecord : a))
      : [manualRecord, ...attendance];

    setAttendance(nextAttendance);
    localStorage.setItem('hrms_persisted_attendance', JSON.stringify(nextAttendance));

    appendAuditLog(
      existing ? 'Manual Attendance Correction' : 'Add Manual Attendance',
      'Attendance',
      `${targetEmp.fullName} (${targetEmp.id}) — ${payload.date}`,
      targetEmp.id,
      existing
        ? `Punch-In: ${prevIn || '--'}, Punch-Out: ${prevOut || '--'}, Status: ${existing.status}`
        : 'No Prior Record',
      `Punch-In: ${payload.punchIn || '--'}, Punch-Out: ${payload.punchOut || '--'}, Status: ${payload.status} (Reason: ${payload.reason})`
    );

    addToast(
      existing ? 'Attendance Corrected' : 'Manual Attendance Added',
      `${targetEmp.fullName} on ${payload.date} marked as ${payload.status} (${manualRecord.workingHours}h) with visible Manual badge.`,
      'success'
    );
  };

  // Workflow 2B: Add New Employee (Onboarding with Persistence)
  const addNewEmployee = (
    newEmp: Omit<Employee, 'id' | 'uid' | 'managerUid' | 'salaryHistory' | 'leaveBalance'>,
    generateOffer: boolean
  ): Employee => {
    // Generate safe unique ID to avoid collisions
    let nextNum = 1001 + allEmployees.length;
    while (allEmployees.some((e) => e.id === `EMP-${nextNum}`)) {
      nextNum++;
    }
    const empId = `EMP-${nextNum}`;
    const managerObj = allEmployees.find((e) => e.id === newEmp.managerId) || allEmployees[0];
    const created: Employee = {
      ...newEmp,
      id: empId,
      uid: `uid_emp_${nextNum}`,
      managerUid: managerObj.uid,
      salaryHistory: [],
      leaveBalance: {
        casualTotal: settings.casualLeaveQuota,
        casualUsed: 0,
        sickTotal: settings.sickLeaveQuota,
        sickUsed: 0,
        earnedTotal: settings.earnedLeaveQuota,
        earnedUsed: 0,
      },
    };

    const updatedEmployees = [created, ...allEmployees];
    setAllEmployees(updatedEmployees);
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(updatedEmployees));

    // Async write to Firestore if authenticated
    if (firebaseUser && firebaseUser.emailVerified) {
      setDoc(doc(db, 'employees', empId), {
        id: empId,
        uid: created.uid,
        managerUid: created.managerUid,
        fullName: created.fullName.slice(0, 120),
        designation: created.designation.slice(0, 120),
        department: created.department.slice(0, 80),
        status: created.status,
        payloadJson: JSON.stringify(created).slice(0, 7900),
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      }).catch((err) => console.warn('Firestore employee write err', err));
    }

    const todayAtt: AttendanceRecord = {
      id: `ATT-${TODAY_DATE.replace(/-/g, '')}-${nextNum}`,
      employeeId: empId,
      employeeName: created.fullName,
      employeeCode: empId,
      department: created.department,
      managerId: created.managerId,
      uid: created.uid,
      managerUid: created.managerUid,
      date: TODAY_DATE,
      checkIn: '09:30',
      checkOut: null,
      status: 'Present',
      isLate: false,
      lateMinutes: 0,
      earlyDepartureMinutes: 0,
      workingHours: 7.0,
      overtimeHours: 0,
      notes: 'Day 1 Onboarding Check-In',
    };
    setAttendance((prev) => [todayAtt, ...prev]);

    const gross =
      created.salary.baseSalary + created.salary.hra + created.salary.specialAllowance;
    const deductions =
      created.salary.pfDeduction +
      created.salary.taxDeduction +
      created.salary.professionalTax;
    const newPayroll: PayrollRecord = {
      id: `PAY-202610-${empId}`,
      employeeId: empId,
      employeeName: created.fullName,
      designation: created.designation,
      department: created.department,
      managerId: created.managerId,
      uid: created.uid,
      managerUid: created.managerUid,
      month: 'October 2026',
      workingDays: 26,
      presentDays: 26,
      paidLeaveDays: 0,
      unpaidLeaveDays: 0,
      lateOccurrences: 0,
      baseSalary: created.salary.baseSalary,
      hra: created.salary.hra,
      specialAllowance: created.salary.specialAllowance,
      bonus: 0,
      pfDeduction: created.salary.pfDeduction,
      taxDeduction: created.salary.taxDeduction,
      professionalTax: created.salary.professionalTax,
      attendanceDeduction: 0,
      considerationAdjustment: 0,
      netSalary: gross - deductions,
      status: 'Processed',
      paidDate: '2026-10-31',
    };
    setPayrolls((prev) => [newPayroll, ...prev]);

    if (generateOffer) {
      const offerLetter: GeneratedLetter = {
        id: `LTR-${Date.now()}`,
        employeeId: empId,
        employeeName: created.fullName,
        department: created.department,
        designation: created.designation,
        templateType: 'Offer Letter',
        subject: `Offer of Full-Time Employment — ${created.designation}`,
        content: `Date: ${TODAY_DATE}\nReference: ARG/HR/OFR/2026/${nextNum}\n\nTo,\n${created.fullName}\n${created.address}\n\nDear ${created.fullName.split(' ')[0]},\n\nWe are delighted to offer you the position of ${created.designation} in the ${created.department} department at ${settings.legalEntityName}, reporting to ${created.managerName}, effective ${created.joiningDate}.\n\nYour monthly gross compensation will be ${settings.currencySymbol}${gross.toLocaleString('en-IN')} per month.\n\nWarm regards,\nChaitanya Katare\nHead of People : Performance & Culture\n${settings.companyName}`,
        issuedDate: TODAY_DATE,
        issuedBy: currentEmployee.fullName,
      };
      setLetters((prev) => [offerLetter, ...prev]);
    }

    appendAuditLog(
      `Onboarded new employee ${created.fullName} (${empId})`,
      'People',
      `${created.fullName} (${empId})`,
      empId,
      'None',
      `${created.designation} · ${created.department}`
    );

    addToast(
      `Employee ${created.fullName} Created`,
      `Assigned ID ${empId}, added to ${created.department}${generateOffer ? ', and generated Offer Letter.' : '.'}`
    );

    return created;
  };

  const updateEmployeeStatus = (employeeId: string, status: Employee['status']) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify employee records.', 'error');
      return;
    }
    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;
    setAllEmployees((prev) =>
      prev.map((e) => (e.id === employeeId ? { ...e, status } : e))
    );
    appendAuditLog(
      `Updated employment status to ${status}`,
      'People',
      `${target.fullName} (${employeeId})`,
      employeeId,
      `Status: ${target.status}`,
      `Status: ${status}`
    );
    addToast('Employee Status Updated', `${target.fullName} is now marked as ${status}.`);
  };

  const archiveEmployee = (employeeId: string, reasonNote?: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can archive employee records.', 'error');
      return;
    }
    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;
    const previousStatus = target.status;
    const updated = allEmployees.map((e) =>
      e.id === employeeId ? { ...e, status: 'Archived' as any } : e
    );
    setAllEmployees(updated);
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(updated));

    appendAuditLog(
      `Archived employee ${target.fullName} (${employeeId})`,
      'People',
      `${target.fullName} (${employeeId})`,
      employeeId,
      `Status: ${previousStatus}`,
      `Status: Archived (Reason: ${reasonNote || 'Operational archival with all history preserved'})`
    );

    addToast(
      'Employee Archived',
      `${target.fullName} has been archived. All payroll, attendance, and leave records are safely preserved.`
    );
  };

  const deactivateEmployee = (employeeId: string, reason?: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can deactivate employee records.', 'error');
      return;
    }
    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;
    const nowIso = new Date().toISOString();
    const historyItem = {
      deactivatedAt: nowIso,
      deactivatedBy: currentEmployee.fullName,
      reason: reason || 'Administrative Deactivation',
    };
    const updated = allEmployees.map((e) => {
      if (e.id !== employeeId) return e;
      const history = e.deactivationHistory ? [...e.deactivationHistory, historyItem] : [historyItem];
      return {
        ...e,
        status: 'Inactive',
        isDeactivated: true,
        deactivatedAt: nowIso,
        deactivatedBy: currentEmployee.fullName,
        deactivationReason: reason || 'Administrative Deactivation',
        deactivationHistory: history,
      };
    });
    setAllEmployees(updated);
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(updated));

    appendAuditLog(
      `Deactivated employee ${target.fullName} (${employeeId}) - Moved to Employee Archive`,
      'People',
      `${target.fullName} (${employeeId})`,
      employeeId,
      `Status: ${target.status}`,
      `Status: Inactive (Deactivated: ${reason || 'Administrative Deactivation'})`
    );

    addToast(
      'Employee Deactivated',
      `${target.fullName} has been moved to Employee Archive. You can restore or initiate final exit from the archive.`
    );
  };

  const restoreEmployee = (employeeId: string, restoreReason?: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can restore employee records.', 'error');
      return;
    }
    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;
    const nowIso = new Date().toISOString();
    const historyItem = {
      deactivatedAt: target.deactivatedAt || nowIso,
      deactivatedBy: target.deactivatedBy || 'System',
      isRestored: true,
      restoredAt: nowIso,
      restoredBy: currentEmployee.fullName,
      restoreReason: restoreReason || 'Deactivated by mistake - Restored to active service',
    };
    const updated = allEmployees.map((e) => {
      if (e.id !== employeeId) return e;
      const history = e.deactivationHistory ? [...e.deactivationHistory, historyItem] : [historyItem];
      return {
        ...e,
        status: 'Active',
        isDeactivated: false,
        isExited: false,
        deactivationHistory: history,
      };
    });
    setAllEmployees(updated);
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(updated));

    appendAuditLog(
      `Restored employee ${target.fullName} (${employeeId}) to Active status`,
      'People',
      `${target.fullName} (${employeeId})`,
      employeeId,
      `Status: ${target.status}`,
      `Status: Active (Reason: ${restoreReason || 'Deactivated by mistake - Restored'})`
    );

    addToast(
      'Employee Restored',
      `${target.fullName} has been restored to active status without duplicating records.`
    );
  };

  const initiateFinalExit = (
    employeeIdOrData: string | FinalExitDetails,
    exitDataParam?: FinalExitDetails
  ) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can process employee final exit.', 'error');
      return;
    }
    const exitData: FinalExitDetails =
      typeof employeeIdOrData === 'object' ? employeeIdOrData : exitDataParam!;
    const employeeId =
      typeof employeeIdOrData === 'string' ? employeeIdOrData : exitData.employeeId!;

    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;

    let generatedLetterId = exitData.generatedLetterId;
    if (exitData.selectedLetterTemplateId && !generatedLetterId) {
      const template = masterLetterTemplates.find((t) => t.id === exitData.selectedLetterTemplateId);
      if (template) {
        const letter = generateAndSaveLetter({
          employeeId: target.id,
          templateType: (exitData.exitType === 'Resignation' ? 'Offer Letter' : 'Warning / Show Cause Notice') as any,
          subject: `${exitData.exitType === 'Resignation' ? 'Resignation Acceptance' : 'Relieving / Termination'} — ${target.fullName}`,
          content: `Dear ${target.fullName},\n\nThis letter formally acknowledges your final exit (${exitData.exitType}) effective from ${exitData.effectiveLastDate || exitData.effectiveLastWorkingDate}.\n\nReason: ${exitData.exitReason}\n\nInternal Notes: ${exitData.internalNote || exitData.mandatoryInternalNote || 'Exit processed in accordance with company policy.'}\n\nWe thank you for your contributions to Argos Watch and wish you the very best in your future endeavors.\n\nAuthorized Signatory,\nArgos Watch HR`,
        });
        generatedLetterId = letter.id;
      }
    }

    const finalExitRecord: FinalExitDetails = {
      ...exitData,
      generatedLetterId,
      initiatedBy: exitData.initiatedBy || currentEmployee.fullName,
      initiatedAt: exitData.initiatedAt || new Date().toISOString(),
      finalizedBy: currentEmployee.fullName,
      finalizedAt: new Date().toISOString(),
      status: 'FINAL_EXIT_COMPLETED',
    };

    const updated = allEmployees.map((e) => {
      if (e.id !== employeeId) return e;
      return {
        ...e,
        status: 'Exited',
        isDeactivated: true,
        isExited: true,
        finalExit: finalExitRecord,
      };
    });
    setAllEmployees(updated);
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(updated));

    appendAuditLog(
      `Finalized Exit for ${target.fullName} (${employeeId}) - Type: ${exitData.exitType}`,
      'People',
      `${target.fullName} (${employeeId})`,
      employeeId,
      `Status: ${target.status}`,
      `Status: Exited (Effective: ${exitData.effectiveLastDate || exitData.effectiveLastWorkingDate}, Reason: ${exitData.exitReason})`
    );

    setNotifications((prev) => [
      {
        id: `NOTIF-EXIT-${Date.now()}`,
        targetRoles: [UserRole.ADMIN, UserRole.HR],
        title: `Employee Exit Completed: ${target.fullName}`,
        message: `${target.fullName} (${target.department}) exit finalized as ${exitData.exitType}. Effective Last Day: ${exitData.effectiveLastDate}.`,
        category: 'Announcement',
        createdAt: new Date().toISOString(),
        isRead: false,
        linkModule: 'people',
      },
      ...prev,
    ]);

    addToast(
      'Final Exit Processed',
      `${target.fullName} marked as Exited. Historical records preserved, future access restricted.`
    );
  };

  const updateNoticePeriod = (employeeId: string, noticeData: NoticePeriodDetails) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify notice period.', 'error');
      return;
    }
    const target = allEmployees.find((e) => e.id === employeeId);
    if (!target) return;
    const nowIso = new Date().toISOString();
    const updatedNotice: NoticePeriodDetails = {
      ...noticeData,
      createdBy: noticeData.createdBy || currentEmployee.fullName,
      createdAt: noticeData.createdAt || nowIso,
      updatedAt: nowIso,
      updatedBy: currentEmployee.fullName,
    };

    let newStatus = target.status;
    if (noticeData.applicable && noticeData.status === 'Active' && target.status !== 'Exited' && target.status !== 'Inactive') {
      newStatus = 'On Notice';
    } else if ((noticeData.status === 'Cancelled' || noticeData.status === 'Waived') && target.status === 'On Notice') {
      newStatus = 'Active';
    }

    const updated = allEmployees.map((e) => {
      if (e.id !== employeeId) return e;
      return {
        ...e,
        status: newStatus,
        noticePeriod: updatedNotice,
      };
    });
    setAllEmployees(updated);
    localStorage.setItem('hrms_persisted_employees', JSON.stringify(updated));

    appendAuditLog(
      `Updated Notice Period for ${target.fullName} (${employeeId}) - Status: ${noticeData.status}`,
      'People',
      `${target.fullName} (${employeeId})`,
      employeeId,
      `Notice Status: ${target.noticePeriod?.status || 'None'}`,
      `Notice Status: ${noticeData.status} (Expected Last Day: ${noticeData.expectedLastWorkingDate})`
    );

    addToast(
      'Notice Period Updated',
      `Notice period for ${target.fullName} recorded (Expected Last Day: ${noticeData.expectedLastWorkingDate}).`
    );
  };

  // Workflow 3: Two-Stage Leave Approval Workflow (Employee -> Manager Review -> HR Final Review -> Final Status)
  const applyLeave = (payload: {
    targetEmployeeId?: string;
    leaveType: LeaveRequest['leaveType'];
    startDate: string;
    endDate: string;
    days: number;
    isHalfDay: boolean;
    halfDaySession?: LeaveRequest['halfDaySession'];
    reason: string;
    autoApprove?: boolean;
  }) => {
    const isHRAdmin = currentRole === UserRole.HR || currentRole === UserRole.ADMIN;
    const targetEmp =
      isHRAdmin && payload.targetEmployeeId
        ? allEmployees.find((e) => e.id === payload.targetEmployeeId) || currentEmployee
        : currentEmployee;

    const isOnBehalf = targetEmp.id !== currentEmployee.id;
    const canAutoApprove = isHRAdmin && Boolean(payload.autoApprove);
    const nowFormatted = new Date().toISOString().replace('T', ' ').slice(0, 16);

    const leaveId = `LV-2026-${100 + leaves.length + 1}`;
    const initialHistory = [
      {
        stage: 'SUBMITTED' as const,
        actorId: currentEmployee.id,
        actorName: currentEmployee.fullName,
        actorRole: currentRole,
        action: 'SUBMITTED' as const,
        note: payload.reason,
        timestamp: nowFormatted,
      },
      ...(canAutoApprove
        ? [
            {
              stage: 'HR_FINAL_REVIEW' as const,
              actorId: currentEmployee.id,
              actorName: currentEmployee.fullName,
              actorRole: currentRole,
              action: 'APPROVED' as const,
              note: `Logged & Final Approved by ${currentEmployee.fullName} (${currentRole} On Behalf)`,
              timestamp: nowFormatted,
            },
          ]
        : []),
    ];

    const newLeave: LeaveRequest = {
      id: leaveId,
      employeeId: targetEmp.id,
      employeeName: targetEmp.fullName,
      department: targetEmp.department,
      managerId: targetEmp.managerId,
      uid: targetEmp.uid,
      managerUid: targetEmp.managerUid,
      leaveType: payload.leaveType,
      startDate: payload.startDate,
      endDate: payload.endDate,
      days: payload.days,
      isHalfDay: payload.isHalfDay,
      halfDaySession: payload.isHalfDay
        ? payload.halfDaySession || 'First Half (09:30 - 14:00)'
        : undefined,
      reason: payload.reason,
      appliedBy: isOnBehalf
        ? `${currentEmployee.fullName} (${currentRole} On Behalf)`
        : targetEmp.fullName,
      status: canAutoApprove ? 'APPROVED' : 'PENDING_MANAGER',
      decisionNote: canAutoApprove
        ? `Logged & Approved by ${currentEmployee.fullName} (${currentRole} On Behalf)`
        : `Awaiting Manager Review (${targetEmp.managerName})`,
      hrApprovedBy: canAutoApprove ? currentEmployee.fullName : undefined,
      hrApprovedAt: canAutoApprove ? nowFormatted : undefined,
      hrDecisionNote: canAutoApprove
        ? `Logged & Approved by ${currentEmployee.fullName}`
        : undefined,
      decidedBy: canAutoApprove ? currentEmployee.fullName : undefined,
      decidedAt: canAutoApprove ? new Date().toISOString() : undefined,
      approvalHistory: initialHistory,
      createdAt: new Date().toISOString(),
    };

    setLeaves((prev) => [newLeave, ...prev]);

    if (canAutoApprove) {
      setAllEmployees((prev) =>
        prev.map((emp) => {
          if (emp.id !== targetEmp.id) return emp;
          const bal = { ...emp.leaveBalance };
          const lt = String(payload.leaveType).toUpperCase();
          if (lt === 'CASUAL') bal.casualUsed += payload.days;
          if (lt === 'SICK') bal.sickUsed += payload.days;
          if (lt === 'EARNED') bal.earnedUsed += payload.days;
          return { ...emp, leaveBalance: bal };
        })
      );
    }

    // Notify relevant Manager and HR/Employee
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}-MGR`,
        targetRoles: [UserRole.MANAGER, UserRole.HR, UserRole.ADMIN],
        targetEmployeeId: !isOnBehalf ? targetEmp.managerId : undefined,
        title: isOnBehalf
          ? `Leave Logged on Behalf: ${targetEmp.fullName}`
          : `Leave Request Awaiting Manager Review: ${targetEmp.fullName}`,
        message: isOnBehalf
          ? `${currentEmployee.fullName} logged ${payload.days}d ${payload.leaveType} Leave for ${targetEmp.fullName} (${payload.startDate}).`
          : `${targetEmp.fullName} applied for ${payload.days}d ${payload.leaveType} Leave (${payload.startDate} to ${payload.endDate}). Routed to ${targetEmp.managerName} for Manager Review.`,
        category: 'Leave',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'leave',
      },
      {
        id: `NOTIF-${Date.now()}-EMP`,
        targetRoles: [UserRole.EMPLOYEE, UserRole.MANAGER],
        targetEmployeeId: targetEmp.id,
        title: `Leave Request Submitted (${leaveId})`,
        message: canAutoApprove
          ? `Your ${payload.days}d ${payload.leaveType} leave (${payload.startDate}) has been logged and approved by HR.`
          : `Your ${payload.days}d ${payload.leaveType} leave request has been sent to ${targetEmp.managerName} for Manager Review.`,
        category: 'Leave',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'leave',
      },
      ...prev,
    ]);

    appendAuditLog(
      isOnBehalf
        ? `HR Applied${canAutoApprove ? ' & Approved' : ''} ${payload.days}d ${payload.leaveType} Leave on Behalf (${leaveId})`
        : `Submitted ${payload.days}d ${payload.leaveType} Leave (${leaveId}) -> Manager Review`,
      'Leave',
      `${targetEmp.fullName} (${targetEmp.id})`,
      targetEmp.id,
      'None',
      `${payload.startDate} to ${payload.endDate} (${newLeave.status})`
    );

    addToast(
      isOnBehalf
        ? `Leave Logged for ${targetEmp.fullName}`
        : 'Leave Request Submitted',
      isOnBehalf
        ? `Recorded ${payload.days}d ${payload.leaveType} leave on behalf of ${targetEmp.fullName} (${newLeave.status}).`
        : `Routed to ${targetEmp.managerName} for Stage 1 Manager Review.`
    );
  };

  const decideLeave = (
    leaveId: string,
    status: 'Approved' | 'Rejected',
    decisionNote: string
  ) => {
    const target = leaves.find((l) => l.id === leaveId);
    if (!target) return;

    if (status === 'Rejected' && !decisionNote.trim()) {
      addToast(
        'Rejection Reason Required',
        'Please provide a reason for rejecting this leave request.',
        'error'
      );
      return;
    }

    const nowFormatted = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const isManagerActor = currentRole === UserRole.MANAGER;
    const isHRAdminActor = currentRole === UserRole.HR || currentRole === UserRole.ADMIN;

    if (!isManagerActor && !isHRAdminActor) {
      addToast('Permission Denied', 'You are not authorized to review leave requests.', 'error');
      return;
    }

    if (isManagerActor) {
      if (target.managerId !== currentEmployee.id || target.employeeId === currentEmployee.id) {
        addToast(
          'Access Restricted',
          'Managers can only review leave requests for employees assigned to their team.',
          'error'
        );
        return;
      }
      if (
        target.status !== 'Pending' &&
        (target.status as string) !== 'Pending Manager' &&
        target.status !== 'PENDING_MANAGER'
      ) {
        addToast(
          'Already Reviewed',
          'This leave request has already completed the Manager Review stage.',
          'info'
        );
        return;
      }

      const nextStatus = status === 'Approved' ? 'PENDING_HR' : 'REJECTED';
      const noteText =
        decisionNote.trim() ||
        (status === 'Approved'
          ? `Approved by Manager (${currentEmployee.fullName}) and forwarded to HR for final approval.`
          : 'Rejected by Manager.');

      setLeaves((prev) =>
        prev.map((l) => {
          if (l.id !== leaveId) return l;
          const prevHist = l.approvalHistory || [
            {
              stage: 'SUBMITTED' as const,
              actorId: l.employeeId,
              actorName: l.employeeName,
              actorRole: UserRole.EMPLOYEE,
              action: 'SUBMITTED' as const,
              note: l.reason,
              timestamp: (l.createdAt || new Date().toISOString()).slice(0, 16).replace('T', ' '),
            },
          ];
          return {
            ...l,
            status: nextStatus,
            managerApprovedBy: status === 'Approved' ? currentEmployee.fullName : l.managerApprovedBy,
            managerApprovedAt: status === 'Approved' ? nowFormatted : l.managerApprovedAt,
            managerDecisionNote: noteText,
            rejectedBy: status === 'Rejected' ? currentEmployee.fullName : undefined,
            rejectedByRole: status === 'Rejected' ? UserRole.MANAGER : undefined,
            rejectedAt: status === 'Rejected' ? nowFormatted : undefined,
            rejectionReason: status === 'Rejected' ? noteText : undefined,
            decisionNote: noteText,
            decidedBy: currentEmployee.fullName,
            decidedAt: new Date().toISOString(),
            approvalHistory: [
              ...prevHist,
              {
                stage: 'MANAGER_REVIEW',
                actorId: currentEmployee.id,
                actorName: currentEmployee.fullName,
                actorRole: UserRole.MANAGER,
                action: status === 'Approved' ? 'APPROVED' : 'REJECTED',
                note: noteText,
                timestamp: nowFormatted,
              },
            ],
          };
        })
      );

      // Notify Employee and HR (Do NOT deduct leave balance yet — wait for HR Final Review!)
      setNotifications((prev) => [
        {
          id: `NOTIF-${Date.now()}-EMP`,
          targetRoles: [UserRole.EMPLOYEE, UserRole.MANAGER],
          targetEmployeeId: target.employeeId,
          title:
            status === 'Approved'
              ? `Manager Approved Leave (${leaveId}) — Forwarded to HR`
              : `Leave Rejected by Manager (${leaveId})`,
          message:
            status === 'Approved'
              ? `${currentEmployee.fullName} approved your ${target.days}d ${target.leaveType} leave and forwarded it to HR for final approval.`
              : `${currentEmployee.fullName} rejected your ${target.days}d ${target.leaveType} leave. Reason: ${noteText}`,
          category: 'Leave',
          createdAt: 'Just now',
          isRead: false,
          linkModule: 'leave',
        },
        {
          id: `NOTIF-${Date.now()}-HR`,
          targetRoles: [UserRole.HR, UserRole.ADMIN],
          title:
            status === 'Approved'
              ? `Leave Awaiting HR Final Review: ${target.employeeName}`
              : `Manager Rejected Leave: ${target.employeeName}`,
          message:
            status === 'Approved'
              ? `Manager ${currentEmployee.fullName} approved ${target.employeeName}'s ${target.days}d ${target.leaveType} leave (${target.startDate}). Ready for HR Final Review.`
              : `Manager ${currentEmployee.fullName} rejected ${target.employeeName}'s leave (${leaveId}). Reason: ${noteText}`,
          category: 'Leave',
          createdAt: 'Just now',
          isRead: false,
          linkModule: 'leave',
        },
        ...prev,
      ]);

      appendAuditLog(
        status === 'Approved'
          ? `Manager Approved Leave (${leaveId}) -> Forwarded to HR`
          : `Manager Rejected Leave (${leaveId}) — Reason: ${noteText}`,
        'Leave',
        `${target.employeeName} (${target.employeeId})`,
        target.employeeId,
        'Status: PENDING_MANAGER',
        `Status: ${nextStatus}`
      );

      addToast(
        status === 'Approved'
          ? 'Manager Approved — Forwarded to HR'
          : 'Leave Request Rejected by Manager',
        status === 'Approved'
          ? `${target.employeeName}'s leave has been forwarded to HR for final approval.`
          : `Rejected with reason: "${noteText}". Employee notified.`
      );
      return;
    }

    // HR / Admin Final Review Stage
    const finalStatus = status === 'Approved' ? 'APPROVED' : 'REJECTED';
    const hrNote =
      decisionNote.trim() ||
      (status === 'Approved'
        ? `Final HR approval granted by ${currentEmployee.fullName}. Leave balance updated.`
        : 'Rejected by HR during final review.');

    setLeaves((prev) =>
      prev.map((l) => {
        if (l.id !== leaveId) return l;
        const prevHist = l.approvalHistory || [
          {
            stage: 'SUBMITTED' as const,
            actorId: l.employeeId,
            actorName: l.employeeName,
            actorRole: UserRole.EMPLOYEE,
            action: 'SUBMITTED' as const,
            note: l.reason,
            timestamp: (l.createdAt || new Date().toISOString()).slice(0, 16).replace('T', ' '),
          },
        ];
        return {
          ...l,
          status: finalStatus,
          hrApprovedBy: status === 'Approved' ? currentEmployee.fullName : l.hrApprovedBy,
          hrApprovedAt: status === 'Approved' ? nowFormatted : l.hrApprovedAt,
          hrDecisionNote: hrNote,
          rejectedBy: status === 'Rejected' ? currentEmployee.fullName : l.rejectedBy,
          rejectedByRole: status === 'Rejected' ? currentRole : l.rejectedByRole,
          rejectedAt: status === 'Rejected' ? nowFormatted : l.rejectedAt,
          rejectionReason: status === 'Rejected' ? hrNote : l.rejectionReason,
          decisionNote: hrNote,
          decidedBy: currentEmployee.fullName,
          decidedAt: new Date().toISOString(),
          approvalHistory: [
            ...prevHist,
            {
              stage: 'HR_FINAL_REVIEW',
              actorId: currentEmployee.id,
              actorName: currentEmployee.fullName,
              actorRole: currentRole,
              action: status === 'Approved' ? 'APPROVED' : 'REJECTED',
              note: hrNote,
              timestamp: nowFormatted,
            },
          ],
        };
      })
    );

    // Update Leave Balances ONLY upon HR Final Approval!
    if (status === 'Approved') {
      setAllEmployees((prev) =>
        prev.map((emp) => {
          if (emp.id !== target.employeeId) return emp;
          const bal = { ...emp.leaveBalance };
          const lt = String(target.leaveType).toUpperCase();
          if (lt === 'CASUAL') bal.casualUsed += target.days;
          if (lt === 'SICK') bal.sickUsed += target.days;
          if (lt === 'EARNED') bal.earnedUsed += target.days;
          return { ...emp, leaveBalance: bal };
        })
      );
    }

    // Notify both Employee and relevant Manager
    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}-EMP`,
        targetRoles: [UserRole.EMPLOYEE, UserRole.MANAGER],
        targetEmployeeId: target.employeeId,
        title: `HR Final Review — Leave ${status}: ${target.leaveType} (${target.days}d)`,
        message:
          status === 'Approved'
            ? `HR (${currentEmployee.fullName}) finalized and approved your leave request ${leaveId}. Your leave balance has been updated.`
            : `HR (${currentEmployee.fullName}) rejected your leave request ${leaveId}. Reason: ${hrNote}`,
        category: 'Leave',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'leave',
      },
      {
        id: `NOTIF-${Date.now()}-MGR`,
        targetRoles: [UserRole.MANAGER],
        targetEmployeeId: target.managerId,
        title: `HR Final Decision on Team Leave (${target.employeeName})`,
        message: `HR (${currentEmployee.fullName}) ${status.toLowerCase()} ${target.employeeName}'s ${target.days}d ${target.leaveType} leave (${leaveId}). Note: ${hrNote}`,
        category: 'Leave',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'leave',
      },
      ...prev,
    ]);

    appendAuditLog(
      `HR Final ${status} Leave Request (${leaveId})`,
      'Leave',
      `${target.employeeName} (${target.employeeId})`,
      target.employeeId,
      `Status: ${target.status}`,
      `Status: ${finalStatus}`
    );
    addToast(
      `HR Final Review: Leave ${status}`,
      status === 'Approved'
        ? `${target.employeeName}'s ${target.leaveType} leave is now Final Approved and leave balance updated.`
        : `${target.employeeName}'s leave rejected. Employee and Manager notified.`
    );
  };

  // Workflow 4: Two-Stage Consideration Approval Workflow
  // (Employee or Manager submits -> Manager Review -> HR Final Review -> Final Status)
  const submitConsideration = (payload: {
    employeeId: string;
    date: string;
    type: ConsiderationRequest['type'];
    customType?: string;
    title?: string;
    category?: string;
    reason: string;
    supportingNote?: string;
    supportingDocument: string;
    forwardToHRImmediately?: boolean;
  }) => {
    const targetEmp =
      allEmployees.find((e) => e.id === payload.employeeId) || currentEmployee;

    // Enforce Team-Based Access Security for Consideration Submission
    if (currentRole === UserRole.EMPLOYEE && targetEmp.id !== currentEmployee.id) {
      addToast(
        'Access Restricted',
        'Employees can only submit consideration requests for themselves.',
        'error'
      );
      return;
    }
    if (
      currentRole === UserRole.MANAGER &&
      targetEmp.id !== currentEmployee.id &&
      targetEmp.managerId !== currentEmployee.id &&
      !isAssignedTeamMember(targetEmp, currentEmployee.id)
    ) {
      addToast(
        'Access Restricted',
        'Managers can only submit consideration requests for employees assigned to their team.',
        'error'
      );
      return;
    }

    const conId = `CON-${1000 + considerations.length + 1}`;
    const dailyBasicHalf = Math.round(targetEmp.salary.baseSalary / 44);
    const nowFormatted = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const isSubmittedByManagerForTeam =
      currentRole === UserRole.MANAGER && targetEmp.id !== currentEmployee.id;

    // A request submitted by an employee goes to Manager first (PENDING_MANAGER).
    // When a Manager submits on behalf of an assigned team member:
    // 1. Automatically complete the Manager approval stage.
    // 2. Forward it directly to HR for final review (PENDING_HR).
    // 3. Clearly identify origin as 'Submitted by Manager on behalf of Employee'.
    // 4. Record employee and Manager names, reason, timestamp and audit history.
    // 5. Does NOT bypass HR approval or deduct payroll before HR final decision.
    const autoEndorseByManager = isSubmittedByManagerForTeam;
    const initialStatus = autoEndorseByManager ? 'PENDING_HR' : 'PENDING_MANAGER';

    const initialHistory = [
      {
        stage: 'SUBMITTED' as const,
        actorId: currentEmployee.id,
        actorName: currentEmployee.fullName,
        actorRole: currentRole,
        action: 'SUBMITTED' as const,
        note: isSubmittedByManagerForTeam
          ? `Submitted by Manager on behalf of Employee (${targetEmp.fullName}): ${payload.reason}${payload.supportingNote ? ` | Supporting Note: ${payload.supportingNote}` : ''}`
          : `${payload.reason}${payload.supportingNote ? ` | Supporting Note: ${payload.supportingNote}` : ''}`,
        timestamp: nowFormatted,
      },
      ...(autoEndorseByManager
        ? [
            {
              stage: 'MANAGER_REVIEW' as const,
              actorId: currentEmployee.id,
              actorName: currentEmployee.fullName,
              actorRole: UserRole.MANAGER,
              action: 'APPROVED' as const,
              note:
                payload.supportingNote ||
                `Manager submission on behalf of ${targetEmp.fullName}. Stage 1 Manager Approval automatically completed. Forwarded directly to HR for final review.`,
              timestamp: nowFormatted,
            },
          ]
        : []),
    ];

    const resolvedType =
      payload.type === 'Other' && payload.customType?.trim()
        ? payload.customType.trim()
        : payload.type;

    const newCon: ConsiderationRequest = {
      id: conId,
      employeeId: targetEmp.id,
      employeeName: targetEmp.fullName,
      department: targetEmp.department,
      managerId: targetEmp.managerId,
      uid: targetEmp.uid,
      managerUid: targetEmp.managerUid,
      date: payload.date || TODAY_DATE,
      type: resolvedType,
      customType: payload.customType?.trim() || (payload.type === 'Other' ? resolvedType : undefined),
      category: payload.type === 'Other' ? 'Other' : (payload.category || payload.type),
      title: isSubmittedByManagerForTeam
        ? `[Submitted by Manager on behalf of Employee] ${resolvedType} — ${targetEmp.fullName}`
        : `${resolvedType} — ${targetEmp.fullName} (${payload.date || TODAY_DATE})`,
      description: payload.reason,
      reason: payload.reason,
      supportingNote:
        payload.supportingNote ||
        (isSubmittedByManagerForTeam
          ? `Submitted by Manager on behalf of Employee (${targetEmp.fullName}) by ${currentEmployee.fullName}`
          : 'Employee self-submission'),
      origin: isSubmittedByManagerForTeam ? 'MANAGER_ON_BEHALF' : 'EMPLOYEE_SUBMITTED',
      submittedById: currentEmployee.id,
      submittedByRole: currentRole,
      submittedByName: currentEmployee.fullName,
      submittedOnBehalfOfName: isSubmittedByManagerForTeam ? targetEmp.fullName : undefined,
      supportingDocument: payload.supportingDocument || 'Supporting_Attestation_Note.pdf',
      status: initialStatus,
      managerApprovedBy: autoEndorseByManager ? currentEmployee.fullName : undefined,
      managerApprovedAt: autoEndorseByManager ? nowFormatted : undefined,
      managerDecisionNote: autoEndorseByManager
        ? payload.supportingNote ||
          `Manager-submitted on behalf of ${targetEmp.fullName}. Stage 1 auto-completed. Forwarded to HR.`
        : undefined,
      decisionNote: autoEndorseByManager
        ? 'Manager-submitted on behalf of Employee. Stage 1 completed. Forwarded directly to HR for final review.'
        : `Awaiting Manager Review (${targetEmp.managerName})`,
      affectsAttendancePenalty: true,
      affectsSalaryDeduction: true,
      approvalHistory: initialHistory,
      deductionAmountSaved: dailyBasicHalf,
      createdAt: new Date().toISOString(),
    };

    setConsiderations((prev) => [newCon, ...prev]);
    setAttendance((prev) =>
      prev.map((a) =>
        a.employeeId === targetEmp.id && a.date === payload.date
          ? { ...a, considerationId: conId, considerationStatus: 'Pending' }
          : a
      )
    );

    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}-CON`,
        targetRoles: [UserRole.MANAGER, UserRole.HR, UserRole.ADMIN],
        targetEmployeeId:
          initialStatus === 'PENDING_MANAGER' ? targetEmp.managerId : undefined,
        title: isSubmittedByManagerForTeam
          ? `Manager Submitted Consideration (${conId}): ${targetEmp.fullName}`
          : `New Consideration Request (${conId}): ${targetEmp.fullName}`,
        message: isSubmittedByManagerForTeam
          ? `${currentEmployee.fullName} (Manager) submitted a ${payload.type} consideration on behalf of ${targetEmp.fullName}. Status: ${initialStatus}.`
          : `${targetEmp.fullName} submitted a ${payload.type} consideration for ${payload.date}. Routed to ${targetEmp.managerName} for Manager Review.`,
        category: 'Consideration',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'more',
        linkSubModule: 'considerations',
      },
      ...(isSubmittedByManagerForTeam
        ? [
            {
              id: `NOTIF-${Date.now()}-EMP-CON`,
              targetRoles: [UserRole.EMPLOYEE],
              targetEmployeeId: targetEmp.id,
              title: `Manager Submitted Consideration on Your Behalf (${conId})`,
              message: `${currentEmployee.fullName} submitted a ${payload.type} request for ${payload.date} on your behalf.`,
              category: 'Consideration' as const,
              createdAt: 'Just now',
              isRead: false,
              linkModule: 'more' as const,
              linkSubModule: 'considerations' as const,
            },
          ]
        : []),
      ...prev,
    ]);

    appendAuditLog(
      isSubmittedByManagerForTeam
        ? `Manager Submitted Consideration on Behalf (${conId}) — ${payload.type}`
        : `Submitted Consideration (${conId}) — ${payload.type}`,
      'Considerations',
      `${targetEmp.fullName} (${targetEmp.id})`,
      targetEmp.id,
      'Unwaived Attendance Exception',
      `Status: ${initialStatus}`
    );
    addToast(
      isSubmittedByManagerForTeam
        ? `Consideration Submitted for ${targetEmp.fullName}`
        : 'Consideration Request Submitted',
      initialStatus === 'PENDING_HR'
        ? `Request ${conId} endorsed by Manager and forwarded to HR for final review.`
        : `Request ${conId} routed to Manager Review before HR Final Review.`
    );
  };

  const decideConsideration = (
    considerationId: string,
    status: 'Approved' | 'Rejected',
    decisionNote: string,
    options?: {
      affectsAttendancePenalty?: boolean;
      affectsSalaryDeduction?: boolean;
    }
  ) => {
    const target = considerations.find((c) => c.id === considerationId);
    if (!target) return;

    if (status === 'Rejected' && !decisionNote.trim()) {
      addToast(
        'Rejection Reason Required',
        'Please provide a reason for rejecting this consideration request.',
        'error'
      );
      return;
    }

    const nowFormatted = new Date().toISOString().replace('T', ' ').slice(0, 16);
    const isManagerActor = currentRole === UserRole.MANAGER;
    const isHRAdminActor = currentRole === UserRole.HR || currentRole === UserRole.ADMIN;

    if (!isManagerActor && !isHRAdminActor) {
      addToast(
        'Permission Denied',
        'Only assigned Managers or HR/Admin can review consideration requests.',
        'error'
      );
      return;
    }

    // Stage 1: Manager Review (Forwards to HR on approval, or rejects with reason)
    if (isManagerActor) {
      if (target.managerId !== currentEmployee.id) {
        addToast(
          'Access Restricted',
          'Managers can only review consideration requests for their assigned team members.',
          'error'
        );
        return;
      }
      if (
        target.status !== 'Pending' &&
        (target.status as string) !== 'Pending Manager' &&
        target.status !== 'PENDING_MANAGER'
      ) {
        addToast(
          'Already Reviewed by Manager',
          'This consideration has already been forwarded to HR or finalized.',
          'info'
        );
        return;
      }

      const nextStatus = status === 'Approved' ? 'PENDING_HR' : 'REJECTED';
      const mgrNote =
        decisionNote.trim() ||
        (status === 'Approved'
          ? `Approved by Manager (${currentEmployee.fullName}) and forwarded to HR for final review.`
          : 'Rejected by Manager.');

      setConsiderations((prev) =>
        prev.map((c) => {
          if (c.id !== considerationId) return c;
          const prevHist = c.approvalHistory || [
            {
              stage: 'SUBMITTED' as const,
              actorId: c.submittedById || c.employeeId,
              actorName: c.submittedByName,
              actorRole: c.submittedByRole,
              action: 'SUBMITTED' as const,
              note: c.reason,
              timestamp: (c.createdAt || new Date().toISOString()).slice(0, 16).replace('T', ' '),
            },
          ];
          return {
            ...c,
            status: nextStatus,
            managerApprovedBy: status === 'Approved' ? currentEmployee.fullName : c.managerApprovedBy,
            managerApprovedAt: status === 'Approved' ? nowFormatted : c.managerApprovedAt,
            managerDecisionNote: mgrNote,
            rejectedBy: status === 'Rejected' ? currentEmployee.fullName : undefined,
            rejectedByRole: status === 'Rejected' ? UserRole.MANAGER : undefined,
            rejectedAt: status === 'Rejected' ? nowFormatted : undefined,
            rejectionReason: status === 'Rejected' ? mgrNote : undefined,
            decisionNote: mgrNote,
            decidedBy: currentEmployee.fullName,
            decisionDate: TODAY_DATE,
            approvalHistory: [
              ...prevHist,
              {
                stage: 'MANAGER_REVIEW',
                actorId: currentEmployee.id,
                actorName: currentEmployee.fullName,
                actorRole: UserRole.MANAGER,
                action: status === 'Approved' ? 'APPROVED' : 'REJECTED',
                note: mgrNote,
                timestamp: nowFormatted,
              },
            ],
          };
        })
      );

      if (status === 'Rejected') {
        setAttendance((prev) =>
          prev.map((a) =>
            a.employeeId === target.employeeId && a.date === target.date
              ? { ...a, considerationStatus: 'Rejected' }
              : a
          )
        );
      }

      setNotifications((prev) => [
        {
          id: `NOTIF-${Date.now()}-EMP-CON`,
          targetRoles: [UserRole.EMPLOYEE, UserRole.MANAGER],
          targetEmployeeId: target.employeeId,
          title:
            status === 'Approved'
              ? `Manager Approved Consideration (${considerationId}) — Sent to HR`
              : `Consideration Rejected by Manager (${considerationId})`,
          message:
            status === 'Approved'
              ? `Manager ${currentEmployee.fullName} approved your consideration (${considerationId}) and forwarded it to HR for final review.`
              : `Manager ${currentEmployee.fullName} rejected your consideration (${considerationId}). Reason: ${mgrNote}`,
          category: 'Consideration',
          createdAt: 'Just now',
          isRead: false,
          linkModule: 'more',
          linkSubModule: 'considerations',
        },
        {
          id: `NOTIF-${Date.now()}-HR-CON`,
          targetRoles: [UserRole.HR, UserRole.ADMIN],
          title:
            status === 'Approved'
              ? `Consideration Awaiting HR Final Review (${considerationId})`
              : `Manager Rejected Consideration (${considerationId})`,
          message:
            status === 'Approved'
              ? `Manager ${currentEmployee.fullName} approved ${target.employeeName}'s ${target.type} consideration. Ready for HR Final Review.`
              : `Manager ${currentEmployee.fullName} rejected ${target.employeeName}'s consideration (${considerationId}).`,
          category: 'Consideration',
          createdAt: 'Just now',
          isRead: false,
          linkModule: 'more',
          linkSubModule: 'considerations',
        },
        ...prev,
      ]);

      appendAuditLog(
        status === 'Approved'
          ? `Manager Approved Consideration (${considerationId}) -> Forwarded to HR`
          : `Manager Rejected Consideration (${considerationId}) — Reason: ${mgrNote}`,
        'Considerations',
        `${target.employeeName} (${target.employeeId})`,
        target.employeeId,
        'Status: PENDING_MANAGER',
        `Status: ${nextStatus}`
      );

      addToast(
        status === 'Approved'
          ? 'Manager Approved — Forwarded to HR'
          : 'Consideration Rejected by Manager',
        status === 'Approved'
          ? `Forwarded ${considerationId} to HR for final review and payroll decision.`
          : `Rejected ${considerationId} with reason recorded in timeline.`
      );
      return;
    }

    // Stage 2: HR Final Review (HR decides approval AND whether it affects attendance penalties / salary deductions)
    const finalStatus = status === 'Approved' ? 'APPROVED' : 'REJECTED';
    const waiveAtt =
      status === 'Approved' ? (options?.affectsAttendancePenalty ?? true) : false;
    const waiveSal =
      status === 'Approved' ? (options?.affectsSalaryDeduction ?? true) : false;

    const hrNote =
      decisionNote.trim() ||
      (status === 'Approved'
        ? `Final HR approval granted.${
            waiveAtt ? ' Attendance penalty waived.' : ' Attendance penalty retained.'
          }${waiveSal ? ' Salary deduction waived.' : ' Salary deduction unchanged.'}`
        : 'Rejected by HR as per company attendance policy.');

    setConsiderations((prev) =>
      prev.map((c) => {
        if (c.id !== considerationId) return c;
        const prevHist = c.approvalHistory || [
          {
            stage: 'SUBMITTED' as const,
            actorId: c.submittedById || c.employeeId,
            actorName: c.submittedByName,
            actorRole: c.submittedByRole,
            action: 'SUBMITTED' as const,
            note: c.reason,
            timestamp: (c.createdAt || new Date().toISOString()).slice(0, 16).replace('T', ' '),
          },
        ];
        return {
          ...c,
          status: finalStatus,
          hrApprovedBy: status === 'Approved' ? currentEmployee.fullName : c.hrApprovedBy,
          hrApprovedAt: status === 'Approved' ? nowFormatted : c.hrApprovedAt,
          hrDecisionNote: hrNote,
          rejectedBy: status === 'Rejected' ? currentEmployee.fullName : c.rejectedBy,
          rejectedByRole: status === 'Rejected' ? currentRole : c.rejectedByRole,
          rejectedAt: status === 'Rejected' ? nowFormatted : c.rejectedAt,
          rejectionReason: status === 'Rejected' ? hrNote : c.rejectionReason,
          affectsAttendancePenalty: waiveAtt,
          affectsSalaryDeduction: waiveSal,
          decisionNote: hrNote,
          decidedBy: currentEmployee.fullName,
          decisionDate: TODAY_DATE,
          approvalHistory: [
            ...prevHist,
            {
              stage: 'HR_FINAL_REVIEW',
              actorId: currentEmployee.id,
              actorName: currentEmployee.fullName,
              actorRole: currentRole,
              action: status === 'Approved' ? 'APPROVED' : 'REJECTED',
              note: `${hrNote}${
                status === 'Approved'
                  ? ` [Attendance Penalty Waived: ${waiveAtt ? 'Yes' : 'No'} | Salary Deduction Waived: ${waiveSal ? 'Yes' : 'No'}]`
                  : ''
              }`,
              timestamp: nowFormatted,
            },
          ],
        };
      })
    );

    setAttendance((prev) =>
      prev.map((a) =>
        a.employeeId === target.employeeId && a.date === target.date
          ? {
              ...a,
              considerationStatus: status,
              status: status === 'Approved' && waiveAtt ? 'Present' : a.status,
              lateMinutes: status === 'Approved' && waiveAtt ? 0 : a.lateMinutes,
              notes:
                status === 'Approved' && waiveAtt
                  ? `${a.notes} · Waived via ${considerationId}`
                  : a.notes,
            }
          : a
      )
    );

    if (status === 'Approved' && waiveSal && (target.deductionAmountSaved ?? 0) > 0) {
      setPayrolls((prev) =>
        prev.map((p) => {
          if (p.employeeId !== target.employeeId) return p;
          const newWaiver = (p.considerationAdjustment ?? 0) + (target.deductionAmountSaved ?? 0);
          const newNet = (p.netSalary ?? 0) + (target.deductionAmountSaved ?? 0);
          return {
            ...p,
            considerationAdjustment: newWaiver,
            netSalary: newNet,
          };
        })
      );
    }

    setNotifications((prev) => [
      {
        id: `NOTIF-${Date.now()}-EMP-HRCON`,
        targetRoles: [UserRole.EMPLOYEE, UserRole.MANAGER],
        targetEmployeeId: target.employeeId,
        title: `HR Final Decision: Consideration ${status} (${considerationId})`,
        message:
          status === 'Approved'
            ? `HR (${currentEmployee.fullName}) approved your consideration ${considerationId}.${
                waiveSal ? ` Salary deduction of ₹${target.deductionAmountSaved} waived.` : ''
              }`
            : `HR (${currentEmployee.fullName}) rejected consideration ${considerationId}. Reason: ${hrNote}`,
        category: 'Consideration',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'more',
        linkSubModule: 'considerations',
      },
      {
        id: `NOTIF-${Date.now()}-MGR-HRCON`,
        targetRoles: [UserRole.MANAGER],
        targetEmployeeId: target.managerId,
        title: `HR Finalized Team Consideration (${target.employeeName})`,
        message: `HR (${currentEmployee.fullName}) ${status.toLowerCase()} consideration ${considerationId} for ${target.employeeName}. Note: ${hrNote}`,
        category: 'Consideration',
        createdAt: 'Just now',
        isRead: false,
        linkModule: 'more',
        linkSubModule: 'considerations',
      },
      ...prev,
    ]);

    appendAuditLog(
      `HR Final ${status} Consideration (${considerationId})`,
      'Considerations',
      `${target.employeeName} (${target.employeeId})`,
      target.employeeId,
      `Status: ${target.status}`,
      status === 'Approved'
        ? `Approved · Att Penalty Waived: ${waiveAtt ? 'Yes' : 'No'}, Salary Waiver: ${
            waiveSal ? `₹${(target.deductionAmountSaved ?? 0).toLocaleString('en-IN')}` : 'No'
          }`
        : `Status: REJECTED (${hrNote})`
    );
    addToast(
      `HR Final Review: Consideration ${status}`,
      status === 'Approved'
        ? `Finalized ${considerationId}.${
            waiveSal
              ? ` Waived ₹${(target.deductionAmountSaved ?? 0).toLocaleString('en-IN')} payroll deduction.`
              : ' Recorded without salary deduction override.'
          }`
        : `Consideration ${considerationId} rejected. Employee and Manager notified.`
    );
  };

  // Workflow 5: Policies & Acknowledgement
  const acknowledgePolicy = (policyId: string) => {
    const target = policies.find((p) => p.id === policyId);
    if (!target) return;
    const alreadyAcked = target.acknowledgements.some(
      (a) => a.employeeId === currentEmployee.id && a.version === target.version
    );
    if (alreadyAcked) return;

    setPolicies((prev) =>
      prev.map((p) =>
        p.id === policyId
          ? {
              ...p,
              acknowledgements: [
                ...p.acknowledgements,
                {
                  employeeId: currentEmployee.id,
                  employeeName: currentEmployee.fullName,
                  version: p.version,
                  acknowledgedAt: TODAY_DATE,
                },
              ],
            }
          : p
      )
    );

    appendAuditLog(
      `Acknowledged Policy ${target.title} (${target.version})`,
      'Policies',
      `${currentEmployee.fullName} (${currentEmployee.id})`,
      currentEmployee.id,
      'Unacknowledged',
      `Acknowledged ${target.version} on ${TODAY_DATE}`
    );
    addToast('Policy Acknowledged', `Recorded your acknowledgement for ${target.title} (${target.version}).`);
  };

  const createOrUpdatePolicy = (
    policyData: Omit<CompanyPolicy, 'id' | 'versions' | 'acknowledgements'>,
    existingId?: string
  ) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can create or modify company policies.', 'error');
      return;
    }
    if (existingId) {
      setPolicies((prev) =>
        prev.map((p) =>
          p.id === existingId
            ? {
                ...p,
                ...policyData,
                versions: [
                  {
                    version: policyData.version,
                    updatedAt: TODAY_DATE,
                    summary: policyData.summary,
                    updatedBy: currentEmployee.fullName,
                  },
                  ...p.versions,
                ],
              }
            : p
        )
      );
      appendAuditLog(
        `Updated Policy ${policyData.title} to ${policyData.version}`,
        'Policies',
        policyData.title,
        undefined,
        'Previous Version',
        `${policyData.version} (${policyData.status})`
      );
      addToast('Policy Updated', `${policyData.title} updated to ${policyData.version}.`);
    } else {
      const newPol: CompanyPolicy = {
        ...policyData,
        id: `POL-00${policies.length + 1}`,
        versions: [
          {
            version: policyData.version,
            updatedAt: TODAY_DATE,
            summary: 'Initial policy release',
            updatedBy: currentEmployee.fullName,
          },
        ],
        acknowledgements: [],
      };
      setPolicies((prev) => [newPol, ...prev]);
      appendAuditLog(
        `Created Policy ${newPol.title} (${newPol.version})`,
        'Policies',
        newPol.title,
        undefined,
        'Draft',
        newPol.status
      );
      addToast('Policy Created', `${newPol.title} has been added to company policies.`);
    }
  };

  const createAnnouncement = (ann: Omit<Announcement, 'id' | 'createdBy'>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can publish company announcements.', 'error');
      return;
    }
    const newAnn: Announcement = {
      ...ann,
      id: `ANN-0${announcements.length + 1}`,
      createdBy: currentEmployee.fullName,
    };
    setAnnouncements((prev) => [newAnn, ...prev]);
    appendAuditLog(
      `Published Announcement: ${newAnn.title}`,
      'Policies',
      `Target: ${newAnn.targetAudience}`,
      undefined,
      'None',
      `Priority: ${newAnn.priority}`
    );
    addToast('Announcement Published', `Broadcasted to ${newAnn.targetAudience}.`);
  };

  // Workflow 6: Letter Generator (Strictly Admin / HR only)
  const generateAndSaveLetter = (payload: {
    employeeId: string;
    templateType: GeneratedLetter['templateType'];
    subject: string;
    content: string;
  }): GeneratedLetter => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can generate official HR letters.', 'error');
      return letters[0];
    }
    const targetEmp =
      allEmployees.find((e) => e.id === payload.employeeId) || allEmployees[0];
    const newLetter: GeneratedLetter = {
      id: `LTR-2026-0${letters.length + 1}`,
      employeeId: targetEmp.id,
      employeeName: targetEmp.fullName,
      department: targetEmp.department,
      designation: targetEmp.designation,
      templateType: payload.templateType,
      subject: payload.subject,
      content: payload.content,
      issuedDate: TODAY_DATE,
      issuedBy: currentEmployee.fullName,
    };
    setLetters((prev) => [newLetter, ...prev]);
    appendAuditLog(
      `Generated ${payload.templateType} (${newLetter.id})`,
      'Letters',
      `${targetEmp.fullName} (${targetEmp.id})`,
      targetEmp.id,
      'Template Draft',
      `Issued on ${TODAY_DATE}`
    );
    addToast(
      `${payload.templateType} Generated`,
      `Saved directly to ${targetEmp.fullName}'s profile under Letters.`
    );
    return newLetter;
  };

  // Workflow 7: Documents (Managers are strictly view-only; Employees can only upload for self; HR/Admin full access)
  const uploadEmployeeDocument = (payload: {
    employeeId: string;
    title: string;
    category: EmployeeDocument['category'];
    fileName: string;
    fileSize: string;
    expiryDate?: string;
  }) => {
    if (currentRole === UserRole.MANAGER) {
      addToast('Read-Only Access', 'Managers have view-only access to employee documents.', 'error');
      return;
    }
    if (currentRole === UserRole.EMPLOYEE && payload.employeeId && payload.employeeId !== currentEmployee.id) {
      addToast('Permission Denied', 'You can only upload documents to your own profile.', 'error');
      return;
    }
    const targetEmp =
      allEmployees.find((e) => e.id === payload.employeeId) || currentEmployee;
    const newDoc: EmployeeDocument = {
      id: `DOC-${100 + documents.length + 1}`,
      employeeId: targetEmp.id,
      employeeName: targetEmp.fullName,
      department: targetEmp.department,
      managerId: targetEmp.managerId,
      title: payload.title,
      category: payload.category,
      fileName: payload.fileName,
      fileSize: payload.fileSize,
      uploadedAt: TODAY_DATE,
      expiryDate: payload.expiryDate,
      status: currentRole === UserRole.ADMIN || currentRole === UserRole.HR ? 'Verified' : 'Pending Review',
      uploadedBy: currentEmployee.fullName,
    };
    setDocuments((prev) => [newDoc, ...prev]);
    appendAuditLog(
      `Uploaded Document: ${payload.title}`,
      'Documents',
      `${targetEmp.fullName} (${targetEmp.id})`,
      targetEmp.id,
      'None',
      payload.fileName
    );
    addToast('Document Uploaded', `${payload.title} added to ${targetEmp.fullName}'s dossier.`);
  };

  const deleteEmployeeDocument = (docId: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can delete employee documents.', 'error');
      return;
    }
    const target = documents.find((d) => d.id === docId);
    if (!target) return;
    setDocuments((prev) => prev.filter((d) => d.id !== docId));
    appendAuditLog(
      `Removed Document: ${target.title}`,
      'Documents',
      `${target.employeeName} (${target.employeeId})`,
      target.employeeId,
      target.fileName,
      'Deleted'
    );
    addToast('Document Removed', `${target.title} has been deleted.`);
  };

  const addHoliday = (holiday: Omit<HolidayRecord, 'id'>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify the holiday calendar.', 'error');
      return;
    }
    const created: HolidayRecord = {
      ...holiday,
      id: `HOL-0${holidays.length + 1}-${Date.now().toString().slice(-3)}`,
    };
    setHolidays((prev) => [...prev, created].sort((a, b) => a.date.localeCompare(b.date)));
    appendAuditLog(
      `Added Company Holiday: ${created.name} (${created.date})`,
      'Settings',
      created.name,
      undefined,
      'None',
      `${created.date} · ${created.type}`
    );
    addToast('Holiday Added', `${created.name} (${created.date}) added to company calendar.`);
  };

  const updateHoliday = (id: string, holiday: Omit<HolidayRecord, 'id'>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify the holiday calendar.', 'error');
      return;
    }
    setHolidays((prev) =>
      prev
        .map((h) => (h.id === id ? { ...holiday, id } : h))
        .sort((a, b) => a.date.localeCompare(b.date))
    );
    appendAuditLog(
      `Updated Company Holiday: ${holiday.name}`,
      'Settings',
      holiday.name,
      undefined,
      'Previous Date/Type',
      `${holiday.date} · ${holiday.type}`
    );
    addToast('Holiday Updated', `${holiday.name} (${holiday.date}) has been updated.`);
  };

  const deleteHoliday = (id: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify the holiday calendar.', 'error');
      return;
    }
    const target = holidays.find((h) => h.id === id);
    if (!target) return;
    setHolidays((prev) => prev.filter((h) => h.id !== id));
    appendAuditLog(
      `Removed Company Holiday: ${target.name}`,
      'Settings',
      target.name,
      undefined,
      target.date,
      'Deleted'
    );
    addToast('Holiday Removed', `${target.name} removed from holiday calendar.`);
  };

  const addOrUpdateCustomRule = (
    ruleData: Omit<CustomCompanyRule, 'id' | 'updatedBy'>,
    existingId?: string
  ) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify company rules.', 'error');
      return;
    }
    if (existingId) {
      setSettings((prev) => ({
        ...prev,
        customRules: prev.customRules.map((r) =>
          r.id === existingId
            ? { ...ruleData, id: existingId, updatedBy: currentEmployee.fullName }
            : r
        ),
      }));
      appendAuditLog(
        `Updated Company Rule: ${ruleData.title}`,
        'Settings',
        ruleData.title,
        undefined,
        'Previous Rule',
        `${ruleData.category} · Effective ${ruleData.effectiveFrom}`
      );
      addToast('Company Rule Updated', `${ruleData.title} has been updated.`);
    } else {
      const newRule: CustomCompanyRule = {
        ...ruleData,
        id: `RULE-${Date.now().toString().slice(-4)}`,
        updatedBy: currentEmployee.fullName,
      };
      setSettings((prev) => ({
        ...prev,
        customRules: [newRule, ...prev.customRules],
      }));
      appendAuditLog(
        `Added New Company Rule: ${newRule.title}`,
        'Settings',
        newRule.title,
        undefined,
        'None',
        `${newRule.category} · Effective ${newRule.effectiveFrom}`
      );
      addToast('New Company Rule Added', `${newRule.title} is now live in Company & Rules.`);
    }
  };

  const deleteCustomRule = (ruleId: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can delete company rules.', 'error');
      return;
    }
    const target = settings.customRules.find((r) => r.id === ruleId);
    if (!target) return;
    setSettings((prev) => ({
      ...prev,
      customRules: prev.customRules.filter((r) => r.id !== ruleId),
    }));
    appendAuditLog(
      `Removed Company Rule: ${target.title}`,
      'Settings',
      target.title,
      undefined,
      target.category,
      'Deleted'
    );
    addToast('Company Rule Deleted', `${target.title} has been removed.`);
  };

  const addDepartment = (dept: Omit<Department, 'id'>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can create departments.', 'error');
      return;
    }
    const created: Department = {
      ...dept,
      id: `DEPT-${dept.code.toUpperCase()}`,
    };
    setDepartments((prev) => [...prev, created]);
    appendAuditLog(
      `Created Department: ${created.name}`,
      'People',
      `${created.name} (${created.code})`,
      undefined,
      'None',
      `Manager: ${created.managerName}`
    );
    addToast('Department Created', `${created.name} added to organization tree.`);
  };

  const updateDepartment = (deptId: string, updates: Partial<Department>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can edit department configuration.', 'error');
      return;
    }
    const target = departments.find((d) => d.id === deptId);
    if (!target) return;
    setDepartments((prev) =>
      prev.map((d) => (d.id === deptId ? { ...d, ...updates } : d))
    );
    appendAuditLog(
      `Updated Department Details: ${target.name}`,
      'Departments',
      target.name,
      undefined,
      target.description || 'Department Record',
      Object.keys(updates).join(', ')
    );
    addToast('Department Updated', `${target.name} configuration saved.`);
  };

  const deleteDepartmentSafely = (deptId: string): { success: boolean; message: string } => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can remove departments.', 'error');
      return { success: false, message: 'Unauthorized: Admin or HR credentials required.' };
    }
    const target = departments.find((d) => d.id === deptId);
    if (!target) return { success: false, message: 'Department not found.' };

    const assignedCount = allEmployees.filter(
      (e) => e.department.toLowerCase() === target.name.toLowerCase()
    ).length;

    if (assignedCount > 0) {
      const msg = `Cannot delete department "${target.name}": ${assignedCount} employee(s) are currently assigned. Please reassign them to another department first.`;
      addToast('Deletion Blocked', msg, 'error');
      return { success: false, message: msg };
    }

    setDepartments((prev) => prev.filter((d) => d.id !== deptId));
    appendAuditLog(
      `Archived/Deleted Department: ${target.name}`,
      'Departments',
      `${target.name} (${target.code})`,
      undefined,
      target.name,
      'Archived safely with 0 active dependencies'
    );
    addToast('Department Removed', `${target.name} has been removed from organization.`);
    return { success: true, message: `Department ${target.name} removed successfully.` };
  };

  const reassignDepartmentEmployees = (fromDeptName: string, toDeptName: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can reassign department personnel.', 'error');
      return;
    }
    const affected = allEmployees.filter((e) => e.department === fromDeptName);
    if (affected.length === 0) {
      addToast('No Employees Found', `No employees currently in ${fromDeptName}.`, 'info');
      return;
    }

    setAllEmployees((prev) =>
      prev.map((e) => (e.department === fromDeptName ? { ...e, department: toDeptName } : e))
    );
    setUserAccessList((prev) =>
      prev.map((u) => (u.department === fromDeptName ? { ...u, department: toDeptName } : u))
    );

    appendAuditLog(
      `Reassigned Department Personnel (${fromDeptName} → ${toDeptName})`,
      'Departments',
      `${affected.length} Employee(s) Migrated`,
      undefined,
      fromDeptName,
      toDeptName
    );
    addToast(
      'Personnel Reassigned',
      `${affected.length} team members moved from ${fromDeptName} to ${toDeptName}.`
    );
  };

  const confirmEmployeeProbation = (employeeId: string, note = '') => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can confirm permanent employment.', 'error');
      return;
    }
    const emp = allEmployees.find((e) => e.id === employeeId);
    if (!emp) return;

    setAllEmployees((prev) =>
      prev.map((e) =>
        e.id === employeeId
          ? {
              ...e,
              employeeType: 'Permanent',
              status: 'Active',
            }
          : e
      )
    );

    appendAuditLog(
      `Confirmed Permanent Employment Status`,
      'People',
      `${emp.fullName} (${emp.id})`,
      emp.id,
      emp.employeeType || 'Probation',
      `Permanent (Confirmed by ${currentEmployee.fullName}${note ? `: ${note}` : ''})`
    );
    addToast(
      'Employment Confirmed',
      `${emp.fullName} successfully transitioned to Permanent status.`
    );
  };

  const updateUserAccess = (
    employeeId: string,
    updates: Partial<UserAccessRecord>,
    reasonNote = ''
  ) => {
    if (currentRole !== UserRole.ADMIN) {
      addToast('Permission Denied', 'Only Administrator can modify user roles and access control.', 'error');
      return;
    }

    const target = userAccessList.find((u) => u.employeeId === employeeId);
    if (!target) return;

    // Prevent self-lockout or accidental self-demotion
    if (
      employeeId === currentEmployee.id &&
      ((updates.role && updates.role !== UserRole.ADMIN) ||
        (updates.accountStatus && updates.accountStatus !== 'Active'))
    ) {
      addToast(
        'Self-Demotion Blocked',
        'Administrators cannot revoke or demote their own admin privileges to prevent system lockout.',
        'error'
      );
      return;
    }

    const previousRole = target.role;
    const newRole = updates.role || target.role;
    const previousLevel = target.accessLevel;
    const newLevel = updates.accessLevel || target.accessLevel;

    setUserAccessList((prev) =>
      prev.map((u) =>
        u.employeeId === employeeId
          ? {
              ...u,
              ...updates,
              updatedAt: `${TODAY_DATE} 12:00:00`,
              updatedBy: currentEmployee.fullName,
              adminNote: reasonNote || updates.adminNote || u.adminNote,
            }
          : u
      )
    );

    // Sync allEmployees role and status if changed
    if (updates.role || updates.accountStatus) {
      setAllEmployees((prev) =>
        prev.map((e) =>
          e.id === employeeId
            ? {
                ...e,
                role: (updates.role as UserRole) || e.role,
                status: updates.accountStatus === 'Active' ? 'Active' : ('Suspended' as any),
              }
            : e
        )
      );
    }

    appendAuditLog(
      `Updated User Access & Permissions: ${target.fullName}`,
      'Manage Access',
      `${target.fullName} (${target.employeeId})`,
      target.employeeId,
      `Role: ${previousRole} · Access: ${previousLevel}`,
      `Role: ${newRole} · Access: ${newLevel}${reasonNote ? ` (Reason: ${reasonNote})` : ''}`
    );

    addToast('Access Permissions Saved', `Permissions updated for ${target.fullName}.`);
  };

  const revokeUserAccess = (employeeId: string, reasonNote = '') => {
    if (currentRole !== UserRole.ADMIN) {
      addToast('Permission Denied', 'Only Administrator can suspend or revoke user access.', 'error');
      return;
    }
    if (employeeId === currentEmployee.id) {
      addToast('Action Blocked', 'You cannot revoke your own administrator account.', 'error');
      return;
    }
    updateUserAccess(
      employeeId,
      {
        accountStatus: 'Suspended',
        accessLevel: 'Viewer',
      },
      reasonNote || 'Administrative suspension via Manage Access Center'
    );
  };

  const createLetterTemplate = (
    template: Omit<MasterLetterTemplate, 'id' | 'version' | 'updatedAt'>
  ) => {
    if (currentRole !== UserRole.ADMIN) {
      addToast('Permission Denied', 'Only Administrator can configure official letter templates.', 'error');
      return;
    }
    const created: MasterLetterTemplate = {
      ...template,
      id: `TMPL-0${masterLetterTemplates.length + 1}`,
      version: 1,
      updatedAt: TODAY_DATE,
    };
    setMasterLetterTemplates((prev) => [created, ...prev]);
    appendAuditLog(
      `Created Letter Template: ${created.title}`,
      'Settings',
      created.title,
      undefined,
      'None',
      `Type: ${created.type} · Version: v1`
    );
    addToast('Template Created', `${created.title} added to master templates.`);
  };

  const updateLetterTemplate = (id: string, updates: Partial<MasterLetterTemplate>) => {
    if (currentRole !== UserRole.ADMIN) {
      addToast('Permission Denied', 'Only Administrator can modify letter templates.', 'error');
      return;
    }
    const target = masterLetterTemplates.find((t) => t.id === id);
    if (!target) return;

    setMasterLetterTemplates((prev) =>
      prev.map((t) =>
        t.id === id
          ? {
              ...t,
              ...updates,
              version: t.version + 1,
              updatedAt: TODAY_DATE,
            }
          : t
      )
    );
    appendAuditLog(
      `Updated Letter Template: ${target.title}`,
      'Settings',
      target.title,
      undefined,
      `v${target.version}`,
      `v${target.version + 1}`
    );
    addToast('Template Updated', `${target.title} updated to v${target.version + 1}.`);
  };

  const deleteLetterTemplate = (id: string) => {
    if (currentRole !== UserRole.ADMIN) {
      addToast('Permission Denied', 'Only Administrator can archive letter templates.', 'error');
      return;
    }
    const target = masterLetterTemplates.find((t) => t.id === id);
    if (!target) return;

    setMasterLetterTemplates((prev) => prev.filter((t) => t.id !== id));
    appendAuditLog(
      `Archived Letter Template: ${target.title}`,
      'Settings',
      target.title,
      undefined,
      target.title,
      'Archived'
    );
    addToast('Template Archived', `${target.title} removed from active templates.`);
  };

  const recordLetterHistory = (
    record: Omit<LetterHistoryRecord, 'id' | 'generatedAt' | 'exportCount'>
  ) => {
    const created: LetterHistoryRecord = {
      ...record,
      id: `LH-2026-00${letterHistory.length + 1}`,
      generatedAt: `${TODAY_DATE} ${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`,
      exportCount: 1,
      lastExportedAt: TODAY_DATE,
    };
    setLetterHistory((prev) => [created, ...prev]);
  };

  const incrementLetterExportCount = (id: string) => {
    setLetterHistory((prev) =>
      prev.map((l) =>
        l.id === id
          ? {
              ...l,
              exportCount: l.exportCount + 1,
              lastExportedAt: `${TODAY_DATE} ${new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}`,
            }
          : l
      )
    );
  };

  const addInternship = (intern: Omit<InternshipRecord, 'id'>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can manage internship records.', 'error');
      return;
    }
    const created: InternshipRecord = {
      ...intern,
      id: `INT-2026-0${internships.length + 1}`,
    };
    setInternships((prev) => [created, ...prev]);
    appendAuditLog(
      `Added Intern Record: ${created.fullName}`,
      'People',
      `${created.fullName} (${created.internCode})`,
      undefined,
      'None',
      `${created.department} · Stipend ₹${created.stipend.toLocaleString('en-IN')}`
    );
    addToast('Internship Record Created', `${created.fullName} added to ${created.department}.`);
  };

  const processMonthlyPayroll = (payrollId: string) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can approve or disburse payroll.', 'error');
      return;
    }
    const target = payrolls.find((p) => p.id === payrollId);
    if (!target) return;
    setPayrolls((prev) =>
      prev.map((p) =>
        p.id === payrollId ? { ...p, status: 'Paid', paidDate: TODAY_DATE } : p
      )
    );
    appendAuditLog(
      `Disbursed Salary & Generated Payslip (${payrollId})`,
      'Payroll',
      `${target.employeeName} (${target.employeeId})`,
      target.employeeId,
      `Status: ${target.status}`,
      `Status: Paid (₹${(target.netSalary ?? target.netPayable ?? 0).toLocaleString('en-IN')})`
    );
    addToast('Salary Marked Paid', `Payslip finalized for ${target.employeeName}.`);
  };

  const updateCompanySettings = (newSettings: Partial<CompanySettings>) => {
    if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
      addToast('Permission Denied', 'Only HR or Admin can modify HR and company settings.', 'error');
      return;
    }
    setSettings((prev) => {
      const updated = { ...prev, ...newSettings };
      return updated;
    });
    appendAuditLog(
      'Updated Company Timings, Policies & HRMS Settings',
      'Settings',
      'Global Company Settings',
      undefined,
      'Previous Configuration',
      Object.keys(newSettings).join(', ')
    );
    addToast('Company Settings Updated', 'Working hours, policies, and rules updated immediately.');
  };

  const markAllNotificationsRead = () => {
    setNotifications((prev) => prev.map((n) => ({ ...n, isRead: true })));
  };

  const markNotificationRead = (id: string) => {
    setNotifications((prev) =>
      prev.map((n) => (n.id === id ? { ...n, isRead: true } : n))
    );
  };

  // Normalized reactive view adapters for modules
  const currentUser = useMemo(
    () => ({
      id: currentEmployee.id,
      employeeId: currentEmployee.id,
      employeeCode: currentEmployee.id,
      fullName: currentEmployee.fullName,
      email: currentEmployee.email,
      role: currentRole as any,
      department: currentEmployee.department,
      designation: currentEmployee.designation,
    }),
    [currentEmployee, currentRole]
  );

  const permissions = useMemo(() => {
    const isHRAdmin = currentRole === UserRole.HR || currentRole === UserRole.ADMIN;
    const isManager = currentRole === UserRole.MANAGER;
    return {
      People: {
        scope: isHRAdmin ? 'ALL' : isManager ? 'TEAM' : 'SELF',
        actions: isHRAdmin ? ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'APPROVE'] : ['VIEW'],
      },
      Attendance: {
        scope: isHRAdmin ? 'ALL' : isManager ? 'TEAM' : 'SELF',
        actions: isHRAdmin ? ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'APPROVE'] : ['VIEW'],
      },
      Leave: {
        scope: isHRAdmin ? 'ALL' : isManager ? 'TEAM' : 'SELF',
        actions: isHRAdmin
          ? ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'APPROVE']
          : isManager
          ? ['VIEW', 'CREATE', 'APPROVE']
          : ['VIEW', 'CREATE'],
      },
      Payroll: {
        scope: isHRAdmin ? 'ALL' : isManager ? 'TEAM' : 'SELF',
        actions: isHRAdmin ? ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'APPROVE'] : ['VIEW'],
      },
      Considerations: {
        scope: isHRAdmin ? 'ALL' : isManager ? 'TEAM' : 'SELF',
        actions: isHRAdmin
          ? ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'APPROVE']
          : isManager
          ? ['VIEW', 'CREATE', 'APPROVE']
          : ['VIEW', 'CREATE'],
      },
      Documents: {
        scope: isHRAdmin ? 'ALL' : isManager ? 'TEAM' : 'SELF',
        actions: isHRAdmin
          ? ['VIEW', 'CREATE', 'EDIT', 'DELETE', 'APPROVE']
          : isManager
          ? ['VIEW']
          : ['VIEW', 'CREATE'],
      },
    };
  }, [currentRole]);

  const companyTiming = useMemo(() => {
    const [fhStart = '09:30', fhEnd = '14:00'] = (settings.firstHalfTiming || '09:30 - 14:00')
      .split('-')
      .map((s) => s.trim());
    const [shStart = '14:00', shEnd = '18:30'] = (settings.secondHalfTiming || '14:00 - 18:30')
      .split('-')
      .map((s) => s.trim());
    return {
      workingStartTime: settings.workStartTime || '09:30',
      workingEndTime: settings.workEndTime || '18:30',
      gracePeriodMinutes: settings.gracePeriodMinutes ?? 15,
      fullDayHours: settings.fullDayHoursThreshold ?? 8.5,
      minHalfDayHours: settings.halfDayHoursThreshold ?? 4.25,
      firstHalfStart: fhStart,
      firstHalfEnd: fhEnd,
      secondHalfStart: shStart,
      secondHalfEnd: shEnd,
      lunchBreakWindow: settings.lunchBreakWindow || '13:30 – 14:15 (45 Mins)',
      latePenaltyThresholdCount: settings.lateArrivalThresholdCount ?? 3,
      latePenaltyDeductionDays: 0.5,
      weeklyOffDays: 'Sunday (Fixed Weekly Off)',
      saturdayRule: 'Working Saturday (10:00 – 16:30 Atelier & Dispatch Schedule)',
    };
  }, [settings]);

  const normalizedEmployees = useMemo(
    () =>
      scopedEmployees.map((e) => {
        const grossMonthly =
          (e.salary?.baseSalary || 0) +
          (e.salary?.hra || 0) +
          (e.salary?.specialAllowance || 0);
        return {
          ...e,
          employeeCode: e.id,
          managerId: e.managerId,
          reportingManager: e.managerName || 'Chaitanya Katare',
          status:
            e.status === 'OnNotice'
              ? 'ON_NOTICE'
              : e.status === 'Inactive'
              ? 'ON_LEAVE'
              : 'ACTIVE',
          annualCTC: grossMonthly * 12,
          bankAccount: `${e.bankName} •••• ${(e.bankAccountNumber || '1001').slice(-4)}`,
        };
      }),
    [scopedEmployees]
  );

  const normalizedLeaves = useMemo(
    () =>
      scopedLeaves.map((l) => ({
        ...l,
        leaveType: (l.leaveType || 'CASUAL').toString().toUpperCase(),
        appliedOn: (l.createdAt || TODAY_DATE).slice(0, 10),
        halfDaySession: !l.isHalfDay
          ? 'FULL_DAY'
          : l.halfDaySession?.toString().includes('Second') || l.halfDaySession === 'SECOND_HALF'
          ? 'SECOND_HALF'
          : 'FIRST_HALF',
        status:
          l.status === 'Approved' || l.status === 'APPROVED'
            ? 'APPROVED'
            : l.status === 'Rejected' || l.status === 'REJECTED'
            ? 'REJECTED'
            : l.status === 'PENDING_HR' || (l.status as string) === 'Pending HR'
            ? 'PENDING_HR'
            : 'PENDING_MANAGER',
        hrApprovedBy:
          l.hrApprovedBy ||
          (l.status === 'Approved' || l.status === 'APPROVED' ? l.decidedBy : undefined),
      })),
    [scopedLeaves]
  );

  const normalizedAttendance = useMemo(
    () =>
      scopedAttendance.map((a) => ({
        ...a,
        punchIn: a.checkIn,
        punchOut: a.checkOut,
        workHours: a.workingHours,
        totalHours: a.workingHours,
        lateByMinutes: a.lateMinutes || 0,
        status:
          a.status === 'Late' || a.status === 'LATE'
            ? 'LATE'
            : a.status === 'Half Day' || a.status === 'HALF_DAY'
            ? 'HALF_DAY'
            : a.status === 'On Leave' || a.status === 'ON_LEAVE'
            ? 'ON_LEAVE'
            : a.status === 'Absent' || a.status === 'ABSENT'
            ? 'ABSENT'
            : 'PRESENT',
        regularizationStatus:
          a.considerationStatus === 'Pending'
            ? 'PENDING'
            : a.considerationStatus === 'Approved'
            ? 'APPROVED'
            : a.considerationStatus === 'Rejected'
            ? 'REJECTED'
            : 'NONE',
      })),
    [scopedAttendance]
  );

  const normalizedPayrolls = useMemo(
    () =>
      scopedPayrolls.map((p) => {
        const gross = (p.baseSalary || 0) + (p.hra || 0) + (p.specialAllowance || 0);
        return {
          ...p,
          employeeCode: p.employeeId,
          paidDays: (p.presentDays || 26) + (p.paidLeaveDays || 0),
          lopDays: p.unpaidLeaveDays || 0,
          basicPay: p.baseSalary || 0,
          grossMonthly: gross,
          tdsDeduction: p.taxDeduction || 0,
          latePenaltyDeduction: p.attendanceDeduction || 0,
          netPayable: p.netSalary || 0,
          status:
            p.status === 'Paid' || p.status === 'DISBURSED'
              ? 'DISBURSED'
              : p.status === 'Draft' || p.status === 'DRAFT'
              ? 'DRAFT'
              : 'PROCESSED',
        };
      }),
    [scopedPayrolls]
  );

  const normalizedConsiderations = useMemo(
    () =>
      scopedConsiderations.map((c: any) => ({
        ...c,
        type: c.type || 'Late Arrival Waiver',
        category: c.category || c.type || 'Late Arrival Waiver',
        title: c.title || `${c.type} — ${c.employeeName}`,
        description: c.description || c.reason || '',
        reason: c.reason || c.description || '',
        supportingNote: c.supportingNote || '',
        submittedAt: (c.createdAt || c.date || TODAY_DATE).slice(0, 10),
        raisedBy: c.raisedBy || c.submittedByName || 'Chaitanya Katare',
        raisedByRole: c.raisedByRole || c.submittedByRole || 'EMPLOYEE',
        severityOrImpact: c.severityOrImpact || 'HIGH',
        status:
          c.status === 'Approved' || c.status === 'APPROVED' || c.status === 'ACKNOWLEDGED'
            ? 'APPROVED'
            : c.status === 'Rejected' || c.status === 'REJECTED' || c.status === 'ARCHIVED'
            ? 'REJECTED'
            : c.status === 'PENDING_HR' || c.status === 'Pending HR'
            ? 'PENDING_HR'
            : 'PENDING_MANAGER',
      })),
    [scopedConsiderations]
  );

  const normalizedDocuments = useMemo(
    () =>
      scopedDocuments.map((d: any) => ({
        ...d,
        category: d.category ? d.category.toString().toUpperCase().replace(/\s+/g, '_') : 'KYC',
        uploadedOn: d.uploadedOn || d.uploadedAt || TODAY_DATE,
        verified: d.status === 'Verified' || d.status === 'VERIFIED',
        status:
          d.status === 'Verified' || d.status === 'VERIFIED'
            ? 'VERIFIED'
            : d.status === 'REJECTED'
            ? 'REJECTED'
            : 'PENDING_VERIFICATION',
      })),
    [scopedDocuments]
  );

  const normalizedHolidays = useMemo(
    () =>
      holidays.map((h: any) => ({
        ...h,
        day: h.day || h.dayOfWeek || 'Monday',
        type:
          h.type === 'National' || h.type === 'NATIONAL'
            ? 'NATIONAL'
            : h.type === 'Company Special' || h.type === 'COMPANY_SPECIAL'
            ? 'COMPANY_SPECIAL'
            : 'FESTIVAL',
        applicableBranches: h.applicableBranches || h.applicableLocations || 'All Argos Watch Locations',
        isPaid: h.isPaid ?? true,
      })),
    [holidays]
  );

  const normalizedPolicies = useMemo(
    () =>
      policies.map((p: any) => ({
        ...p,
        category: (p.category || 'ATTENDANCE').toString().toUpperCase(),
        mandatoryAck: p.requiresAcknowledgement ?? true,
        acknowledgedByMe:
          p.acknowledgedByMe ??
          (Array.isArray(p.acknowledgements) &&
            p.acknowledgements.some((a: any) => a.employeeId === currentEmployee.id)),
      })),
    [policies, currentEmployee.id]
  );

  const normalizedAnnouncements = useMemo(
    () =>
      announcements.map((a: any) => ({
        ...a,
        category: a.category || 'COMPANY_NEWS',
        date: a.date || a.publishDate || TODAY_DATE,
        author: a.author || a.createdBy || 'Chaitanya Katare',
        authorRole: a.authorRole || 'Head of People : Performance & Culture',
        content: a.content || a.description || '',
        pinned: a.pinned ?? a.priority === 'Important',
      })),
    [announcements]
  );

  const myTodayRecord = useMemo(
    () => attendance.find((a) => a.employeeId === currentEmployee.id && a.date === TODAY_DATE),
    [attendance, currentEmployee.id]
  );
  const isClockedIn = !!(myTodayRecord && myTodayRecord.checkIn && !myTodayRecord.checkOut);
  const clockInTime = myTodayRecord?.checkIn || '09:30';

  const toggleClockIn = () => {
    if (isClockedIn) {
      checkOutToday();
    } else {
      checkInToday();
    }
  };

  return (
    <HRMSContext.Provider
      value={{
        firebaseUser,
        authLoading,
        currentRole,
        currentEmployee,
        switchRolePersona,
        switchEmployeePersona,
        signInWithGoogle,
        signOutUser,
        activeModule,
        activeSubModule,
        selectedEmployeeId,
        reportPreset,
        navigateTo,
        openEmployeeProfile,
        allEmployees,
        scopedEmployees,
        departments,
        scopedAttendance,
        scopedLeaves,
        scopedConsiderations,
        scopedPayrolls,
        scopedDocuments,
        scopedLetters,
        scopedPolicies,
        scopedAnnouncements,
        internships,
        holidays: normalizedHolidays as any,
        notifications,
        scopedActivityLogs,
        settings,
        companySettings: settings,
        checkInToday,
        checkOutToday,
        logOrUpdateAttendanceForEmployee: (payload: any) => {
          logOrUpdateAttendanceForEmployee({
            employeeId: payload.employeeId,
            date: payload.date,
            checkIn: payload.checkIn || payload.punchIn || '09:30',
            checkOut: payload.checkOut || payload.punchOut || '18:30',
            status:
              payload.status === 'LATE'
                ? 'Late'
                : payload.status === 'HALF_DAY'
                ? 'Half Day'
                : payload.status === 'ON_LEAVE'
                ? 'On Leave'
                : payload.status === 'ABSENT'
                ? 'Absent'
                : payload.status || 'Present',
            notes: payload.notes || '',
          });
        },
        addNewEmployee,
        updateEmployeeStatus,
        archiveEmployee,
        deactivateEmployee,
        restoreEmployee,
        initiateFinalExit,
        updateNoticePeriod,
        applyLeave: (payload: any) => {
          const normType =
            payload.leaveType === 'SICK'
              ? 'Sick'
              : payload.leaveType === 'EARNED'
              ? 'Earned'
              : payload.leaveType === 'UNPAID'
              ? 'Unpaid'
              : 'Casual';
          const normSession =
            payload.halfDaySession === 'SECOND_HALF'
              ? 'Second Half (14:00 - 18:30)'
              : payload.halfDaySession === 'FIRST_HALF'
              ? 'First Half (09:30 - 14:00)'
              : payload.halfDaySession;
          applyLeave({
            ...payload,
            leaveType: normType,
            halfDaySession: normSession,
          });
        },
        decideLeave,
        submitConsideration,
        decideConsideration,
        acknowledgePolicy,
        createOrUpdatePolicy,
        createAnnouncement: (ann: any) => {
          createAnnouncement({
            title: ann.title,
            description: ann.description || ann.content || '',
            priority: ann.priority || (ann.pinned ? 'Important' : 'Normal'),
            publishDate: ann.publishDate || TODAY_DATE,
            expiryDate: ann.expiryDate || '2026-12-31',
            targetAudience: ann.targetAudience || 'Everyone',
          });
        },
        generateAndSaveLetter,
        uploadEmployeeDocument,
        deleteEmployeeDocument,
        addHoliday,
        updateHoliday: (id: string, hol: any) => {
          setHolidays((prev) =>
            prev.map((h) =>
              h.id === id
                ? {
                    ...h,
                    ...hol,
                    dayOfWeek: hol.dayOfWeek || hol.day || h.dayOfWeek,
                    applicableLocations:
                      hol.applicableLocations || hol.applicableBranches || h.applicableLocations,
                  }
                : h
            )
          );
          addToast('Holiday Updated', 'Company holiday calendar updated.');
        },
        deleteHoliday,
        addOrUpdateCustomRule,
        deleteCustomRule,
        addDepartment,
        updateDepartment,
        deleteDepartmentSafely,
        reassignDepartmentEmployees,
        confirmEmployeeProbation,
        userAccessList,
        updateUserAccess,
        revokeUserAccess,
        masterLetterTemplates,
        letterHistory,
        createLetterTemplate,
        updateLetterTemplate,
        deleteLetterTemplate,
        recordLetterHistory,
        incrementLetterExportCount,
        addInternship,
        processMonthlyPayroll: (id?: string) => {
          if (id) {
            processMonthlyPayroll(id);
          } else {
            setPayrolls((prev) =>
              prev.map((p) => ({ ...p, status: 'Paid', paidDate: TODAY_DATE }))
            );
            addToast('Monthly Payroll Disbursed', 'All Argos Watch payslips marked as Paid.');
          }
        },
        updateCompanySettings,
        markAllNotificationsRead,
        markNotificationRead,
        toasts,
        addToast,
        dismissToast,

        // Normalized properties for modules
        currentUser,
        permissions,
        companyTiming,
        employees: normalizedEmployees,
        leaves: normalizedLeaves,
        attendance: normalizedAttendance,
        payroll: normalizedPayrolls,
        considerations: normalizedConsiderations,
        documents: normalizedDocuments,
        policies: normalizedPolicies,
        announcements: normalizedAnnouncements,
        auditLogs: scopedActivityLogs,
        setActiveModule: (mod: PrimaryModuleId) => navigateTo(mod),
        activeSecondaryModule: activeSubModule,
        setActiveSecondaryModule: (sub: any) => setActiveSubModule(sub),
        isClockedIn,
        clockInTime,
        toggleClockIn,
        liveWorkingSeconds,
        liveWorkingDuration,
        myLeaves: leaves.filter((l) => l.employeeId === currentEmployee.id),
        myAttendance: attendance.filter((a) => a.employeeId === currentEmployee.id),
        myConsiderations: considerations.filter((c) => c.employeeId === currentEmployee.id),
        teamLeaves: leaves.filter((l) => l.managerId === currentEmployee.id),
        teamAttendance: attendance.filter((a) => a.managerId === currentEmployee.id),
        teamConsiderations: considerations.filter((c) => c.managerId === currentEmployee.id),

        // Normalized CRUD handlers (with Strict Read-Only Guards for Manager & Employee)
        createEmployee: (emp: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can create employee records.', 'error');
            return;
          }
          const monthlyGross = Math.round((Number(emp.annualCTC) || 900000) / 12);
          const empType = emp.employeeType || emp.employmentType || 'Probation';
          addNewEmployee(
            {
              fullName: emp.fullName,
              email: emp.officialEmail || emp.email,
              personalEmail: emp.personalEmail || emp.email,
              officialEmail: emp.officialEmail || emp.email,
              phone: emp.phone || emp.mobileNumber || '+91 98201 00000',
              role: (emp.role as UserRole) || UserRole.EMPLOYEE,
              designation: emp.designation || 'Staff',
              department: emp.department || 'Operations & Development',
              managerId: emp.managerId || 'EMP-1001',
              managerName: emp.reportingManager || 'Chaitanya Katare',
              status: emp.status || 'Active',
              employmentType: empType,
              employeeType: empType,
              location: emp.location || emp.workLocation || 'Main Atelier & HQ',
              joiningDate: emp.joiningDate || TODAY_DATE,
              probationEndDate: emp.probationEndDate || '2026-12-31',
              probationDurationMonths: emp.probationDurationMonths || 3,
              dob: emp.dob || '1995-06-15',
              gender: emp.gender || 'Male',
              address: emp.address || 'Surat, Gujarat',
              structuredAddress: emp.structuredAddress,
              permanentAddress: emp.permanentAddress,
              emergencyContactName: emp.emergencyContactName || 'Family Contact',
              emergencyContactPhone: emp.emergencyContactPhone || '+91 98201 11111',
              avatarUrl: emp.profilePhotoUrl || '',
              bankName: emp.bankName || 'HDFC Bank',
              bankAccountNumber: emp.bankAccount || emp.bankAccountNumber || '50100991122',
              ifscCode: emp.ifscCode || 'HDFC0001234',
              panNumber: emp.panNumber || 'ARGPK1000A',
              aadhaarNumber: emp.aadhaarNumber,
              uanNumber: emp.uanNumber,
              education: emp.education || [],
              experience: emp.experience || [],
              salary: {
                baseSalary: Math.round(monthlyGross * 0.5),
                hra: Math.round(monthlyGross * 0.3),
                specialAllowance: Math.round(monthlyGross * 0.2),
                pfDeduction: 1800,
                taxDeduction: 2500,
                professionalTax: 200,
              },
            },
            true
          );
        },
        updateEmployee: (id: string, updates: any) => {
          const isHRAdmin = currentRole === UserRole.ADMIN || currentRole === UserRole.HR;
          const isSelf = id === currentEmployee.id;

          if (!isHRAdmin && !isSelf) {
            addToast('Permission Denied', 'You can only view or update your own personal information.', 'error');
            return;
          }

          if (!isHRAdmin) {
            if (updates.role || updates.designation || updates.department || updates.salary || updates.annualCTC || updates.employeeType) {
              addToast('Permission Denied', 'Restricted employment fields can only be modified by HR or Admin.', 'error');
              return;
            }
          }

          const target = allEmployees.find((e) => e.id === id);
          const prevDesignation = target?.designation || '';
          const prevDept = target?.department || '';

          const updatedList = allEmployees.map((e) => {
            if (e.id !== id) return e;
            const monthlyGross = updates.annualCTC
              ? Math.round(Number(updates.annualCTC) / 12)
              : e.salary.baseSalary + e.salary.hra + e.salary.specialAllowance;
            return {
              ...e,
              fullName: isHRAdmin ? (updates.fullName ?? e.fullName) : e.fullName,
              email: isHRAdmin ? (updates.officialEmail ?? updates.email ?? e.email) : e.email,
              officialEmail: isHRAdmin ? (updates.officialEmail ?? updates.email ?? e.officialEmail) : e.officialEmail,
              personalEmail: updates.personalEmail ?? e.personalEmail,
              phone: updates.phone ?? updates.mobileNumber ?? e.phone,
              department: isHRAdmin ? (updates.department ?? e.department) : e.department,
              designation: isHRAdmin ? (updates.designation ?? e.designation) : e.designation,
              role: isHRAdmin ? ((updates.role as UserRole) ?? e.role) : e.role,
              status: isHRAdmin ? (updates.status ?? e.status) : e.status,
              employmentType: isHRAdmin ? (updates.employeeType ?? updates.employmentType ?? e.employmentType) : e.employmentType,
              employeeType: isHRAdmin ? (updates.employeeType ?? updates.employmentType ?? e.employeeType) : e.employeeType,
              address: updates.address ?? e.address,
              structuredAddress: updates.structuredAddress ?? e.structuredAddress,
              permanentAddress: updates.permanentAddress ?? e.permanentAddress,
              dob: updates.dob ?? e.dob,
              gender: updates.gender ?? e.gender,
              bankName: updates.bankName ?? e.bankName,
              bankAccountNumber: updates.bankAccount ?? updates.bankAccountNumber ?? e.bankAccountNumber,
              ifscCode: updates.ifscCode ?? e.ifscCode,
              panNumber: updates.panNumber ?? e.panNumber,
              aadhaarNumber: updates.aadhaarNumber ?? e.aadhaarNumber,
              uanNumber: updates.uanNumber ?? e.uanNumber,
              emergencyContactName: updates.emergencyContactName ?? e.emergencyContactName,
              emergencyContactPhone: updates.emergencyContactPhone ?? e.emergencyContactPhone,
              managerName: isHRAdmin ? (updates.reportingManager ?? updates.managerName ?? e.managerName) : e.managerName,
              managerId: isHRAdmin ? (updates.managerId ?? e.managerId) : e.managerId,
              joiningDate: isHRAdmin ? (updates.joiningDate ?? e.joiningDate) : e.joiningDate,
              probationEndDate: isHRAdmin ? (updates.probationEndDate ?? e.probationEndDate) : e.probationEndDate,
              salary: isHRAdmin && updates.salary
                ? { ...e.salary, ...updates.salary }
                : isHRAdmin && updates.annualCTC
                ? {
                    ...e.salary,
                    baseSalary: Math.round(monthlyGross * 0.5),
                    hra: Math.round(monthlyGross * 0.3),
                    specialAllowance: Math.round(monthlyGross * 0.2),
                  }
                : e.salary,
            };
          });

          setAllEmployees(updatedList);
          localStorage.setItem('hrms_persisted_employees', JSON.stringify(updatedList));

          appendAuditLog(
            `Updated employee details: ${target?.fullName || id}`,
            'People',
            `${target?.fullName || id} (${id})`,
            id,
            `${prevDesignation} (${prevDept})`,
            `${updates.designation || prevDesignation} (${updates.department || prevDept})`
          );

          addToast('Employee Updated', `${target?.fullName || id} profile saved successfully.`);
        },
        deleteEmployee: (id: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can remove employee records.', 'error');
            return;
          }
          // Soft-delete/archival as requested by requirement 1 to preserve payroll, attendance & leave history
          archiveEmployee(id, 'Archived via People Directory');
        },
        logManualAttendance,
        approveLeave: (id: string, note = '') =>
          decideLeave(id, 'Approved', note || 'Approved via Leave Desk'),
        rejectLeave: (id: string, reason = '') =>
          decideLeave(id, 'Rejected', reason || 'Rejected due to operational shift requirements'),
        updateLeave: (id: string, updates: any) => {
          const target = leaves.find((l) => l.id === id);
          if (
            currentRole !== UserRole.ADMIN &&
            currentRole !== UserRole.HR &&
            (!target || target.employeeId !== currentEmployee.id)
          ) {
            addToast('Permission Denied', 'You cannot modify another employee’s leave.', 'error');
            return;
          }
          setLeaves((prev) =>
            prev.map((l) => (l.id === id ? { ...l, ...updates } : l))
          );
          addToast('Leave Updated', 'Leave request updated.');
        },
        deleteLeave: (id: string) => {
          const target = leaves.find((l) => l.id === id);
          if (
            currentRole !== UserRole.ADMIN &&
            currentRole !== UserRole.HR &&
            (!target || target.employeeId !== currentEmployee.id)
          ) {
            addToast('Permission Denied', 'You cannot delete another employee’s leave.', 'error');
            return;
          }
          setLeaves((prev) => prev.filter((l) => l.id !== id));
          addToast('Leave Deleted', 'Leave entry removed.');
        },
        updateAttendanceRecord: (id: string, updates: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can edit attendance records.', 'error');
            return;
          }
          setAttendance((prev) =>
            prev.map((a) =>
              a.id === id
                ? {
                    ...a,
                    ...updates,
                    checkIn: updates.punchIn !== undefined ? updates.punchIn : a.checkIn,
                    checkOut: updates.punchOut !== undefined ? updates.punchOut : a.checkOut,
                    lateMinutes:
                      updates.lateByMinutes !== undefined ? updates.lateByMinutes : a.lateMinutes,
                  }
                : a
            )
          );
          addToast('Attendance Log Updated', 'Shift log updated.');
        },
        deleteAttendanceRecord: (id: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can delete attendance records.', 'error');
            return;
          }
          setAttendance((prev) => prev.filter((a) => a.id !== id));
          addToast('Attendance Log Deleted', 'Shift log removed.');
        },
        submitRegularization: (id: string, reasonText: string) => {
          setAttendance((prev) =>
            prev.map((a) =>
              a.id === id
                ? { ...a, considerationStatus: 'Pending', notes: reasonText }
                : a
            )
          );
          addToast('Regularization Requested', 'Sent to Manager / HR for approval.');
        },
        approveRegularization: (id: string, approve: boolean) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can directly regularize attendance.', 'error');
            return;
          }
          setAttendance((prev) =>
            prev.map((a) =>
              a.id === id
                ? {
                    ...a,
                    considerationStatus: approve ? 'Approved' : 'Rejected',
                    status: approve ? 'Present' : a.status,
                    lateMinutes: approve ? 0 : a.lateMinutes,
                  }
                : a
            )
          );
          addToast(
            approve ? 'Regularization Approved' : 'Regularization Rejected',
            'Attendance log updated.'
          );
        },
        updatePayrollRecord: (id: string, updates: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can edit payroll records.', 'error');
            return;
          }
          setPayrolls((prev) =>
            prev.map((p) =>
              p.id === id
                ? {
                    ...p,
                    ...updates,
                    netSalary: updates.netPayable ?? p.netSalary,
                    taxDeduction: updates.tdsDeduction ?? p.taxDeduction,
                    attendanceDeduction: updates.latePenaltyDeduction ?? p.attendanceDeduction,
                  }
                : p
            )
          );
          addToast('Payroll Record Updated', 'Salary computation adjusted.');
        },
        deletePayrollRecord: (id: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can delete payroll records.', 'error');
            return;
          }
          setPayrolls((prev) => prev.filter((p) => p.id !== id));
          addToast('Payroll Entry Removed', 'Payroll record deleted.');
        },
        createConsideration: (c: any) => {
          submitConsideration({
            employeeId: c.employeeId || currentEmployee.id,
            date: c.date || TODAY_DATE,
            type: c.type || 'Late Arrival Waiver',
            title: c.title,
            category: c.category || c.type,
            reason: c.reason || c.description || '',
            supportingNote: c.supportingNote || '',
            supportingDocument: c.supportingDocument || 'Supporting_Attestation.pdf',
            forwardToHRImmediately: c.forwardToHRImmediately,
          });
        },
        updateConsideration: (id: string, updates: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can edit consideration records.', 'error');
            return;
          }
          setConsiderations((prev) =>
            prev.map((c) => (c.id === id ? { ...c, ...updates } : c))
          );
          addToast('Consideration Updated', 'Case record updated.');
        },
        deleteConsideration: (id: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can delete consideration records.', 'error');
            return;
          }
          setConsiderations((prev) => prev.filter((c) => c.id !== id));
          addToast('Consideration Deleted', 'Case record removed.');
        },
        reviewConsideration: (
          id: string,
          status: string,
          note = '',
          options?: { affectsAttendancePenalty?: boolean; affectsSalaryDeduction?: boolean }
        ) => {
          const isApprove =
            status === 'ACKNOWLEDGED' || status === 'APPROVED' || status === 'Approved';
          decideConsideration(
            id,
            isApprove ? 'Approved' : 'Rejected',
            note || (isApprove ? `Reviewed & approved by ${currentEmployee.fullName}` : ''),
            options
          );
        },
        uploadDocument: (d: any) => {
          uploadEmployeeDocument({
            employeeId: d.employeeId,
            title: d.title,
            category: (d.category as any) || 'Identity',
            fileName: `${d.title.toLowerCase().replace(/\s+/g, '_')}.pdf`,
            fileSize: d.fileSize || '1.2 MB',
          });
        },
        updateDocument: (id: string, updates: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can modify document metadata.', 'error');
            return;
          }
          setDocuments((prev) =>
            prev.map((d) => (d.id === id ? { ...d, ...updates } : d))
          );
          addToast('Document Updated', 'Vault metadata saved.');
        },
        deleteDocument: (id: string) => deleteEmployeeDocument(id),
        verifyDocument: (id: string, status: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can verify documents.', 'error');
            return;
          }
          setDocuments((prev) =>
            prev.map((d) =>
              d.id === id
                ? { ...d, status: status === 'VERIFIED' ? 'Verified' : ('Rejected' as any) }
                : d
            )
          );
          addToast('Document Verification Updated', `Marked as ${status}.`);
        },
        createHoliday: (h: any) => {
          addHoliday({
            name: h.name,
            date: h.date,
            dayOfWeek: h.day || h.dayOfWeek || 'Friday',
            type:
              h.type === 'NATIONAL'
                ? 'National'
                : h.type === 'COMPANY_SPECIAL'
                ? 'Company Special'
                : 'Regional',
            applicableLocations: h.applicableBranches || 'All Argos Watch Locations',
          });
        },
        createPolicy: (p: any) => {
          createOrUpdatePolicy({
            title: p.title,
            category: (p.category as any) || 'Attendance',
            version: p.version || 'v1.0',
            status: 'Active',
            effectiveDate: p.effectiveDate || TODAY_DATE,
            targetDepartment: 'All Departments',
            requiresAcknowledgement: p.mandatoryAck ?? true,
            summary: p.summary,
            content: p.summary,
          });
        },
        updatePolicy: (id: string, updates: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can modify company policies.', 'error');
            return;
          }
          setPolicies((prev) =>
            prev.map((p) => (p.id === id ? { ...p, ...updates } : p))
          );
          addToast('Policy Updated', 'Company policy charter updated.');
        },
        deletePolicy: (id: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can delete company policies.', 'error');
            return;
          }
          setPolicies((prev) => prev.filter((p) => p.id !== id));
          addToast('Policy Deleted', 'Policy removed.');
        },
        updateAnnouncement: (id: string, updates: any) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can modify announcements.', 'error');
            return;
          }
          setAnnouncements((prev) =>
            prev.map((a) =>
              a.id === id
                ? { ...a, ...updates, description: updates.content ?? a.description }
                : a
            )
          );
          addToast('Broadcast Updated', 'Announcement updated.');
        },
        deleteAnnouncement: (id: string) => {
          if (currentRole !== UserRole.ADMIN && currentRole !== UserRole.HR) {
            addToast('Permission Denied', 'Only HR or Admin can delete announcements.', 'error');
            return;
          }
          setAnnouncements((prev) => prev.filter((a) => a.id !== id));
          addToast('Broadcast Deleted', 'Announcement removed.');
        },
        theme,
        setTheme,
        language,
        setLanguage,
        t,
        appLockEnabled,
        isAppLocked,
        lockTimeoutMinutes,
        setLockTimeoutMinutes,
        setAppLockEnabled,
        changeAppLockPin,
        unlockApp,
        lockAppNow,
        resetAppLockWithIdentity,
      }}
    >
      {children}
    </HRMSContext.Provider>
  );
};

export const useHRMS = (): HRMSContextValue => {
  const ctx = useContext(HRMSContext);
  if (!ctx) {
    throw new Error('useHRMS must be used within an HRMSProvider');
  }
  return ctx;
};
