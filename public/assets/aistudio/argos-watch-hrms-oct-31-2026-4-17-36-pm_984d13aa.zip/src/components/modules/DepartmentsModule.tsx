import React, { useState, useMemo } from 'react';
import {
  Building2,
  Users,
  Plus,
  Edit3,
  Trash2,
  Search,
  UserCheck,
  ArrowRightLeft,
  AlertTriangle,
  FolderTree,
  ChevronDown,
  ChevronRight,
  ShieldAlert,
  Download,
  DollarSign,
  MapPin,
  FileText,
} from 'lucide-react';
import { useHRMS } from '../../context/HRMSContext';
import { Department, UserRole } from '../../types/hrms';
import {
  AvatarInitials,
  ModalShell,
  ExportDropdown,
} from '../ui/EnterpriseComponents';
import { exportTableToCSV, exportTableToJSON } from '../../lib/exportUtils';

export function DepartmentsModule() {
  const {
    currentRole,
    currentUser,
    departments,
    allEmployees,
    addDepartment,
    updateDepartment,
    deleteDepartmentSafely,
    reassignDepartmentEmployees,
    addToast,
  } = useHRMS();

  const isAuthorized =
    currentRole === UserRole.ADMIN || currentRole === UserRole.HR;

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');

  // Add / Edit Department Modal
  const [showAddEditModal, setShowAddEditModal] = useState(false);
  const [editingDept, setEditingDept] = useState<Department | null>(null);
  const [name, setName] = useState('');
  const [code, setCode] = useState('');
  const [managerId, setManagerId] = useState('');

  // Safe Deletion & Resolution State
  const [deletingDept, setDeletingDept] = useState<Department | null>(null);
  const [reassignTargetDept, setReassignTargetDept] = useState('');

  // Direct Reassign Employees Wizard
  const [showReassignModal, setShowReassignModal] = useState(false);
  const [reassignSourceDept, setReassignSourceDept] = useState('');
  const [reassignDestinationDept, setReassignDestinationDept] = useState('');

  // Expanded Department Cards
  const [expandedDeptId, setExpandedDeptId] = useState<string | null>(null);

  // Calculate headcount and members map
  const departmentStats = useMemo(() => {
    const stats: Record<
      string,
      {
        count: number;
        members: typeof allEmployees;
        manager: typeof allEmployees[0] | undefined;
      }
    > = {};

    departments.forEach((dept) => {
      const members = allEmployees.filter(
        (e) => e.department.toLowerCase() === dept.name.toLowerCase()
      );
      const manager =
        allEmployees.find((e) => e.id === dept.managerId) ||
        allEmployees.find((e) => e.fullName === dept.managerName);

      stats[dept.id] = {
        count: members.length,
        members,
        manager,
      };
    });

    return stats;
  }, [departments, allEmployees]);

  // Filtered Departments
  const filteredDepartments = useMemo(() => {
    if (!searchQuery.trim()) return departments;
    const q = searchQuery.toLowerCase();
    return departments.filter(
      (d) =>
        d.name.toLowerCase().includes(q) ||
        d.code.toLowerCase().includes(q) ||
        (d.managerName && d.managerName.toLowerCase().includes(q))
    );
  }, [departments, searchQuery]);

  // Total Company Headcount
  const totalEmployeesCount = allEmployees.length;

  const openCreateModal = () => {
    setEditingDept(null);
    setName('');
    setCode('');
    setManagerId(allEmployees[0]?.id || 'EMP-1001');
    setShowAddEditModal(true);
  };

  const openEditModal = (dept: Department) => {
    setEditingDept(dept);
    setName(dept.name);
    setCode(dept.code);
    setManagerId(dept.managerId || allEmployees[0]?.id || 'EMP-1001');
    setShowAddEditModal(true);
  };

  const handleSaveDepartment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !code.trim()) {
      addToast('Validation Error', 'Department name and code are required.', 'error');
      return;
    }

    const assignedManager = allEmployees.find((e) => e.id === managerId);
    const managerName = assignedManager?.fullName || 'Argos Leadership';

    if (editingDept) {
      updateDepartment(editingDept.id, {
        name: name.trim(),
        code: code.trim().toUpperCase(),
        managerId,
        managerName,
      });
    } else {
      addDepartment({
        name: name.trim(),
        code: code.trim().toUpperCase(),
        managerId,
        managerName,
        parentDepartmentId: null,
        location: '',
        description: '',
        annualBudget: 0,
      });
    }

    setShowAddEditModal(false);
  };

  const handleDeleteClick = (dept: Department) => {
    setDeletingDept(dept);
    // Find another department to default the migration destination
    const other = departments.find((d) => d.id !== dept.id);
    setReassignTargetDept(other ? other.name : '');
  };

  const handleExecuteDeletion = () => {
    if (!deletingDept) return;
    const res = deleteDepartmentSafely(deletingDept.id);
    if (res.success) {
      setDeletingDept(null);
    }
  };

  const handleReassignAndMigrate = () => {
    if (!deletingDept || !reassignTargetDept) {
      addToast('Target Required', 'Please select a destination department.', 'error');
      return;
    }
    reassignDepartmentEmployees(deletingDept.name, reassignTargetDept);
    // After migrating, re-attempt safe deletion
    const res = deleteDepartmentSafely(deletingDept.id);
    if (res.success) {
      setDeletingDept(null);
    }
  };

  const handleExecuteDirectReassignment = () => {
    if (!reassignSourceDept || !reassignDestinationDept) {
      addToast('Departments Required', 'Select both source and target departments.', 'error');
      return;
    }
    if (reassignSourceDept === reassignDestinationDept) {
      addToast('Invalid Selection', 'Source and target departments cannot be identical.', 'error');
      return;
    }
    reassignDepartmentEmployees(reassignSourceDept, reassignDestinationDept);
    setShowReassignModal(false);
  };

  if (!isAuthorized) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="bg-white border-2 border-[#4E1617] rounded-2xl p-8 text-center space-y-4 shadow-sm">
          <ShieldAlert className="w-12 h-12 text-[#4E1617] mx-auto" />
          <h1 className="text-xl font-bold text-[#141A17]">
            Authorized HR & Admin Department Control
          </h1>
          <p className="text-sm text-[#525854] max-w-md mx-auto">
            You are logged in as <strong>{currentUser.role}</strong>. Creating, editing, or reassigning organizational departments is restricted to Human Resources and System Administrators.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#CBCBCB]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-md bg-[#164C38] text-[#F2F2F2] text-[10px] font-bold font-mono uppercase tracking-wider">
              Organization Core
            </span>
            <span className="text-xs text-[#525854]">
              Single Source of Truth for Enterprise Units
            </span>
          </div>
          <h1 className="text-2xl font-bold text-[#141A17] tracking-tight mt-1">
            Department Management
          </h1>
          <p className="text-xs text-[#525854] mt-0.5">
            Configure departments, subdepartments, assign department heads, monitor headcounts, and safely reassign team members with audit logging.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            onClick={() => {
              setReassignSourceDept(departments[0]?.name || '');
              setReassignDestinationDept(departments[1]?.name || '');
              setShowReassignModal(true);
            }}
            className="px-3.5 py-2 bg-[#F2F2F2] hover:bg-[#E5E5E5] text-[#141A17] border border-[#CBCBCB] rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            Reassign Personnel
          </button>

          <button
            type="button"
            onClick={openCreateModal}
            className="px-4 py-2 bg-[#164C38] hover:bg-[#0F3627] text-[#F2F2F2] rounded-lg text-xs font-semibold flex items-center gap-1.5 cursor-pointer shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Add Department
          </button>
        </div>
      </div>

      {/* KPI Stats Bar */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3 sm:gap-4">
        <div className="p-4 bg-white border border-[#CBCBCB] rounded-xl shadow-xs">
          <span className="text-[10px] font-bold uppercase text-[#525854] block">
            Total Departments
          </span>
          <p className="text-2xl font-bold text-[#141A17] mt-1">
            {departments.length}
          </p>
          <span className="text-[11px] text-[#164C38] font-medium block mt-0.5">
            Active organizational units
          </span>
        </div>

        <div className="p-4 bg-white border border-[#CBCBCB] rounded-xl shadow-xs">
          <span className="text-[10px] font-bold uppercase text-[#525854] block">
            Total Headcount
          </span>
          <p className="text-2xl font-bold text-[#141A17] mt-1">
            {totalEmployeesCount}
          </p>
          <span className="text-[11px] text-[#525854] block mt-0.5">
            Assigned personnel
          </span>
        </div>

        <div className="p-4 bg-white border border-[#CBCBCB] rounded-xl shadow-xs">
          <span className="text-[10px] font-bold uppercase text-[#525854] block">
            Assigned Department Heads
          </span>
          <p className="text-2xl font-bold text-[#141A17] mt-1">
            {departments.filter((d) => d.managerName).length}
          </p>
          <span className="text-[11px] text-[#164C38] font-medium block mt-0.5">
            Leadership appointed
          </span>
        </div>

        <div className="p-4 bg-white border border-[#CBCBCB] rounded-xl shadow-xs">
          <span className="text-[10px] font-bold uppercase text-[#525854] block">
            Average Department Size
          </span>
          <p className="text-2xl font-bold text-[#141A17] mt-1">
            {departments.length > 0
              ? (totalEmployeesCount / departments.length).toFixed(1)
              : '0'}
          </p>
          <span className="text-[11px] text-[#525854] block mt-0.5">
            Members per unit
          </span>
        </div>
      </div>

      {/* Filter and Export Bar */}
      <div className="bg-white border border-[#CBCBCB] rounded-xl p-4 flex flex-col md:flex-row items-center justify-between gap-3 shadow-xs">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-[#525854] absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search departments by name, code, or department head..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs placeholder:text-[#525854] focus:outline-none focus:ring-1 focus:ring-[#164C38]"
          />
        </div>

        <ExportDropdown
          onExportCSV={() =>
            exportTableToCSV(
              departments.map((d) => ({
                ID: d.id,
                'Department Name': d.name,
                'Department Code': d.code,
                'Department Head / Manager': d.managerName,
                Headcount: departmentStats[d.id]?.count || 0,
              })),
              'argos_departments_directory'
            )
          }
          onExportJSON={() =>
            exportTableToJSON(
              departments.map((d) => ({
                id: d.id,
                name: d.name,
                code: d.code,
                managerName: d.managerName,
                headcount: departmentStats[d.id]?.count || 0,
              })),
              'argos_departments_directory'
            )
          }
        />
      </div>

      {/* Department Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredDepartments.map((dept) => {
          const stats = departmentStats[dept.id] || {
            count: 0,
            members: [],
            manager: undefined,
          };
          const isExpanded = expandedDeptId === dept.id;

          return (
            <div
              key={dept.id}
              className="bg-white border border-[#CBCBCB] hover:border-[#164C38] rounded-xl p-5 shadow-xs transition-all flex flex-col justify-between"
            >
              <div>
                {/* Header row */}
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div>
                    <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-[#164C38]/10 text-[#164C38] border border-[#164C38]/30">
                      {dept.code}
                    </span>
                    <h2 className="text-base font-bold text-[#141A17] mt-1">
                      {dept.name}
                    </h2>
                  </div>

                  <span className="px-2.5 py-1 rounded-full text-xs font-mono font-bold bg-[#F2F2F2] text-[#141A17] border border-[#CBCBCB]">
                    {stats.count} {stats.count === 1 ? 'Member' : 'Members'}
                  </span>
                </div>

                {/* Assigned Department Head */}
                <div className="p-3 bg-[#F2F2F2] rounded-lg border border-[#CBCBCB] mb-3">
                  <span className="text-[10px] font-bold uppercase text-[#525854] block">
                    Department Head / Manager
                  </span>
                  <div className="flex items-center gap-2.5 mt-1">
                    <AvatarInitials name={dept.managerName || 'Head'} size="sm" />
                    <div>
                      <span className="text-xs font-bold text-[#141A17] block">
                        {dept.managerName || 'Unassigned'}
                      </span>
                      <span className="text-[11px] text-[#525854]">
                        {stats.manager?.designation || 'Department Leader'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* Expand Member List Drawer inside card */}
                {isExpanded && (
                  <div className="mt-4 pt-3 border-t border-[#CBCBCB] space-y-2 max-h-48 overflow-y-auto">
                    <span className="text-[10px] font-bold uppercase text-[#164C38] block">
                      Assigned Personnel ({stats.members.length})
                    </span>
                    {stats.members.length === 0 ? (
                      <p className="text-xs text-[#525854] italic">
                        No team members currently assigned.
                      </p>
                    ) : (
                      stats.members.map((m) => (
                        <div
                          key={m.id}
                          className="flex items-center justify-between text-xs p-1.5 bg-[#F2F2F2] rounded"
                        >
                          <div>
                            <span className="font-bold text-[#141A17] block">
                              {m.fullName}
                            </span>
                            <span className="text-[10px] text-[#525854]">
                              {m.designation}
                            </span>
                          </div>
                          <span className="text-[10px] font-mono text-[#164C38]">
                            {m.role}
                          </span>
                        </div>
                      ))
                    )}
                  </div>
                )}
              </div>

              {/* Action Buttons */}
              <div className="flex items-center justify-between pt-4 mt-4 border-t border-[#CBCBCB]">
                <button
                  type="button"
                  onClick={() =>
                    setExpandedDeptId(isExpanded ? null : dept.id)
                  }
                  className="text-xs font-semibold text-[#164C38] hover:underline cursor-pointer flex items-center gap-1"
                >
                  {isExpanded ? 'Hide Members' : `View ${stats.count} Members`}
                  {isExpanded ? (
                    <ChevronDown className="w-3.5 h-3.5" />
                  ) : (
                    <ChevronRight className="w-3.5 h-3.5" />
                  )}
                </button>

                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => openEditModal(dept)}
                    className="p-1.5 rounded bg-[#F2F2F2] hover:bg-[#E5E5E5] text-[#141A17] cursor-pointer"
                    title="Edit Department"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    type="button"
                    onClick={() => handleDeleteClick(dept)}
                    className="p-1.5 rounded hover:bg-[#4E1617]/10 text-[#4E1617] cursor-pointer"
                    title="Archive / Delete"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* ADD / EDIT DEPARTMENT MODAL */}
      {showAddEditModal && (
        <ModalShell
          title={editingDept ? `Edit Department — ${editingDept.name}` : 'Add New Department'}
          subtitle="Manage Department Name, Code, and Department Head"
          maxWidth="max-w-md"
        >
          <form onSubmit={handleSaveDepartment} className="space-y-4">
            <div className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                  Department Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., Horological Research & Assembly"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-semibold"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                  Department Code *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g., HRA, OPS, MKT"
                  value={code}
                  onChange={(e) => setCode(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-mono uppercase"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                  Department Head / Manager *
                </label>
                <select
                  value={managerId}
                  onChange={(e) => setManagerId(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-medium"
                >
                  {allEmployees.map((e) => (
                    <option key={e.id} value={e.id}>
                      {e.fullName} ({e.designation} · {e.department})
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#CBCBCB]">
              <button
                type="button"
                onClick={() => setShowAddEditModal(false)}
                className="px-4 py-2 text-xs font-semibold text-[#525854]"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-5 py-2 bg-[#164C38] hover:bg-[#0F3627] text-[#F2F2F2] rounded-lg text-xs font-semibold shadow-sm cursor-pointer"
              >
                {editingDept ? 'Save Changes' : 'Create Department'}
              </button>
            </div>
          </form>
        </ModalShell>
      )}

      {/* SAFE DELETION / REASSIGNMENT RESOLUTION MODAL */}
      {deletingDept && (
        <ModalShell
          title={`Archive / Delete — ${deletingDept.name}`}
          subtitle={`Department Code: ${deletingDept.code}`}
          maxWidth="max-w-md"
        >
          <div className="space-y-4">
            {departmentStats[deletingDept.id]?.count > 0 ? (
              <>
                <div className="p-3.5 bg-[#4E1617]/10 border border-[#4E1617]/30 rounded-xl flex items-start gap-3">
                  <AlertTriangle className="w-5 h-5 text-[#4E1617] shrink-0 mt-0.5" />
                  <div className="text-xs text-[#141A17]">
                    <strong className="block text-[#4E1617]">
                      Active Dependencies Detected
                    </strong>
                    There are currently{' '}
                    <strong>{departmentStats[deletingDept.id].count} employee(s)</strong>{' '}
                    assigned to <strong>{deletingDept.name}</strong>. Enterprise policy prohibits deleting departments with active dependencies to avoid orphan historical records.
                  </div>
                </div>

                <div>
                  <label className="block text-[11px] font-bold uppercase text-[#141A17] mb-1">
                    Migrate Assigned Employees To *
                  </label>
                  <select
                    value={reassignTargetDept}
                    onChange={(e) => setReassignTargetDept(e.target.value)}
                    className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-semibold text-[#164C38]"
                  >
                    {departments
                      .filter((d) => d.id !== deletingDept.id)
                      .map((d) => (
                        <option key={d.id} value={d.name}>
                          {d.name} ({d.code})
                        </option>
                      ))}
                  </select>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-[#CBCBCB]">
                  <button
                    type="button"
                    onClick={() => setDeletingDept(null)}
                    className="px-4 py-2 text-xs font-semibold text-[#525854]"
                  >
                    Cancel
                  </button>

                  <button
                    type="button"
                    onClick={handleReassignAndMigrate}
                    className="px-4 py-2 bg-[#164C38] hover:bg-[#0F3627] text-[#F2F2F2] rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Reassign {departmentStats[deletingDept.id].count} Members & Delete
                  </button>
                </div>
              </>
            ) : (
              <>
                <p className="text-xs text-[#525854]">
                  This department currently has <strong>0 assigned employees</strong>. It can be safely removed without impacting historical employment profiles.
                </p>

                <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#CBCBCB]">
                  <button
                    type="button"
                    onClick={() => setDeletingDept(null)}
                    className="px-4 py-2 text-xs font-semibold text-[#525854]"
                  >
                    Cancel
                  </button>
                  <button
                    type="button"
                    onClick={handleExecuteDeletion}
                    className="px-4 py-2 bg-[#4E1617] hover:bg-[#380F10] text-[#F2F2F2] rounded-lg text-xs font-semibold cursor-pointer"
                  >
                    Confirm Deletion
                  </button>
                </div>
              </>
            )}
          </div>
        </ModalShell>
      )}

      {/* DIRECT PERSONNEL REASSIGNMENT WIZARD */}
      {showReassignModal && (
        <ModalShell
          title="Batch Personnel Reassignment Wizard"
          subtitle="Migrate employee groups between enterprise departments with complete activity logging"
          maxWidth="max-w-lg"
        >
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
              <div>
                <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                  Source Department
                </label>
                <select
                  value={reassignSourceDept}
                  onChange={(e) => setReassignSourceDept(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-semibold"
                >
                  {departments.map((d) => (
                    <option key={d.id} value={d.name}>
                      {d.name} ({departmentStats[d.id]?.count || 0} members)
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                  Destination Department
                </label>
                <select
                  value={reassignDestinationDept}
                  onChange={(e) => setReassignDestinationDept(e.target.value)}
                  className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-semibold text-[#164C38]"
                >
                  {departments
                    .filter((d) => d.name !== reassignSourceDept)
                    .map((d) => (
                      <option key={d.id} value={d.name}>
                        {d.name} ({d.code})
                      </option>
                    ))}
                </select>
              </div>
            </div>

            <div className="p-3 bg-[#F2F2F2] rounded-xl border border-[#CBCBCB] text-xs text-[#525854]">
              <strong>Migration Confirmation:</strong> All employees currently belonging to <strong>{reassignSourceDept}</strong> will be updated to <strong>{reassignDestinationDept}</strong>. This update will be recorded in the system audit trail.
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-[#CBCBCB]">
              <button
                type="button"
                onClick={() => setShowReassignModal(false)}
                className="px-4 py-2 text-xs font-semibold text-[#525854]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleExecuteDirectReassignment}
                className="px-5 py-2 bg-[#164C38] hover:bg-[#0F3627] text-[#F2F2F2] text-xs font-semibold rounded-lg cursor-pointer"
              >
                Confirm Reassignment
              </button>
            </div>
          </div>
        </ModalShell>
      )}
    </div>
  );
}
