import React, { useState, useMemo } from 'react';
import {
  ShieldAlert,
  ShieldCheck,
  Search,
  Filter,
  CheckCircle2,
  XCircle,
  Clock,
  UserCheck,
  History,
  Sliders,
  AlertTriangle,
  Lock,
  Unlock,
  Eye,
  Edit3,
  Trash2,
  FileText,
  UserX,
  Mail,
  ChevronRight,
  Shield,
  Layers,
  ArrowUpDown,
  Download,
} from 'lucide-react';
import { useHRMS } from '../../context/HRMSContext';
import {
  UserRole,
  UserAccessRecord,
  AccessLevel,
  AccountStatus,
  ModuleActionPermission,
} from '../../types/hrms';
import {
  AvatarInitials,
  StatusBadge,
  ModalShell,
  ConfirmDialog,
  ActionMenu,
  ExportDropdown,
} from '../ui/EnterpriseComponents';
import { MODULE_LIST } from '../../data/accessAndOrgData';
import { exportTableToCSV, exportTableToJSON } from '../../lib/exportUtils';

export function ManageAccessModule() {
  const {
    currentUser,
    currentRole,
    userAccessList,
    updateUserAccess,
    revokeUserAccess,
    scopedActivityLogs,
    addToast,
    employees,
  } = useHRMS();

  // Active Category Filter: 'ALL' | 'ADMIN' | 'HR' | 'MANAGER' | 'EMPLOYEE'
  const [selectedRoleCategory, setSelectedRoleCategory] = useState<
    'ALL' | 'ADMIN' | 'HR' | 'MANAGER' | 'EMPLOYEE'
  >('ALL');

  // Search filter
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedStatusFilter, setSelectedStatusFilter] = useState<string>('ALL');
  const [selectedLevelFilter, setSelectedLevelFilter] = useState<string>('ALL');

  // Active Main Tab: 'users' (User Directory & Roles) | 'audit' (Access Audit Trail)
  const [activeTab, setActiveTab] = useState<'users' | 'audit'>('users');

  // Modal State for Editing / Granting Access
  const [editingUser, setEditingUser] = useState<UserAccessRecord | null>(null);
  const [formRole, setFormRole] = useState<UserRole>(UserRole.EMPLOYEE);
  const [formLevel, setFormLevel] = useState<AccessLevel>('Viewer');
  const [formStatus, setFormStatus] = useState<AccountStatus>('Active');
  const [formAdminNote, setFormAdminNote] = useState('');
  const [formPermissions, setFormPermissions] = useState<
    Record<string, ModuleActionPermission>
  >({});

  // Suspend/Revoke Confirmation Dialog
  const [suspendingUser, setSuspendingUser] = useState<UserAccessRecord | null>(null);
  const [suspendReason, setSuspendReason] = useState('');

  // Check if current user is an authorized Admin
  const isAdmin = currentRole === UserRole.ADMIN;

  // Counts by Role
  const countsByRole = useMemo(() => {
    return {
      ADMIN: userAccessList.filter((u) => u.role === UserRole.ADMIN).length,
      HR: userAccessList.filter((u) => u.role === UserRole.HR).length,
      MANAGER: userAccessList.filter((u) => u.role === UserRole.MANAGER).length,
      EMPLOYEE: userAccessList.filter((u) => u.role === UserRole.EMPLOYEE).length,
      TOTAL: userAccessList.length,
    };
  }, [userAccessList]);

  // Filtered User List
  const filteredUsers = useMemo(() => {
    return userAccessList.filter((u) => {
      if (selectedRoleCategory !== 'ALL' && u.role !== selectedRoleCategory) {
        return false;
      }
      if (selectedStatusFilter !== 'ALL' && u.accountStatus !== selectedStatusFilter) {
        return false;
      }
      if (selectedLevelFilter !== 'ALL' && u.accessLevel !== selectedLevelFilter) {
        return false;
      }
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase();
        const matchesName = u.fullName.toLowerCase().includes(q);
        const matchesId = u.employeeId.toLowerCase().includes(q);
        const matchesEmail = u.email.toLowerCase().includes(q);
        const matchesDept = u.department.toLowerCase().includes(q);
        const matchesDesig = u.designation.toLowerCase().includes(q);
        return matchesName || matchesId || matchesEmail || matchesDept || matchesDesig;
      }
      return true;
    });
  }, [userAccessList, selectedRoleCategory, selectedStatusFilter, selectedLevelFilter, searchQuery]);

  // Access-related Audit Logs
  const accessAuditLogs = useMemo(() => {
    return scopedActivityLogs.filter(
      (log) =>
        log.module === 'Manage Access' ||
        log.action.toLowerCase().includes('access') ||
        log.action.toLowerCase().includes('permission') ||
        log.action.toLowerCase().includes('role')
    );
  }, [scopedActivityLogs]);

  // Handle Opening the Edit Modal
  const openEditModal = (user: UserAccessRecord) => {
    setEditingUser(user);
    setFormRole(user.role);
    setFormLevel(user.accessLevel);
    setFormStatus(user.accountStatus);
    setFormAdminNote(user.adminNote || '');
    // Deep clone permissions
    setFormPermissions(JSON.parse(JSON.stringify(user.modulePermissions || {})));
  };

  // Handle Toggling a Specific Permission Action for a Module
  const togglePermissionAction = (
    moduleId: string,
    action: keyof ModuleActionPermission
  ) => {
    setFormPermissions((prev) => {
      const currentMod = prev[moduleId] || {
        view: false,
        create: false,
        edit: false,
        approve: false,
        delete: false,
        export: false,
      };
      return {
        ...prev,
        [moduleId]: {
          ...currentMod,
          [action]: !currentMod[action],
        },
      };
    });
  };

  // Handle Quick Permission Template switch (Viewer vs Controller presets)
  const applyAccessLevelDefaults = (level: AccessLevel, role: UserRole) => {
    setFormLevel(level);
    const updated: Record<string, ModuleActionPermission> = {};
    MODULE_LIST.forEach((m) => {
      if (role === UserRole.ADMIN) {
        updated[m.id] = {
          view: true,
          create: true,
          edit: true,
          approve: true,
          delete: true,
          export: true,
        };
      } else if (level === 'Controller') {
        const isSelfService = ['leave', 'considerations', 'documents'].includes(m.id);
        const isManagerOperational = ['people', 'attendance', 'leave', 'considerations', 'org-tree'].includes(m.id);
        updated[m.id] = {
          view: true,
          create: role === UserRole.MANAGER ? isManagerOperational : isSelfService,
          edit: role === UserRole.MANAGER ? isManagerOperational : isSelfService,
          approve: role === UserRole.MANAGER ? ['leave', 'considerations'].includes(m.id) : false,
          delete: false,
          export: true,
        };
      } else {
        // Viewer
        updated[m.id] = {
          view: true,
          create: false,
          edit: false,
          approve: false,
          delete: false,
          export: ['attendance', 'documents', 'reports'].includes(m.id),
        };
      }
    });
    setFormPermissions(updated);
  };

  // Save Modal Form
  const handleSaveAccess = () => {
    if (!editingUser) return;

    if (
      editingUser.employeeId === currentUser.id &&
      formRole !== UserRole.ADMIN
    ) {
      addToast(
        'Self-Demotion Blocked',
        'Administrators cannot demote themselves to prevent system lockout.',
        'error'
      );
      return;
    }

    updateUserAccess(
      editingUser.employeeId,
      {
        role: formRole,
        accessLevel: formLevel,
        accountStatus: formStatus,
        modulePermissions: formPermissions,
      },
      formAdminNote || `Updated by Administrator ${currentUser.fullName}`
    );

    setEditingUser(null);
  };

  // Confirm Suspension
  const handleConfirmSuspend = () => {
    if (!suspendingUser) return;
    revokeUserAccess(
      suspendingUser.employeeId,
      suspendReason || 'Administrative suspension via Manage Access center'
    );
    setSuspendingUser(null);
    setSuspendReason('');
  };

  // If user is not admin, display restricted shield
  if (!isAdmin) {
    return (
      <div className="p-8 max-w-4xl mx-auto">
        <div className="bg-white border-2 border-[#4E1617] rounded-2xl p-8 text-center space-y-4 shadow-sm">
          <div className="w-16 h-16 mx-auto rounded-full bg-[#4E1617]/10 flex items-center justify-center text-[#4E1617]">
            <Lock className="w-8 h-8" />
          </div>
          <div>
            <h1 className="text-xl font-bold text-[#141A17]">
              Admin-Only Manage Access Center
            </h1>
            <p className="text-sm text-[#525854] mt-1 max-w-md mx-auto">
              You are currently authenticated as <strong>{currentUser.role}</strong>. This module is strictly restricted to Enterprise Administrators for role assignment, credential controls, and audit trails.
            </p>
          </div>
          <div className="p-3 bg-[#F2F2F2] rounded-xl text-xs font-mono text-[#525854] max-w-sm mx-auto border border-[#CBCBCB]">
            RBAC Policy: REQUIRE_ADMIN_PRIVILEGES_V2
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6 p-4 sm:p-6 max-w-7xl mx-auto">
      {/* Header Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[#CBCBCB]">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-1 rounded-md bg-[#164C38] text-[#F2F2F2] text-[10px] font-bold font-mono uppercase tracking-wider">
              Admin Exclusive
            </span>
            <span className="text-xs text-[#525854] font-medium">
              Enterprise Role-Based Access Control & Governance
            </span>
          </div>
          <h1 className="text-2xl font-bold text-[#141A17] tracking-tight mt-1">
            Manage Access Center
          </h1>
          <p className="text-xs text-[#525854] mt-0.5">
            Configure system roles, Viewer/Controller privileges, granular module permissions, and inspect immutable audit logs.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex items-center gap-2 bg-[#F2F2F2] p-1 rounded-xl border border-[#CBCBCB]">
          <button
            type="button"
            onClick={() => setActiveTab('users')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'users'
                ? 'bg-[#164C38] text-[#F2F2F2] shadow-sm'
                : 'text-[#525854] hover:text-[#141A17]'
            }`}
          >
            <ShieldCheck className="w-3.5 h-3.5" />
            User Permissions ({countsByRole.TOTAL})
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('audit')}
            className={`px-3.5 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-2 cursor-pointer transition-colors ${
              activeTab === 'audit'
                ? 'bg-[#164C38] text-[#F2F2F2] shadow-sm'
                : 'text-[#525854] hover:text-[#141A17]'
            }`}
          >
            <History className="w-3.5 h-3.5" />
            Access Audit Trail ({accessAuditLogs.length})
          </button>
        </div>
      </div>

      {/* TAB 1: USERS & ROLE CATEGORIES */}
      {activeTab === 'users' && (
        <div className="space-y-6">
          {/* 4 Separate Category Cards */}
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-4">
            {/* Admin Access Card */}
            <div
              onClick={() =>
                setSelectedRoleCategory(
                  selectedRoleCategory === 'ADMIN' ? 'ALL' : 'ADMIN'
                )
              }
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedRoleCategory === 'ADMIN'
                  ? 'bg-white border-[#164C38] ring-2 ring-[#164C38]/20 shadow-sm'
                  : 'bg-white border-[#CBCBCB] hover:border-[#164C38]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#164C38]">
                  Admin Access
                </span>
                <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#164C38] text-[#F2F2F2]">
                  {countsByRole.ADMIN}
                </span>
              </div>
              <p className="text-xl font-bold text-[#141A17]">
                {countsByRole.ADMIN} {countsByRole.ADMIN === 1 ? 'Administrator' : 'Administrators'}
              </p>
              <span className="text-[11px] text-[#525854] block mt-1">
                Unrestricted system configuration & role governance
              </span>
            </div>

            {/* HR Access Card */}
            <div
              onClick={() =>
                setSelectedRoleCategory(
                  selectedRoleCategory === 'HR' ? 'ALL' : 'HR'
                )
              }
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedRoleCategory === 'HR'
                  ? 'bg-white border-[#164C38] ring-2 ring-[#164C38]/20 shadow-sm'
                  : 'bg-white border-[#CBCBCB] hover:border-[#164C38]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#164C38]">
                  HR Access
                </span>
                <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#164C38]/10 text-[#164C38] border border-[#164C38]/30">
                  {countsByRole.HR}
                </span>
              </div>
              <p className="text-xl font-bold text-[#141A17]">
                {countsByRole.HR} {countsByRole.HR === 1 ? 'HR Officer' : 'HR Officers'}
              </p>
              <span className="text-[11px] text-[#525854] block mt-1">
                People management, payroll processing & onboarding
              </span>
            </div>

            {/* Manager Access Card */}
            <div
              onClick={() =>
                setSelectedRoleCategory(
                  selectedRoleCategory === 'MANAGER' ? 'ALL' : 'MANAGER'
                )
              }
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedRoleCategory === 'MANAGER'
                  ? 'bg-white border-[#164C38] ring-2 ring-[#164C38]/20 shadow-sm'
                  : 'bg-white border-[#CBCBCB] hover:border-[#164C38]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#164C38]">
                  Manager Access
                </span>
                <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#164C38]/10 text-[#164C38] border border-[#164C38]/30">
                  {countsByRole.MANAGER}
                </span>
              </div>
              <p className="text-xl font-bold text-[#141A17]">
                {countsByRole.MANAGER} {countsByRole.MANAGER === 1 ? 'Team Lead' : 'Team Leads'}
              </p>
              <span className="text-[11px] text-[#525854] block mt-1">
                Direct reports approvals, shifts & attendance reviews
              </span>
            </div>

            {/* Employee Access Card */}
            <div
              onClick={() =>
                setSelectedRoleCategory(
                  selectedRoleCategory === 'EMPLOYEE' ? 'ALL' : 'EMPLOYEE'
                )
              }
              className={`p-4 rounded-xl border cursor-pointer transition-all ${
                selectedRoleCategory === 'EMPLOYEE'
                  ? 'bg-white border-[#164C38] ring-2 ring-[#164C38]/20 shadow-sm'
                  : 'bg-white border-[#CBCBCB] hover:border-[#164C38]'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <span className="text-[11px] font-bold uppercase tracking-wider text-[#525854]">
                  Employee Access
                </span>
                <span className="px-2 py-0.5 rounded-full text-xs font-mono font-bold bg-[#F2F2F2] text-[#141A17] border border-[#CBCBCB]">
                  {countsByRole.EMPLOYEE}
                </span>
              </div>
              <p className="text-xl font-bold text-[#141A17]">
                {countsByRole.EMPLOYEE} Members
              </p>
              <span className="text-[11px] text-[#525854] block mt-1">
                Self-service attendance check-in, leaves & documents
              </span>
            </div>
          </div>

          {/* Filter Bar */}
          <div className="bg-white border border-[#CBCBCB] rounded-xl p-4 flex flex-col md:flex-row items-stretch md:items-center justify-between gap-3 shadow-xs">
            {/* Search */}
            <div className="relative flex-1">
              <Search className="w-4 h-4 text-[#525854] absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search by name, employee ID, department, designation, or email..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs placeholder:text-[#525854] focus:outline-none focus:ring-1 focus:ring-[#164C38]"
              />
            </div>

            {/* Secondary Filters */}
            <div className="flex items-center gap-2 flex-wrap">
              <select
                value={selectedRoleCategory}
                onChange={(e) => setSelectedRoleCategory(e.target.value as any)}
                className="px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-semibold text-[#141A17]"
              >
                <option value="ALL">All Roles ({countsByRole.TOTAL})</option>
                <option value="ADMIN">Admin Only ({countsByRole.ADMIN})</option>
                <option value="HR">HR Only ({countsByRole.HR})</option>
                <option value="MANAGER">Manager Only ({countsByRole.MANAGER})</option>
                <option value="EMPLOYEE">Employee Only ({countsByRole.EMPLOYEE})</option>
              </select>

              <select
                value={selectedLevelFilter}
                onChange={(e) => setSelectedLevelFilter(e.target.value)}
                className="px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-medium text-[#141A17]"
              >
                <option value="ALL">All Levels</option>
                <option value="Controller">Controller</option>
                <option value="Viewer">Viewer</option>
              </select>

              <select
                value={selectedStatusFilter}
                onChange={(e) => setSelectedStatusFilter(e.target.value)}
                className="px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs font-medium text-[#141A17]"
              >
                <option value="ALL">All Statuses</option>
                <option value="Active">Active</option>
                <option value="Suspended">Suspended</option>
                <option value="Invited">Invited</option>
              </select>

              <ExportDropdown
                onExportCSV={() =>
                  exportTableToCSV(
                    filteredUsers.map((u) => ({
                      'Employee ID': u.employeeId,
                      'Full Name': u.fullName,
                      Email: u.email,
                      Role: u.role,
                      'Access Level': u.accessLevel,
                      Status: u.accountStatus,
                      Department: u.department,
                      Designation: u.designation,
                      'Last Login': u.lastLogin || 'N/A',
                      'Invitation Status': u.invitationStatus,
                    })),
                    'argos_user_access_directory'
                  )
                }
                onExportJSON={() =>
                  exportTableToJSON(filteredUsers, 'argos_user_access_directory')
                }
              />
            </div>
          </div>

          {/* User Table */}
          <div className="bg-white border border-[#CBCBCB] rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#F2F2F2] border-b border-[#CBCBCB] text-[#525854] font-bold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">User & Employee ID</th>
                    <th className="py-3 px-4">Current Role</th>
                    <th className="py-3 px-4">Department & Designation</th>
                    <th className="py-3 px-4">Assigned Manager</th>
                    <th className="py-3 px-4">Access Level</th>
                    <th className="py-3 px-4">Account Status</th>
                    <th className="py-3 px-4">Last Login & Invite</th>
                    <th className="py-3 px-4 text-right">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#CBCBCB]">
                  {filteredUsers.length === 0 ? (
                    <tr>
                      <td colSpan={8} className="py-10 text-center text-[#525854]">
                        No users match the selected filters or search query.
                      </td>
                    </tr>
                  ) : (
                    filteredUsers.map((u) => {
                      const isSelf = u.employeeId === currentUser.id;
                      return (
                        <tr
                          key={u.employeeId}
                          className="hover:bg-[#F2F2F2]/60 transition-colors"
                        >
                          {/* User & ID */}
                          <td className="py-3.5 px-4">
                            <div className="flex items-center gap-3">
                              <AvatarInitials name={u.fullName} size="sm" />
                              <div>
                                <span className="font-bold text-[#141A17] flex items-center gap-1.5">
                                  {u.fullName}
                                  {isSelf && (
                                    <span className="px-1.5 py-0.2 rounded text-[9px] bg-[#164C38]/10 text-[#164C38] font-mono font-bold">
                                      YOU
                                    </span>
                                  )}
                                </span>
                                <span className="text-[11px] font-mono text-[#525854] block">
                                  {u.employeeId} • {u.email}
                                </span>
                              </div>
                            </div>
                          </td>

                          {/* Role */}
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2 py-0.5 rounded text-[11px] font-bold font-mono inline-block ${
                                u.role === UserRole.ADMIN
                                  ? 'bg-[#164C38] text-[#F2F2F2]'
                                  : u.role === UserRole.HR
                                  ? 'bg-[#164C38]/10 text-[#164C38] border border-[#164C38]/30'
                                  : u.role === UserRole.MANAGER
                                  ? 'bg-[#4E1617]/10 text-[#4E1617] border border-[#4E1617]/30'
                                  : 'bg-[#F2F2F2] text-[#141A17] border border-[#CBCBCB]'
                              }`}
                            >
                              {u.role}
                            </span>
                          </td>

                          {/* Department & Designation */}
                          <td className="py-3.5 px-4">
                            <span className="font-medium text-[#141A17] block">
                              {u.designation}
                            </span>
                            <span className="text-[11px] text-[#525854]">
                              {u.department}
                            </span>
                          </td>

                          {/* Manager */}
                          <td className="py-3.5 px-4 text-[#525854]">
                            {u.managerName || 'Executive Board'}
                          </td>

                          {/* Access Level */}
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider inline-flex items-center gap-1 ${
                                u.accessLevel === 'Controller'
                                  ? 'bg-[#164C38]/10 text-[#164C38] border border-[#164C38]/30'
                                  : 'bg-[#F2F2F2] text-[#525854] border border-[#CBCBCB]'
                              }`}
                            >
                              {u.accessLevel === 'Controller' ? (
                                <Unlock className="w-2.5 h-2.5" />
                              ) : (
                                <Eye className="w-2.5 h-2.5" />
                              )}
                              {u.accessLevel}
                            </span>
                          </td>

                          {/* Account Status */}
                          <td className="py-3.5 px-4">
                            <span
                              className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase inline-block ${
                                u.accountStatus === 'Active'
                                  ? 'bg-[#164C38]/10 text-[#164C38]'
                                  : u.accountStatus === 'Suspended'
                                  ? 'bg-[#4E1617]/10 text-[#4E1617]'
                                  : 'bg-[#F2F2F2] text-[#525854]'
                              }`}
                            >
                              {u.accountStatus}
                            </span>
                          </td>

                          {/* Last Login & Invite */}
                          <td className="py-3.5 px-4">
                            <span className="text-[11px] text-[#141A17] block">
                              {u.lastLogin || 'Recent Active Session'}
                            </span>
                            <span className="text-[10px] font-mono text-[#525854]">
                              Invite: {u.invitationStatus}
                            </span>
                          </td>

                          {/* Actions */}
                          <td className="py-3.5 px-4 text-right">
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                type="button"
                                onClick={() => openEditModal(u)}
                                className="px-2.5 py-1 rounded-md bg-[#164C38] text-[#F2F2F2] text-[11px] font-semibold hover:bg-[#0F3627] cursor-pointer inline-flex items-center gap-1"
                              >
                                <Edit3 className="w-3 h-3" />
                                Edit Access
                              </button>

                              {!isSelf && (
                                <button
                                  type="button"
                                  onClick={() => setSuspendingUser(u)}
                                  className="p-1 rounded-md text-[#4E1617] hover:bg-[#4E1617]/10 cursor-pointer"
                                  title="Suspend / Revoke"
                                >
                                  <UserX className="w-3.5 h-3.5" />
                                </button>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>

            {/* Footer summary */}
            <div className="px-4 py-3 bg-[#F2F2F2] border-t border-[#CBCBCB] flex items-center justify-between text-[11px] text-[#525854]">
              <span>
                Showing <strong>{filteredUsers.length}</strong> of{' '}
                <strong>{userAccessList.length}</strong> total users
              </span>
              <span>
                Viewer: {userAccessList.filter((u) => u.accessLevel === 'Viewer').length} | Controller: {userAccessList.filter((u) => u.accessLevel === 'Controller').length}
              </span>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ACCESS AUDIT TRAIL */}
      {activeTab === 'audit' && (
        <div className="space-y-4">
          <div className="bg-white border border-[#CBCBCB] rounded-xl p-4 flex items-center justify-between shadow-xs">
            <div>
              <h2 className="text-sm font-bold text-[#141A17]">
                Immutable Access Audit Trail
              </h2>
              <p className="text-xs text-[#525854]">
                Complete history of role assignments, Viewer/Controller grants, module permission toggles, and suspensions.
              </p>
            </div>
            <ExportDropdown
              onExportCSV={() =>
                exportTableToCSV(
                  accessAuditLogs.map((log) => ({
                    ID: log.id,
                    'Date & Time': log.timestamp,
                    Actor: log.actorName,
                    'Actor Role': log.actorRole,
                    Action: log.action,
                    'Target Record': log.targetRecord,
                    'Previous State': log.previousValue,
                    'New State': log.newValue,
                  })),
                  'argos_access_audit_trail'
                )
              }
              onExportJSON={() =>
                exportTableToJSON(accessAuditLogs, 'argos_access_audit_trail')
              }
            />
          </div>

          <div className="bg-white border border-[#CBCBCB] rounded-xl overflow-hidden shadow-xs">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs border-collapse">
                <thead>
                  <tr className="bg-[#F2F2F2] border-b border-[#CBCBCB] text-[#525854] font-bold uppercase text-[10px] tracking-wider">
                    <th className="py-3 px-4">Date & Time</th>
                    <th className="py-3 px-4">Administrator (Actor)</th>
                    <th className="py-3 px-4">Affected User</th>
                    <th className="py-3 px-4">Action Summary</th>
                    <th className="py-3 px-4">Previous Value</th>
                    <th className="py-3 px-4">New Value / Note</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#CBCBCB]">
                  {accessAuditLogs.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="py-8 text-center text-[#525854]">
                        No access modifications logged yet.
                      </td>
                    </tr>
                  ) : (
                    accessAuditLogs.map((log) => (
                      <tr key={log.id} className="hover:bg-[#F2F2F2]/60">
                        <td className="py-3 px-4 font-mono text-[11px] text-[#525854]">
                          {log.timestamp}
                        </td>
                        <td className="py-3 px-4">
                          <span className="font-bold text-[#141A17]">
                            {log.actorName}
                          </span>
                          <span className="text-[10px] font-mono text-[#525854] block">
                            {log.actorRole}
                          </span>
                        </td>
                        <td className="py-3 px-4 font-semibold text-[#141A17]">
                          {log.targetRecord || log.targetEmployeeId || 'N/A'}
                        </td>
                        <td className="py-3 px-4 text-[#141A17]">
                          {log.action}
                        </td>
                        <td className="py-3 px-4 text-[11px] text-[#525854] font-mono">
                          {log.previousValue || '—'}
                        </td>
                        <td className="py-3 px-4 text-[11px] text-[#164C38] font-mono font-semibold">
                          {log.newValue || '—'}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* EDIT / GRANT ACCESS MODAL */}
      {editingUser && (
        <ModalShell
          title={`Configure Access — ${editingUser.fullName}`}
          subtitle={`${editingUser.employeeId} · ${editingUser.designation} (${editingUser.department})`}
          maxWidth="max-w-3xl"
        >
          <div className="space-y-5">
            {/* Top Config Row: Role, Level, Status */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3.5 bg-[#F2F2F2] p-3.5 rounded-xl border border-[#CBCBCB]">
              <div>
                <label className="block text-[10px] font-bold uppercase text-[#525854] mb-1">
                  Assigned RBAC Role *
                </label>
                <select
                  value={formRole}
                  onChange={(e) => {
                    const nextRole = e.target.value as UserRole;
                    setFormRole(nextRole);
                    applyAccessLevelDefaults(formLevel, nextRole);
                  }}
                  className="w-full px-3 py-2 bg-white border border-[#CBCBCB] rounded-lg text-xs font-bold text-[#141A17]"
                >
                  <option value={UserRole.ADMIN}>ADMIN (Full System Privileges)</option>
                  <option value={UserRole.HR}>HR (Human Resources)</option>
                  <option value={UserRole.MANAGER}>MANAGER (Operational Team Lead)</option>
                  <option value={UserRole.EMPLOYEE}>EMPLOYEE (Self-Service)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-[#525854] mb-1">
                  Access Level (Permission Tier) *
                </label>
                <select
                  value={formLevel}
                  onChange={(e) => {
                    const nextLevel = e.target.value as AccessLevel;
                    applyAccessLevelDefaults(nextLevel, formRole);
                  }}
                  className="w-full px-3 py-2 bg-white border border-[#CBCBCB] rounded-lg text-xs font-bold text-[#164C38]"
                >
                  <option value="Viewer">Viewer (Read-Only Authorized Modules)</option>
                  <option value="Controller">Controller (Authorized Action Privileges)</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold uppercase text-[#525854] mb-1">
                  Account Status *
                </label>
                <select
                  value={formStatus}
                  onChange={(e) => setFormStatus(e.target.value as AccountStatus)}
                  className="w-full px-3 py-2 bg-white border border-[#CBCBCB] rounded-lg text-xs font-bold text-[#141A17]"
                >
                  <option value="Active">Active</option>
                  <option value="Suspended">Suspended (Access Disabled)</option>
                  <option value="Invited">Invited (Pending First Login)</option>
                  <option value="Inactive">Inactive</option>
                </select>
              </div>
            </div>

            {/* Viewer vs Controller Guidance banner */}
            <div className="p-3 bg-[#164C38]/5 border border-[#164C38]/20 rounded-xl text-xs text-[#141A17] flex items-start gap-2.5">
              <Shield className="w-4 h-4 text-[#164C38] shrink-0 mt-0.5" />
              <div>
                <strong className="block text-[#164C38]">
                  {formLevel === 'Controller' ? 'Controller Level Granted' : 'Viewer Level Selected'}
                </strong>
                <p className="text-[11px] text-[#525854]">
                  {formLevel === 'Controller'
                    ? 'Controllers can create, edit, update, or manage explicitly authorized modules. Controller does not automatically confer unrestricted admin authority.'
                    : 'Viewers are strictly restricted to reading and exporting data in their authorized modules.'}
                </p>
              </div>
            </div>

            {/* Granular Module Permissions Matrix */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-[11px] font-bold uppercase text-[#141A17] tracking-wider">
                  Module-Level Granular Permissions
                </label>
                <span className="text-[10px] text-[#525854]">
                  Click checkboxes to toggle View, Create, Edit, Approve, Delete, Export
                </span>
              </div>

              <div className="border border-[#CBCBCB] rounded-xl overflow-hidden">
                <table className="w-full text-left text-xs">
                  <thead className="bg-[#F2F2F2] border-b border-[#CBCBCB] text-[10px] font-bold uppercase text-[#525854]">
                    <tr>
                      <th className="py-2.5 px-3">Module</th>
                      <th className="py-2.5 px-2 text-center">View</th>
                      <th className="py-2.5 px-2 text-center">Create</th>
                      <th className="py-2.5 px-2 text-center">Edit</th>
                      <th className="py-2.5 px-2 text-center">Approve</th>
                      <th className="py-2.5 px-2 text-center">Delete</th>
                      <th className="py-2.5 px-2 text-center">Export</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#CBCBCB]">
                    {MODULE_LIST.map((mod) => {
                      const perms = formPermissions[mod.id] || {
                        view: false,
                        create: false,
                        edit: false,
                        approve: false,
                        delete: false,
                        export: false,
                      };
                      return (
                        <tr key={mod.id} className="hover:bg-[#F2F2F2]/50">
                          <td className="py-2.5 px-3 font-semibold text-[#141A17]">
                            {mod.label}
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <input
                              type="checkbox"
                              checked={perms.view}
                              onChange={() => togglePermissionAction(mod.id, 'view')}
                              className="accent-[#164C38]"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <input
                              type="checkbox"
                              checked={perms.create}
                              onChange={() => togglePermissionAction(mod.id, 'create')}
                              className="accent-[#164C38]"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <input
                              type="checkbox"
                              checked={perms.edit}
                              onChange={() => togglePermissionAction(mod.id, 'edit')}
                              className="accent-[#164C38]"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <input
                              type="checkbox"
                              checked={perms.approve}
                              onChange={() => togglePermissionAction(mod.id, 'approve')}
                              className="accent-[#164C38]"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <input
                              type="checkbox"
                              checked={perms.delete}
                              onChange={() => togglePermissionAction(mod.id, 'delete')}
                              className="accent-[#164C38]"
                            />
                          </td>
                          <td className="py-2.5 px-2 text-center">
                            <input
                              type="checkbox"
                              checked={perms.export}
                              onChange={() => togglePermissionAction(mod.id, 'export')}
                              className="accent-[#164C38]"
                            />
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Administrative Reason / Note */}
            <div>
              <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                Administrative Reason / Audit Note *
              </label>
              <textarea
                rows={2}
                placeholder="Specify the reason or operational justification for this permission change..."
                value={formAdminNote}
                onChange={(e) => setFormAdminNote(e.target.value)}
                className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs focus:ring-1 focus:ring-[#164C38]"
              />
            </div>

            {/* Modal Actions */}
            <div className="flex items-center justify-between pt-3 border-t border-[#CBCBCB]">
              <button
                type="button"
                onClick={() => setEditingUser(null)}
                className="px-4 py-2 rounded-lg text-xs font-semibold text-[#525854] hover:bg-[#F2F2F2] cursor-pointer"
              >
                Cancel
              </button>

              <div className="flex items-center gap-2">
                {editingUser.employeeId !== currentUser.id && (
                  <button
                    type="button"
                    onClick={() => {
                      setSuspendingUser(editingUser);
                      setEditingUser(null);
                    }}
                    className="px-3.5 py-2 rounded-lg text-xs font-semibold text-[#4E1617] hover:bg-[#4E1617]/10 cursor-pointer"
                  >
                    Suspend Access
                  </button>
                )}

                <button
                  type="button"
                  onClick={handleSaveAccess}
                  className="px-5 py-2 bg-[#164C38] hover:bg-[#0F3627] text-[#F2F2F2] text-xs font-semibold rounded-lg cursor-pointer shadow-sm"
                >
                  Save Access Permissions
                </button>
              </div>
            </div>
          </div>
        </ModalShell>
      )}

      {/* SUSPEND / REVOKE CONFIRMATION DIALOG */}
      {suspendingUser && (
        <ModalShell
          title={`Suspend User Access — ${suspendingUser.fullName}`}
          subtitle={`Employee ID: ${suspendingUser.employeeId}`}
          maxWidth="max-w-md"
        >
          <div className="space-y-4">
            <div className="p-3.5 bg-[#4E1617]/10 border border-[#4E1617]/30 rounded-xl flex items-start gap-3">
              <AlertTriangle className="w-5 h-5 text-[#4E1617] shrink-0 mt-0.5" />
              <div className="text-xs text-[#141A17]">
                <strong className="block text-[#4E1617]">Immediate Access Suspension</strong>
                This user will be marked as <strong>Suspended</strong> and their credentials downgraded to Viewer. They will be prevented from executing privileged workflows.
              </div>
            </div>

            <div>
              <label className="block text-[11px] font-bold uppercase text-[#525854] mb-1">
                Reason for Suspension *
              </label>
              <textarea
                rows={2}
                placeholder="e.g., Extended leave of absence, department reorganization, compliance review..."
                value={suspendReason}
                onChange={(e) => setSuspendReason(e.target.value)}
                className="w-full px-3 py-2 bg-[#F2F2F2] border border-[#CBCBCB] rounded-lg text-xs"
              />
            </div>

            <div className="flex items-center justify-end gap-2 pt-2 border-t border-[#CBCBCB]">
              <button
                type="button"
                onClick={() => setSuspendingUser(null)}
                className="px-4 py-2 text-xs font-semibold text-[#525854]"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={handleConfirmSuspend}
                className="px-4 py-2 bg-[#4E1617] hover:bg-[#380F10] text-[#F2F2F2] text-xs font-semibold rounded-lg"
              >
                Confirm Suspension
              </button>
            </div>
          </div>
        </ModalShell>
      )}
    </div>
  );
}
