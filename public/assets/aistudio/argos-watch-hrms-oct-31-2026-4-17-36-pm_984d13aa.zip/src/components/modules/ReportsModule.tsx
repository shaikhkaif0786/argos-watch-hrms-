import React, { useState, useMemo } from 'react';
import {
  BarChart3,
  Search,
  ArrowUpDown,
  Filter,
  FileSpreadsheet,
  AlertTriangle,
  Clock,
  Calendar,
  FileText,
  UserCheck,
  CheckCircle2,
  XCircle,
  HelpCircle,
  Receipt,
  IndianRupee,
} from 'lucide-react';
import { useHRMS } from '../../context/HRMSContext';
import { ExportDropdown, AvatarInitials, StatusBadge } from '../ui/EnterpriseComponents';
import { exportDataToFormat, exportMultiSheetExcelXLSX } from '../../lib/exportUtils';
import { calculateLateDeduction } from '../../lib/attendanceCalculations';

export type ReportTypeId =
  | 'attendance'
  | 'consideration'
  | 'late-coming'
  | 'late-salary-deduction'
  | 'overtime'
  | 'leave'
  | 'final-combined';

interface ReportMeta {
  id: ReportTypeId;
  label: string;
  badge: string;
  description: string;
  icon: React.ElementType;
}

const REPORT_TYPES: ReportMeta[] = [
  {
    id: 'attendance',
    label: 'Attendance Report',
    badge: 'Core Daily',
    description: 'Daily shift attendance, punch in/out timestamps, effective working hours, and punch exceptions sub-view',
    icon: Calendar,
  },
  {
    id: 'consideration',
    label: 'Consideration Report',
    badge: 'Appeals',
    description: 'Late arrival waivers, missed punch dispute requests, and HR/Manager decision audit trails',
    icon: HelpCircle,
  },
  {
    id: 'late-coming',
    label: 'Late Coming Report',
    badge: 'Compliance',
    description: 'Arrivals past the 15-min grace window (09:45), minutes late, monthly count, and deduction threshold warnings',
    icon: Clock,
  },
  {
    id: 'late-salary-deduction',
    label: 'Late Salary Deduction',
    badge: 'Payroll Precision',
    description: 'Per-minute salary deduction breakdown: Monthly Salary ÷ 26 ÷ 480 × Late Minutes across 20 audit parameters',
    icon: IndianRupee,
  },
  {
    id: 'overtime',
    label: 'Overtime Report',
    badge: 'Compensation',
    description: 'Hours worked beyond 8.5h shift, overtime rates, approval status, and calculated payouts',
    icon: BarChart3,
  },
  {
    id: 'leave',
    label: 'Leave Report',
    badge: 'Time Off',
    description: 'Leave applications, leave types, approved dates, session allocations, and employee balances',
    icon: FileText,
  },
  {
    id: 'final-combined',
    label: 'Final Combined Report',
    badge: 'Executive Master',
    description: 'Consolidated master metrics across all modules with complete 8-sheet .xlsx workbook export',
    icon: FileSpreadsheet,
  },
];

export function ReportsModule() {
  const {
    currentUser,
    employees,
    attendance,
    leaves,
    considerations,
    settings,
    companySettings,
  } = useHRMS();

  const activeSettings = companySettings || settings;

  const [activeReport, setActiveReport] = useState<ReportTypeId>('attendance');

  // Attendance Sub-view: All vs Punch Exceptions Only (Requirement 8)
  const [attendanceSubView, setAttendanceSubView] = useState<'ALL' | 'EXCEPTIONS'>('ALL');

  // Universal Report Filters
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [filterEmpId, setFilterEmpId] = useState('ALL');
  const [filterDept, setFilterDept] = useState('ALL');
  const [filterStatus, setFilterStatus] = useState('ALL');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const isHRAdmin = currentUser.role === 'HR' || currentUser.role === 'ADMIN';

  // Role-Scoped Employees
  const permittedEmployees = useMemo(() => {
    if (isHRAdmin) return employees;
    if (currentUser.role === 'MANAGER') {
      return employees.filter(
        (e) => e.managerId === currentUser.employeeId || e.id === currentUser.employeeId
      );
    }
    return employees.filter((e) => e.id === currentUser.employeeId);
  }, [employees, isHRAdmin, currentUser]);

  const permittedEmpIds = useMemo(
    () => new Set(permittedEmployees.map((e) => e.id)),
    [permittedEmployees]
  );

  const departments = useMemo<string[]>(() => {
    const set = new Set<string>(permittedEmployees.map((e) => e.department));
    return ['ALL', ...Array.from(set)];
  }, [permittedEmployees]);

  // Universal Filter Check Helper
  const matchesCommon = (
    empId: string,
    dept: string,
    dateStr?: string,
    statusStr?: string,
    textBlob?: string
  ) => {
    if (!permittedEmpIds.has(empId)) return false;
    if (filterEmpId !== 'ALL' && empId !== filterEmpId) return false;
    if (filterDept !== 'ALL' && dept !== filterDept) return false;
    if (filterStatus !== 'ALL' && statusStr && statusStr !== filterStatus) return false;
    if (dateFrom && dateStr && dateStr < dateFrom) return false;
    if (dateTo && dateStr && dateStr > dateTo) return false;
    if (searchQuery && textBlob && !textBlob.toLowerCase().includes(searchQuery.toLowerCase())) {
      return false;
    }
    return true;
  };

  // Monthly Late Count Map for Late Coming Warning Flags
  const monthlyLateCounts = useMemo(() => {
    const map = new Map<string, number>();
    attendance.forEach((att) => {
      if (att.status === 'LATE' || (att.lateMinutes && att.lateMinutes > 0)) {
        const monthKey = `${att.employeeId}-${att.date.slice(0, 7)}`;
        map.set(monthKey, (map.get(monthKey) || 0) + 1);
      }
    });
    return map;
  }, [attendance]);

  // 1. Attendance Data (with Punch Exception Sub-view)
  const attendanceRows = useMemo(() => {
    return attendance
      .filter((a) => {
        const isException =
          a.status === 'MISSING_PUNCH' ||
          !a.punchIn ||
          a.punchIn === '--:--' ||
          !a.punchOut ||
          a.punchOut === '--:--' ||
          (a.workMinutes < 240 && a.status !== 'ABSENT' && a.status !== 'ON_LEAVE');

        if (attendanceSubView === 'EXCEPTIONS' && !isException) return false;

        return matchesCommon(
          a.employeeId,
          a.department,
          a.date,
          a.status,
          `${a.employeeName} ${a.employeeCode} ${a.department} ${a.status}`
        );
      })
      .map((a) => {
        const emp = employees.find((e) => e.id === a.employeeId);
        const hasMissingIn = !a.punchIn || a.punchIn === '--:--';
        const hasMissingOut = !a.punchOut || a.punchOut === '--:--';
        const punchExceptionType = hasMissingIn
          ? 'Missing Punch-In'
          : hasMissingOut
          ? 'Missing Punch-Out'
          : a.status === 'MISSING_PUNCH'
          ? 'Punch Anomaly'
          : 'None';

        return {
          'Date': a.date,
          'Employee ID': a.employeeCode || emp?.employeeId || a.employeeId,
          'Employee Name': a.employeeName,
          'Department': a.department,
          'Designation': emp?.designation || 'Staff',
          'Shift': a.shift || '09:30 - 18:30',
          'Punch In': a.punchIn || '--:--',
          'Punch Out': a.punchOut || '--:--',
          'Work Hours': (a.workMinutes / 60).toFixed(1),
          'Overtime (Hrs)': (a.overtimeMinutes / 60).toFixed(1),
          'Attendance Status': a.status,
          'Punch Exception': punchExceptionType,
          'Source': a.source || 'Biometric',
        };
      });
  }, [attendance, attendanceSubView, employees, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // 2. Consideration Data
  const considerationRows = useMemo(() => {
    return considerations
      .filter((c) =>
        matchesCommon(
          c.employeeId,
          c.department,
          c.date,
          c.status,
          `${c.employeeName} ${c.employeeCode} ${c.department} ${c.category} ${c.reason}`
        )
      )
      .map((c) => {
        const emp = employees.find((e) => e.id === c.employeeId);
        return {
          'Applied Date': c.appliedAt ? c.appliedAt.slice(0, 10) : c.date,
          'Incident Date': c.date,
          'Employee ID': c.employeeCode || emp?.employeeId || c.employeeId,
          'Employee Name': c.employeeName,
          'Department': c.department,
          'Category': c.category,
          'Reason': c.reason,
          'Status': c.status,
          'Manager Review Note': c.managerComment || '—',
          'Reviewed By': c.reviewedBy || 'Pending Review',
          'Decision Timestamp': c.reviewedAt ? new Date(c.reviewedAt).toLocaleString() : '—',
        };
      });
  }, [considerations, employees, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // 3. Late Coming Data (Priority Report)
  const lateComingRows = useMemo(() => {
    const shiftStart = activeSettings?.workStartTime || (activeSettings as any)?.shiftStartTime || '09:30';
    const graceMinutes = activeSettings?.gracePeriodMinutes || (activeSettings as any)?.shiftGraceMinutes || 15;
    const thresholdCount = activeSettings?.lateArrivalThresholdCount || (activeSettings as any)?.lateDeductionThresholdCount || 3;

    return attendance
      .filter((a) => {
        const isLate = a.status === 'LATE' || (a.lateMinutes && a.lateMinutes > 0);
        if (!isLate) return false;
        return matchesCommon(
          a.employeeId,
          a.department,
          a.date,
          a.status,
          `${a.employeeName} ${a.employeeCode} ${a.department}`
        );
      })
      .map((a) => {
        const emp = employees.find((e) => e.id === a.employeeId);
        const monthKey = `${a.employeeId}-${a.date.slice(0, 7)}`;
        const monthCount = monthlyLateCounts.get(monthKey) || 1;
        const thresholdExceeded = monthCount >= thresholdCount;

        return {
          'Date': a.date,
          'Employee ID': a.employeeCode || emp?.employeeId || a.employeeId,
          'Employee Name': a.employeeName,
          'Department': a.department,
          'Designation': emp?.designation || 'Staff',
          'Scheduled Start': shiftStart,
          'Grace Cut-off': '09:45',
          'Punch In': a.punchIn || '--:--',
          'Minutes Late': a.lateMinutes || 0,
          'Monthly Late Count': monthCount,
          'Threshold Policy': `Max ${thresholdCount}/mo`,
          'Limit Warning': thresholdExceeded ? 'EXCEEDED (LOP Deduction Risk)' : 'Within Limit',
          'Verification': a.verifiedByManager ? 'Manager Verified' : 'Unverified',
        };
      });
  }, [attendance, activeSettings, monthlyLateCounts, employees, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // 3B. Dedicated Late Salary Deduction Dataset (Requirement 6 - 20 Columns)
  const lateSalaryDeductionRows = useMemo(() => {
    // Group monthly totals per employee & month
    const empMonthTotals = new Map<string, { minutes: number; deduction: number }>();

    attendance.forEach((a) => {
      const emp = employees.find((e) => e.id === a.employeeId);
      const isLate =
        a.status === 'LATE' ||
        a.status === 'Late' ||
        (a.lateMinutes && a.lateMinutes > 0) ||
        (a.lateByMinutes && a.lateByMinutes > 0);

      if (isLate) {
        const lateCalc = calculateLateDeduction(emp, a, activeSettings);
        const monthKey = `${a.employeeId}-${a.date.slice(0, 7)}`;
        const prev = empMonthTotals.get(monthKey) || { minutes: 0, deduction: 0 };
        empMonthTotals.set(monthKey, {
          minutes: prev.minutes + lateCalc.chargeableLateMinutes,
          deduction: Number((prev.deduction + lateCalc.deductionAmount).toFixed(2)),
        });
      }
    });

    return attendance
      .filter((a) => {
        const isLate =
          a.status === 'LATE' ||
          a.status === 'Late' ||
          (a.lateMinutes && a.lateMinutes > 0) ||
          (a.lateByMinutes && a.lateByMinutes > 0);
        if (!isLate) return false;
        return matchesCommon(
          a.employeeId,
          a.department,
          a.date,
          a.status,
          `${a.employeeName} ${a.employeeCode} ${a.department}`
        );
      })
      .map((a) => {
        const emp = employees.find((e) => e.id === a.employeeId);
        const lateCalc = calculateLateDeduction(emp, a, activeSettings);
        const monthKey = `${a.employeeId}-${a.date.slice(0, 7)}`;
        const monthlyTotal = empMonthTotals.get(monthKey) || {
          minutes: lateCalc.chargeableLateMinutes,
          deduction: lateCalc.deductionAmount,
        };

        return {
          'Employee Name': a.employeeName,
          'Employee ID': a.employeeCode || emp?.employeeId || a.employeeId,
          'Department': a.department,
          'Designation': emp?.designation || 'Staff',
          'Monthly Salary Used': `₹${lateCalc.monthlySalary.toLocaleString()}`,
          'Salary Basis': lateCalc.salaryBasis,
          'Calculation Days (26)': 26,
          'Daily Salary': `₹${lateCalc.dailySalary.toFixed(2)}`,
          'Daily Working Minutes (480)': 480,
          'Per-Minute Deduction Rate': `₹${lateCalc.perMinuteRate.toFixed(4)}`,
          'Attendance Date': a.date,
          'Scheduled Shift Start': lateCalc.scheduledShiftStart,
          'Actual First In': lateCalc.actualFirstIn,
          'Actual Late Minutes': lateCalc.actualLateMinutes,
          'Grace Minutes': lateCalc.graceMinutes,
          'Chargeable Late Minutes': lateCalc.chargeableLateMinutes,
          'Deduction Amount': `₹${lateCalc.deductionAmount.toFixed(2)}`,
          'Monthly Total Late Minutes': monthlyTotal.minutes,
          'Monthly Total Late Deduction': `₹${monthlyTotal.deduction.toFixed(2)}`,
          'Payroll Adjustment Status': lateCalc.status,
        };
      });
  }, [attendance, employees, activeSettings, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // 4. Overtime Data
  const overtimeRows = useMemo(() => {
    const standardDailyHours = activeSettings?.fullDayWorkingHours || 8.5;
    const standardMinutes = standardDailyHours * 60;
    const hourlyRate = 250; // ₹250/hr default rate

    return attendance
      .filter((a) => {
        const hasOvertime = a.overtimeMinutes > 0 || a.workMinutes > standardMinutes;
        if (!hasOvertime) return false;
        return matchesCommon(
          a.employeeId,
          a.department,
          a.date,
          a.status,
          `${a.employeeName} ${a.employeeCode} ${a.department}`
        );
      })
      .map((a) => {
        const emp = employees.find((e) => e.id === a.employeeId);
        const otHours = Number(
          (a.overtimeMinutes > 0
            ? a.overtimeMinutes / 60
            : Math.max(0, (a.workMinutes - standardMinutes) / 60)
          ).toFixed(1)
        );
        const estimatedPayout = Math.round(otHours * hourlyRate);

        return {
          'Date': a.date,
          'Employee ID': a.employeeCode || emp?.employeeId || a.employeeId,
          'Employee Name': a.employeeName,
          'Department': a.department,
          'Designation': emp?.designation || 'Staff',
          'Scheduled Hours': `${standardDailyHours} hrs`,
          'Actual Worked (Hrs)': (a.workMinutes / 60).toFixed(1),
          'Overtime Hours': otHours,
          'Overtime Rate (INR/hr)': hourlyRate,
          'Estimated Payout (INR)': estimatedPayout,
          'Approval Status': otHours > 0 ? 'Approved (Auto-Logged)' : 'Pending',
        };
      });
  }, [attendance, activeSettings, employees, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // 5. Leave Data
  const leaveRows = useMemo(() => {
    return leaves
      .filter((l) =>
        matchesCommon(
          l.employeeId,
          l.department,
          l.startDate,
          l.status,
          `${l.employeeName} ${l.employeeCode} ${l.department} ${l.leaveType} ${l.reason}`
        )
      )
      .map((l) => {
        const emp = employees.find((e) => e.id === l.employeeId);
        const remainingTotal = emp?.leaveBalances
          ? (emp.leaveBalances.casual || 0) + (emp.leaveBalances.sick || 0) + (emp.leaveBalances.earned || 0)
          : 0;

        return {
          'Applied Date': l.appliedAt ? l.appliedAt.slice(0, 10) : l.startDate,
          'Employee ID': l.employeeCode || emp?.employeeId || l.employeeId,
          'Employee Name': l.employeeName,
          'Department': l.department,
          'Leave Type': l.leaveType,
          'Session': l.session || 'FULL_DAY',
          'Start Date': l.startDate,
          'End Date': l.endDate,
          'Total Days': l.daysCount,
          'Status': l.status,
          'Reason': l.reason,
          'Approved / Actioned By': l.approvedBy || (l.status === 'PENDING' ? 'Pending Action' : 'System'),
          'Remaining Balance (Days)': remainingTotal,
        };
      });
  }, [leaves, employees, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // 6. Punch Exceptions Dataset (for Attendance Sub-View & Final Combined Workbook Sheet)
  const punchExceptionRows = useMemo(() => {
    return attendance
      .filter((a) => {
        const isException =
          a.status === 'MISSING_PUNCH' ||
          !a.punchIn ||
          a.punchIn === '--:--' ||
          !a.punchOut ||
          a.punchOut === '--:--' ||
          (a.workMinutes < 240 && a.status !== 'ABSENT' && a.status !== 'ON_LEAVE');
        if (!isException) return false;
        return matchesCommon(
          a.employeeId,
          a.department,
          a.date,
          a.status,
          `${a.employeeName} ${a.employeeCode} ${a.department}`
        );
      })
      .map((a) => {
        const emp = employees.find((e) => e.id === a.employeeId);
        const hasMissingIn = !a.punchIn || a.punchIn === '--:--';
        const hasMissingOut = !a.punchOut || a.punchOut === '--:--';

        return {
          'Date': a.date,
          'Employee ID': a.employeeCode || emp?.employeeId || a.employeeId,
          'Employee Name': a.employeeName,
          'Department': a.department,
          'Exception Category': hasMissingIn ? 'Missing In' : hasMissingOut ? 'Missing Out' : 'Duration Anomaly',
          'Punch In': a.punchIn || '--:--',
          'Punch Out': a.punchOut || '--:--',
          'Recorded Duration': `${(a.workMinutes / 60).toFixed(1)} hrs`,
          'Status': a.status,
          'Biometric Source': a.source || 'Biometric Device',
          'Resolution Status': a.verifiedByManager ? 'Resolved by Manager' : 'Pending Resolution',
        };
      });
  }, [attendance, employees, permittedEmpIds, filterEmpId, filterDept, filterStatus, dateFrom, dateTo, searchQuery]);

  // Consolidated Rollup for Final Combined Report
  const consolidatedRollupRows = useMemo(() => {
    return permittedEmployees.map((emp) => {
      const empAttendance = attendance.filter((a) => a.employeeId === emp.id);
      const presentCount = empAttendance.filter((a) => a.status === 'PRESENT').length;
      const lateCount = empAttendance.filter((a) => a.status === 'LATE' || (a.lateMinutes && a.lateMinutes > 0)).length;
      const missedPunches = empAttendance.filter(
        (a) => a.status === 'MISSING_PUNCH' || !a.punchIn || a.punchIn === '--:--' || !a.punchOut || a.punchOut === '--:--'
      ).length;
      const empConsiderations = considerations.filter((c) => c.employeeId === emp.id && c.status === 'APPROVED').length;
      const otHours = empAttendance.reduce((acc, a) => acc + (a.overtimeMinutes || 0) / 60, 0);
      const leaveDays = leaves
        .filter((l) => l.employeeId === emp.id && l.status === 'APPROVED')
        .reduce((acc, l) => acc + (l.daysCount || 0), 0);

      const totalRecordedDays = empAttendance.length;
      const complianceRate =
        totalRecordedDays > 0
          ? Math.round(((presentCount + empConsiderations) / totalRecordedDays) * 100)
          : 100;

      return {
        'Employee ID': emp.employeeId,
        'Employee Name': emp.fullName,
        'Department': emp.department,
        'Designation': emp.designation,
        'Present Days': presentCount,
        'Late Arrivals': lateCount,
        'Missed Punches': missedPunches,
        'Approved Considerations': empConsiderations,
        'Overtime (Hrs)': Number(otHours.toFixed(1)),
        'Approved Leaves (Days)': leaveDays,
        'Late Deduction (INR)': `₹${empAttendance.reduce((acc, a) => acc + (a.lateSalaryDeduction || 0), 0).toFixed(2)}`,
        'Compliance Rate (%)': `${complianceRate}%`,
        'Status': emp.isExited ? 'Exited' : emp.isDeactivated ? 'Archived' : emp.status,
      };
    });
  }, [permittedEmployees, attendance, considerations, leaves]);

  // Executive Summary KPI calculations for Final Combined Report
  const executiveSummary = useMemo(() => {
    const totalStaff = permittedEmployees.length;
    const totalAttRecords = attendance.filter((a) => permittedEmpIds.has(a.employeeId)).length;
    const totalLateMarks = lateComingRows.length;
    const totalApprovedConsiderations = considerations.filter(
      (c) => permittedEmpIds.has(c.employeeId) && c.status === 'APPROVED'
    ).length;
    const totalOtHours = overtimeRows.reduce((acc, row) => acc + (Number(row['Overtime Hours']) || 0), 0);
    const totalOtPayout = overtimeRows.reduce((acc, row) => acc + (Number(row['Estimated Payout (INR)']) || 0), 0);
    const totalLeavesDays = leaves
      .filter((l) => permittedEmpIds.has(l.employeeId) && l.status === 'APPROVED')
      .reduce((acc, l) => acc + (l.daysCount || 0), 0);
    const totalExceptions = punchExceptionRows.length;
    const totalLateDeductions = lateSalaryDeductionRows.reduce((acc, row) => {
      const val = parseFloat(String(row['Deduction Amount']).replace(/[₹,]/g, '')) || 0;
      return acc + val;
    }, 0);
    const totalChargeableLateMinutes = lateSalaryDeductionRows.reduce((acc, row) => {
      return acc + (Number(row['Chargeable Late Minutes']) || 0);
    }, 0);

    return {
      totalStaff,
      totalAttRecords,
      totalLateMarks,
      totalApprovedConsiderations,
      totalOtHours: Number(totalOtHours.toFixed(1)),
      totalOtPayout,
      totalLeavesDays,
      totalExceptions,
      totalLateDeductions: Number(totalLateDeductions.toFixed(2)),
      totalChargeableLateMinutes,
    };
  }, [permittedEmployees, permittedEmpIds, attendance, lateComingRows, considerations, overtimeRows, leaves, punchExceptionRows, lateSalaryDeductionRows]);

  // Export Master Workbook (.xlsx) with 8 sheets (Requirement 6)
  const handleExportMasterWorkbook = () => {
    const summarySheetData = [
      { Metric: 'Report Generation Timestamp', Value: new Date().toLocaleString() },
      { Metric: 'Organization Name', Value: activeSettings?.companyName || 'Argos Watch HRMS' },
      { Metric: 'Total Employees In Scope', Value: executiveSummary.totalStaff },
      { Metric: 'Total Attendance Logs Analyzed', Value: executiveSummary.totalAttRecords },
      { Metric: 'Total Late Arrival Incidents', Value: executiveSummary.totalLateMarks },
      { Metric: 'Late Threshold Policy', Value: `Grace 15 mins (09:45), Max ${activeSettings?.lateArrivalThresholdCount || (activeSettings as any)?.lateDeductionThresholdCount || 3}/month` },
      { Metric: 'Total Chargeable Late Minutes', Value: `${executiveSummary.totalChargeableLateMinutes} mins` },
      { Metric: 'Total Late Salary Deduction (INR)', Value: `₹${executiveSummary.totalLateDeductions.toLocaleString()}` },
      { Metric: 'Total Considerations Approved', Value: executiveSummary.totalApprovedConsiderations },
      { Metric: 'Total Overtime Hours', Value: `${executiveSummary.totalOtHours} hrs` },
      { Metric: 'Total Estimated Overtime Payout (INR)', Value: `₹${executiveSummary.totalOtPayout.toLocaleString()}` },
      { Metric: 'Total Approved Leave Days', Value: `${executiveSummary.totalLeavesDays} days` },
      { Metric: 'Total Punch Exceptions / Anomalies', Value: executiveSummary.totalExceptions },
    ];

    const sheets = [
      { sheetName: 'Summary', data: summarySheetData },
      { sheetName: 'Attendance', data: attendanceRows },
      { sheetName: 'Considerations', data: considerationRows },
      { sheetName: 'Late Coming', data: lateComingRows },
      { sheetName: 'Overtime', data: overtimeRows },
      { sheetName: 'Leave', data: leaveRows },
      { sheetName: 'Punch Exceptions', data: punchExceptionRows },
      { sheetName: 'Late Salary Deduction', data: lateSalaryDeductionRows },
    ];

    const filename = `Argos_Master_Combined_Report_${new Date().toISOString().slice(0, 10)}`;
    exportMultiSheetExcelXLSX(sheets, filename);
  };

  // Determine current active report dataset & columns
  const currentDataset = useMemo(() => {
    switch (activeReport) {
      case 'attendance':
        return attendanceRows;
      case 'consideration':
        return considerationRows;
      case 'late-coming':
        return lateComingRows;
      case 'late-salary-deduction':
        return lateSalaryDeductionRows;
      case 'overtime':
        return overtimeRows;
      case 'leave':
        return leaveRows;
      case 'final-combined':
        return consolidatedRollupRows;
      default:
        return [];
    }
  }, [activeReport, attendanceRows, considerationRows, lateComingRows, lateSalaryDeductionRows, overtimeRows, leaveRows, consolidatedRollupRows]);

  // Dynamic columns for current table
  const columns = useMemo(() => {
    if (!currentDataset || currentDataset.length === 0) return [];
    return Object.keys(currentDataset[0]);
  }, [currentDataset]);

  return (
    <div className="space-y-6">
      {/* Module Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4 border-b border-[#CBCBCB] pb-4">
        <div>
          <h2 className="text-xl font-semibold text-[#141A17] tracking-tight">
            Reports & Operational Analytics
          </h2>
          <p className="text-xs text-[#70757D] mt-0.5">
            Six enterprise audit reports with real-time biometric and statutory integration
          </p>
        </div>

        {activeReport === 'final-combined' ? (
          <button
            onClick={handleExportMasterWorkbook}
            className="inline-flex items-center gap-2 px-4 py-2 bg-[#2D5A27] text-white hover:bg-[#23461E] rounded-md text-xs font-semibold shadow-sm transition-colors cursor-pointer"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
            <span>Export Master Workbook (.xlsx)</span>
          </button>
        ) : (
          <ExportDropdown
            onExport={(fmt) =>
              exportDataToFormat(
                currentDataset,
                `Argos_${activeReport}_Report_${new Date().toISOString().slice(0, 10)}`,
                fmt,
                `Argos Watch ${REPORT_TYPES.find((r) => r.id === activeReport)?.label}`
              )
            }
          />
        )}
      </div>

      {/* Six Primary Report Type Navigation Tabs */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-2">
        {REPORT_TYPES.map((rep) => {
          const Icon = rep.icon;
          const isActive = activeReport === rep.id;
          return (
            <button
              key={rep.id}
              onClick={() => setActiveReport(rep.id)}
              className={`text-left p-3 rounded-lg border transition-all cursor-pointer flex flex-col justify-between ${
                isActive
                  ? 'bg-white border-[#2D5A27] shadow-sm ring-1 ring-[#2D5A27]'
                  : 'bg-[#F9F9F8] border-[#CBCBCB] hover:bg-white hover:border-[#141A17]'
              }`}
            >
              <div className="flex items-center justify-between gap-1 mb-1.5">
                <span
                  className={`p-1.5 rounded-md ${
                    isActive ? 'bg-[#2D5A27]/10 text-[#2D5A27]' : 'bg-[#EAEAEA] text-[#70757D]'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                </span>
                <span
                  className={`text-[10px] font-semibold px-1.5 py-0.5 rounded ${
                    isActive
                      ? 'bg-[#2D5A27] text-white'
                      : 'bg-[#EAEAEA] text-[#70757D]'
                  }`}
                >
                  {rep.badge}
                </span>
              </div>
              <div>
                <p className={`text-xs font-semibold ${isActive ? 'text-[#141A17]' : 'text-[#70757D]'}`}>
                  {rep.label}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Attendance Report Specific Sub-view Selector (Requirement 8) */}
      {activeReport === 'attendance' && (
        <div className="flex items-center justify-between p-3 bg-white border border-[#CBCBCB] rounded-lg">
          <div className="flex items-center gap-2">
            <Filter className="w-4 h-4 text-[#70757D]" />
            <span className="text-xs font-medium text-[#141A17]">Attendance View:</span>
          </div>
          <div className="flex items-center bg-[#F9F9F8] p-0.5 rounded-md border border-[#CBCBCB]">
            <button
              onClick={() => setAttendanceSubView('ALL')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer ${
                attendanceSubView === 'ALL'
                  ? 'bg-white text-[#141A17] shadow-xs'
                  : 'text-[#70757D] hover:text-[#141A17]'
              }`}
            >
              All Attendance Records ({attendance.length})
            </button>
            <button
              onClick={() => setAttendanceSubView('EXCEPTIONS')}
              className={`px-3 py-1 text-xs font-medium rounded transition-colors cursor-pointer flex items-center gap-1.5 ${
                attendanceSubView === 'EXCEPTIONS'
                  ? 'bg-amber-100 text-amber-900 font-semibold shadow-xs'
                  : 'text-[#70757D] hover:text-[#141A17]'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
              <span>Punch Exceptions Only ({punchExceptionRows.length})</span>
            </button>
          </div>
        </div>
      )}

      {/* Executive KPI Summary for Final Combined Report */}
      {activeReport === 'final-combined' && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
            <div className="p-3 bg-white rounded-lg border border-[#CBCBCB]">
              <p className="text-[11px] font-medium text-[#70757D]">Active In Scope</p>
              <p className="text-lg font-bold text-[#141A17] mt-1">{executiveSummary.totalStaff}</p>
              <p className="text-[10px] text-[#70757D] mt-0.5">Employees</p>
            </div>
            <div className="p-3 bg-white rounded-lg border border-[#CBCBCB]">
              <p className="text-[11px] font-medium text-[#70757D]">Attendance Logs</p>
              <p className="text-lg font-bold text-[#141A17] mt-1">{executiveSummary.totalAttRecords}</p>
              <p className="text-[10px] text-[#70757D] mt-0.5">Shift records</p>
            </div>
            <div className="p-3 bg-amber-50 rounded-lg border border-amber-200">
              <p className="text-[11px] font-medium text-amber-800">Late Arrivals</p>
              <p className="text-lg font-bold text-amber-900 mt-1">{executiveSummary.totalLateMarks}</p>
              <p className="text-[10px] text-amber-700 mt-0.5">&gt; 15m grace window</p>
            </div>
            <div className="p-3 bg-rose-50 rounded-lg border border-rose-200">
              <p className="text-[11px] font-medium text-rose-800">Late Deductions</p>
              <p className="text-lg font-bold text-rose-900 mt-1">₹{executiveSummary.totalLateDeductions.toLocaleString()}</p>
              <p className="text-[10px] text-rose-700 mt-0.5">{executiveSummary.totalChargeableLateMinutes}m chargeable</p>
            </div>
            <div className="p-3 bg-white rounded-lg border border-[#CBCBCB]">
              <p className="text-[11px] font-medium text-[#70757D]">Considerations</p>
              <p className="text-lg font-bold text-[#2D5A27] mt-1">{executiveSummary.totalApprovedConsiderations}</p>
              <p className="text-[10px] text-[#70757D] mt-0.5">Approved waivers</p>
            </div>
            <div className="p-3 bg-white rounded-lg border border-[#CBCBCB]">
              <p className="text-[11px] font-medium text-[#70757D]">Overtime Hours</p>
              <p className="text-lg font-bold text-[#141A17] mt-1">{executiveSummary.totalOtHours}h</p>
              <p className="text-[10px] text-emerald-700 mt-0.5">₹{executiveSummary.totalOtPayout.toLocaleString()} payout</p>
            </div>
            <div className="p-3 bg-white rounded-lg border border-[#CBCBCB]">
              <p className="text-[11px] font-medium text-[#70757D]">Leaves Taken</p>
              <p className="text-lg font-bold text-[#141A17] mt-1">{executiveSummary.totalLeavesDays}</p>
              <p className="text-[10px] text-[#70757D] mt-0.5">Approved days</p>
            </div>
            <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
              <p className="text-[11px] font-medium text-orange-800">Punch Exceptions</p>
              <p className="text-lg font-bold text-orange-900 mt-1">{executiveSummary.totalExceptions}</p>
              <p className="text-[10px] text-orange-700 mt-0.5">Missing In/Out</p>
            </div>
          </div>

          <div className="p-4 bg-[#F9F9F8] border border-[#CBCBCB] rounded-lg flex flex-col md:flex-row md:items-center md:justify-between gap-4">
            <div>
              <h3 className="text-xs font-semibold text-[#141A17] uppercase tracking-wider">
                Consolidated Master Workbook Architecture
              </h3>
              <p className="text-xs text-[#70757D] mt-1">
                The master workbook compiles 8 dedicated, styled worksheets: <strong>Summary</strong>, <strong>Attendance</strong>, <strong>Considerations</strong>, <strong>Late Coming</strong>, <strong>Overtime</strong>, <strong>Leave</strong>, <strong>Punch Exceptions</strong>, and <strong>Late Salary Deduction</strong> into a single .xlsx file.
              </p>
            </div>
            <button
              onClick={handleExportMasterWorkbook}
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-[#2D5A27] text-white hover:bg-[#23461E] rounded-md text-xs font-semibold shadow-sm transition-colors cursor-pointer whitespace-nowrap"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-200" />
              <span>Download Master Workbook (.xlsx)</span>
            </button>
          </div>
        </div>
      )}

      {/* Universal Filter Toolbar */}
      <div className="bg-white p-4 rounded-lg border border-[#CBCBCB] space-y-3">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3">
          {/* Search Box */}
          <div className="relative">
            <Search className="w-3.5 h-3.5 text-[#70757D] absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search records..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-3 py-1.5 bg-[#F9F9F8] border border-[#CBCBCB] rounded-md text-xs text-[#141A17] placeholder:text-[#70757D] focus:outline-none focus:border-[#2D5A27]"
            />
          </div>

          {/* Department Filter */}
          <div>
            <select
              value={filterDept}
              onChange={(e) => setFilterDept(e.target.value)}
              className="w-full px-3 py-1.5 bg-[#F9F9F8] border border-[#CBCBCB] rounded-md text-xs text-[#141A17] focus:outline-none focus:border-[#2D5A27]"
            >
              {departments.map((dept) => (
                <option key={dept} value={dept}>
                  {dept === 'ALL' ? 'All Departments' : dept}
                </option>
              ))}
            </select>
          </div>

          {/* Date Range From */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-[#70757D] whitespace-nowrap">From:</span>
            <input
              type="date"
              value={dateFrom}
              onChange={(e) => setDateFrom(e.target.value)}
              className="w-full px-2 py-1.5 bg-[#F9F9F8] border border-[#CBCBCB] rounded-md text-xs text-[#141A17] focus:outline-none focus:border-[#2D5A27]"
            />
          </div>

          {/* Date Range To */}
          <div className="flex items-center gap-2">
            <span className="text-[11px] text-[#70757D] whitespace-nowrap">To:</span>
            <input
              type="date"
              value={dateTo}
              onChange={(e) => setDateTo(e.target.value)}
              className="w-full px-2 py-1.5 bg-[#F9F9F8] border border-[#CBCBCB] rounded-md text-xs text-[#141A17] focus:outline-none focus:border-[#2D5A27]"
            />
          </div>
        </div>

        {/* Filter Reset */}
        {(dateFrom || dateTo || filterDept !== 'ALL' || filterStatus !== 'ALL' || searchQuery) && (
          <div className="flex items-center justify-between pt-2 border-t border-[#EAEAEA]">
            <p className="text-[11px] text-[#70757D]">Filters active</p>
            <button
              onClick={() => {
                setDateFrom('');
                setDateTo('');
                setFilterDept('ALL');
                setFilterStatus('ALL');
                setSearchQuery('');
              }}
              className="text-[11px] text-[#2D5A27] hover:underline cursor-pointer font-medium"
            >
              Reset All Filters
            </button>
          </div>
        )}
      </div>

      {/* Report Records Table */}
      <div className="bg-white rounded-lg border border-[#CBCBCB] overflow-hidden shadow-xs">
        <div className="px-4 py-3 border-b border-[#CBCBCB] flex items-center justify-between bg-[#F9F9F8]">
          <div className="flex items-center gap-2">
            <span className="text-xs font-semibold text-[#141A17]">
              {REPORT_TYPES.find((r) => r.id === activeReport)?.label}
            </span>
            <span className="text-[11px] font-medium text-[#70757D]">
              ({currentDataset.length} {currentDataset.length === 1 ? 'record' : 'records'})
            </span>
          </div>

          <div className="flex items-center gap-2">
            <ExportDropdown
              onExport={(fmt) =>
                exportDataToFormat(
                  currentDataset,
                  `Argos_${activeReport}_Report_${new Date().toISOString().slice(0, 10)}`,
                  fmt,
                  `Argos Watch ${REPORT_TYPES.find((r) => r.id === activeReport)?.label}`
                )
              }
            />
          </div>
        </div>

        {currentDataset.length === 0 ? (
          <div className="py-12 text-center">
            <FileText className="w-8 h-8 text-[#CBCBCB] mx-auto mb-2" />
            <p className="text-xs font-medium text-[#141A17]">No records match the selected criteria</p>
            <p className="text-[11px] text-[#70757D] mt-0.5">Try clearing or adjusting date ranges and filters</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-[#F9F9F8] border-b border-[#CBCBCB] text-[#70757D] font-medium">
                <tr>
                  {columns.map((col) => (
                    <th key={col} className="px-4 py-2.5 whitespace-nowrap text-[11px] font-semibold text-[#141A17]">
                      {col}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EAEAEA]">
                {currentDataset.slice(0, 100).map((row, idx) => (
                  <tr key={idx} className="hover:bg-[#F9F9F8] transition-colors">
                    {columns.map((col) => {
                      const val = row[col];

                      // Special styling for Late Warning / Status flags
                      if (col === 'Limit Warning') {
                        const isExceeded = String(val).includes('EXCEEDED');
                        return (
                          <td key={col} className="px-4 py-2.5 whitespace-nowrap">
                            <span
                              className={`inline-flex items-center px-2 py-0.5 rounded text-[11px] font-semibold ${
                                isExceeded
                                  ? 'bg-rose-100 text-rose-800 border border-rose-200'
                                  : 'bg-emerald-50 text-emerald-800'
                              }`}
                            >
                              {val}
                            </span>
                          </td>
                        );
                      }

                      if (col === 'Punch Exception') {
                        const isException = val !== 'None';
                        return (
                          <td key={col} className="px-4 py-2.5 whitespace-nowrap">
                            {isException ? (
                              <span className="inline-flex items-center px-2 py-0.5 rounded text-[11px] font-medium bg-amber-100 text-amber-900 border border-amber-200">
                                {val}
                              </span>
                            ) : (
                              <span className="text-[#70757D]">—</span>
                            )}
                          </td>
                        );
                      }

                      if (col === 'Attendance Status' || col === 'Status') {
                        return (
                          <td key={col} className="px-4 py-2.5 whitespace-nowrap">
                            <StatusBadge status={String(val)} />
                          </td>
                        );
                      }

                      return (
                        <td key={col} className="px-4 py-2.5 whitespace-nowrap text-[#141A17]">
                          {val ?? '—'}
                        </td>
                      );
                    })}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {currentDataset.length > 100 && (
          <div className="p-3 bg-[#F9F9F8] border-t border-[#CBCBCB] text-center text-xs text-[#70757D]">
            Showing first 100 of {currentDataset.length} records. Export full report via .xlsx or .csv to view all rows.
          </div>
        )}
      </div>
    </div>
  );
}
