export enum UserRole {
  ADMIN = 'ADMIN',
  HR = 'HR',
  MANAGER = 'MANAGER',
  EMPLOYEE = 'EMPLOYEE',
}

export type Role = UserRole | 'ADMIN' | 'HR' | 'MANAGER' | 'EMPLOYEE';

export type PrimaryModuleId =
  | 'dashboard'
  | 'manage-access'
  | 'people'
  | 'departments-mgmt'
  | 'my-team'
  | 'my-profile'
  | 'approvals'
  | 'org-tree'
  | 'attendance'
  | 'leave'
  | 'payroll'
  | 'company-info'
  | 'considerations'
  | 'documents'
  | 'calendar'
  | 'reports'
  | 'more'
  | 'settings';

export type ModuleId = PrimaryModuleId;

export type AccessLevel = 'Viewer' | 'Controller';
export type AccountStatus = 'Active' | 'Suspended' | 'Invited' | 'Inactive';

export interface ModuleActionPermission {
  view: boolean;
  create: boolean;
  edit: boolean;
  approve: boolean;
  delete: boolean;
  export: boolean;
}

export interface UserAccessRecord {
  employeeId: string;
  fullName: string;
  email: string;
  role: UserRole;
  accessLevel: AccessLevel;
  accountStatus: AccountStatus;
  department: string;
  designation: string;
  managerId?: string;
  managerName?: string;
  lastLogin?: string;
  invitationStatus: 'Accepted' | 'Pending' | 'Invited';
  modulePermissions: Record<string, ModuleActionPermission>;
  updatedAt: string;
  updatedBy: string;
  adminNote?: string;
}

export interface EducationRecord {
  id: string;
  schoolName: string;
  degree: string;
  fieldOfStudy: string;
  completionDate: string;
  notes?: string;
}

export interface ExperienceRecord {
  id: string;
  occupation: string;
  company: string;
  workSummary: string;
  duration: string;
  currentlyWorking: boolean;
}

export interface MasterLetterTemplate {
  id: string;
  title: string;
  name?: string;
  type: 'Offer' | 'Internship' | 'Appointment' | 'Confirmation' | 'Experience' | 'Termination' | string;
  subject: string;
  bodyTemplate: string;
  placeholders: string[];
  version: number;
  status: 'Active' | 'Archived' | 'Draft';
  createdBy: string;
  updatedAt: string;
}

export interface LetterHistoryRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  letterType: string;
  templateName: string;
  templateVersion: number;
  content: string;
  generatedBy: string;
  generatedByName: string;
  generatedAt: string;
  sentBy?: string;
  sentByName?: string;
  sentAt?: string;
  deliveryStatus: 'Draft' | 'Generated' | 'Sent' | 'Delivered' | 'Failed';
  exportCount: number;
  lastExportedAt?: string;
  status: string;
  failureDetails?: string;
}

export type MoreSubModuleId =
  | 'departments'
  | 'org-tree'
  | 'policies'
  | 'announcements'
  | 'letters'
  | 'letter-templates'
  | 'letter-history'
  | 'documents'
  | 'internships'
  | 'holidays'
  | 'birthdays'
  | 'considerations'
  | 'reports'
  | 'activity-log'
  | 'settings';

export type EmployeeType =
  | 'Permanent'
  | 'Probation'
  | 'Intern'
  | 'Intern / Internship'
  | 'Contract'
  | 'Temporary'
  | 'Part-time'
  | 'Consultant'
  | 'Other';

export const EMPLOYEE_TYPE_OPTIONS: EmployeeType[] = [
  'Permanent',
  'Probation',
  'Intern',
  'Intern / Internship',
  'Contract',
  'Temporary',
  'Part-time',
  'Consultant',
  'Other',
];

export interface EmployeeAddress {
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
}

export interface CustomCompanyRule {
  id: string;
  title: string;
  category: 'Timing & Shift' | 'Half-Day Rule' | 'Late Coming' | 'Leave Policy' | 'Payroll & Deductions' | 'General Conduct' | string;
  description: string;
  effectiveFrom: string;
  updatedBy: string;
}

export interface WeekdaySchedule {
  day: 'Monday' | 'Tuesday' | 'Wednesday' | 'Thursday' | 'Friday' | 'Saturday' | 'Sunday';
  isOpen: boolean;
  startTime: string;
  endTime: string;
  breakStart?: string;
  breakEnd?: string;
  isHalfDay?: boolean;
  notes?: string;
}

export interface NoticePeriodDetails {
  applicable: boolean;
  duration?: number;
  durationValue?: number;
  durationUnit?: "Days" | "Months" | string;
  unit?: string;
  noticeType?: string;
  startDate: string;
  expectedLastWorkingDate: string;
  actualLastWorkingDate?: string;
  status: "Not Started" | "Active" | "Completed" | "Waived" | "Cancelled" | string;
  internalNotes?: string;
  createdBy?: string;
  createdAt?: string;
  updatedAt?: string;
  updatedBy?: string;
}

export interface FinalExitDetails {
  employeeId?: string;
  employeeName?: string;
  exitType: "Resignation" | "Termination" | string;
  effectiveLastDate?: string;
  effectiveLastWorkingDate?: string;
  noticePeriodServed?: boolean;
  noticeStartDate?: string;
  noticeEndDate?: string;
  noticePeriodDays?: number;
  exitReason: string;
  internalNote?: string;
  mandatoryInternalNote?: string;
  additionalRemarks?: string;
  selectedLetterTemplateId?: string;
  selectedLetterTemplateTitle?: string;
  generatedLetterId?: string;
  initiatedBy?: string;
  initiatedAt?: string;
  finalizedBy?: string;
  finalizedAt?: string;
  handoverCompleted?: boolean;
  clearanceStatus?: "Pending" | "Completed" | string;
  status?: "EXIT_INITIATED" | "FINAL_EXIT_COMPLETED" | string;
}

export interface EmployeeDeactivationRecord {
  deactivatedAt: string;
  deactivatedBy: string;
  reason?: string;
  isRestored?: boolean;
  restoredAt?: string;
  restoredBy?: string;
  restoreReason?: string;
}

export interface CompanySettings {
  companyName: string;
  legalEntityName: string;
  registrationNumber: string;
  headquartersAddress: string;
  aboutCompany: string;
  workingDays: string[];
  workStartTime: string;
  workEndTime: string;
  lunchBreakWindow: string;
  firstHalfTiming: string;
  secondHalfTiming: string;
  gracePeriodMinutes: number;
  lateArrivalThresholdCount: number;
  lunchStartTime?: string;
  lunchEndTime?: string;
  lunchDurationMinutes?: number;
  fullDayWorkingHours?: number;
  firstHalfStartTime?: string;
  firstHalfEndTime?: string;
  firstHalfHours?: number;
  secondHalfStartTime?: string;
  secondHalfEndTime?: string;
  secondHalfHours?: number;
  annualLeaveEntitlement?: number;
  updatedAt?: string;
  updatedBy?: string;
  lateDeductionRule: string;
  halfDayHoursThreshold: number;
  fullDayHoursThreshold: number;
  casualLeaveQuota: number;
  sickLeaveQuota: number;
  earnedLeaveQuota: number;
  managerCanViewTeamSalary: boolean;
  managerCanViewTeamDocuments: boolean;
  autoDeductUnapprovedLate: boolean;
  currencySymbol: string;
  customRules: CustomCompanyRule[];
  weekdaySchedules?: WeekdaySchedule[];
  overtimeThresholdHours?: number;
  ipRestrictionEnabled?: boolean;
  allowedIpAddresses?: string[];
  probationDurationMonths?: number;
  probationAutoConfirmation?: boolean;
  letterNumberingPrefix?: string;
  designationsList?: string[];
  locationsList?: string[];
  lateDeductionSalaryBasis?: 'Monthly Gross' | 'Basic Salary';
  lateDeductionGraceExempt?: boolean;
}

export interface Department {
  id: string;
  name: string;
  code: string;
  managerId: string;
  managerName: string;
  parentDepartmentId?: string | null;
  location: string;
  description: string;
  annualBudget: number;
  headcount?: number;
  teams?: string[];
  subdepartments?: Department[];
  isArchived?: boolean;
}

export interface SalaryRevision {
  id: string;
  effectiveDate: string;
  previousGross: number;
  newGross: number;
  incrementPercent: number;
  reason: string;
  approvedBy: string;
}

export interface Employee {
  id: string;
  uid: string;
  managerUid: string;
  fullName: string;
  email: string;
  phone: string;
  role: UserRole;
  designation: string;
  department: string;
  managerId: string;
  managerName: string;
  status: 'Active' | 'Probation' | 'On Notice' | 'Inactive' | string;
  employmentType: 'Full-Time' | 'Probation' | 'Contract' | 'Intern' | string;
  employeeType?: EmployeeType;
  structuredAddress?: EmployeeAddress;
  location: string;
  joiningDate: string;
  probationEndDate: string;
  dob: string;
  gender: 'Male' | 'Female' | 'Non-binary' | string;
  address: string;
  emergencyContactName: string;
  emergencyContactPhone: string;
  avatarUrl: string;
  bankName: string;
  bankAccountNumber: string;
  ifscCode: string;
  panNumber: string;
  aadhaarNumber?: string;
  uanNumber?: string;
  pfNumber?: string;
  salary: {
    baseSalary: number;
    hra: number;
    specialAllowance: number;
    pfDeduction: number;
    taxDeduction: number;
    professionalTax: number;
  };
  salaryHistory: SalaryRevision[];
  leaveBalance: {
    casualTotal: number;
    casualUsed: number;
    sickTotal: number;
    sickUsed: number;
    earnedTotal: number;
    earnedUsed: number;
  };
  employeeCode?: string;
  firstName?: string;
  middleName?: string;
  lastName?: string;
  personalEmail?: string;
  officialEmail?: string;
  experienceYears?: number;
  sourceOfHire?: string;
  skillSet?: string[];
  highestQualification?: string;
  additionalInformation?: string;
  tentativeJoiningDate?: string;
  offerLetterUrl?: string;
  workLocation?: string;
  workMode?: 'On-site' | 'Remote' | 'Hybrid' | string;
  shiftSchedule?: string;
  probationDurationMonths?: number;
  probationStatus?: 'In Probation' | 'Confirmed Permanent' | 'Extended' | 'Not Applicable' | string;
  probationReviewReminder?: boolean;
  presentAddress?: EmployeeAddress;
  permanentAddress?: EmployeeAddress;
  education?: EducationRecord[];
  experience?: ExperienceRecord[];
  accessLevel?: AccessLevel;
  accountStatus?: AccountStatus;
  lastLogin?: string;
  invitationStatus?: 'Accepted' | 'Pending' | 'Invited';
  modulePermissions?: Record<string, ModuleActionPermission>;
  isDeactivated?: boolean;
  deactivatedAt?: string;
  deactivatedBy?: string;
  deactivationReason?: string;
  isExited?: boolean;
  finalExit?: FinalExitDetails;
  deactivationHistory?: EmployeeDeactivationRecord[];
  noticePeriod?: NoticePeriodDetails;
}

export interface EmployeeRecord {
  id: string;
  employeeCode: string;
  fullName: string;
  email: string;
  phone: string;
  department: string;
  designation: string;
  role: Role;
  reportingManager: string;
  managerId?: string;
  joiningDate: string;
  status: 'ACTIVE' | 'ON_LEAVE' | 'PROBATION' | 'INACTIVE' | string;
  employeeType?: EmployeeType;
  structuredAddress?: EmployeeAddress;
  address?: string;
  location: string;
  annualCTC: number;
  panNumber: string;
  bankAccount: string;
  avatarInitials?: string;
}

export type PunchType = 'IN' | 'OUT';
export type PunchSource =
  | 'ESSL Biometric'
  | 'Mobile App'
  | 'Web Portal'
  | 'Manual Correction'
  | 'System Auto-Sync'
  | string;

export interface PunchEvent {
  id: string;
  employeeId: string;
  timestamp: string;
  time: string; // e.g. "09:25" or "09:25 AM"
  type: PunchType;
  source: PunchSource;
  sourceDeviceId?: string;
  isFirstIn?: boolean;
  isLastOut?: boolean;
  isIntermediate?: boolean;
  isManualCorrection?: boolean;
  manualCorrectionReason?: string;
  correctedBy?: string;
  correctedAt?: string;
  notes?: string;
}

export interface AttendanceRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode: string;
  department: string;
  managerId?: string;
  uid?: string;
  managerUid?: string;
  date: string;
  checkIn?: string | null;
  checkOut?: string | null;
  punchIn?: string | null;
  punchOut?: string | null;
  punchInTimestamp?: number | null;
  status: 'Present' | 'Late' | 'Half Day' | 'Absent' | 'On Leave' | 'PRESENT' | 'LATE' | 'HALF_DAY' | 'ABSENT' | 'ON_LEAVE' | string;
  isLate?: boolean;
  lateMinutes?: number;
  lateByMinutes?: number;
  earlyDepartureMinutes?: number;
  workingHours?: number;
  workHours?: number;
  totalHours?: number;
  productiveHours?: number;
  overtimeHours?: number;
  notes?: string;
  considerationId?: string;
  considerationStatus?: 'Pending' | 'Approved' | 'Rejected' | string;
  regularizationRequested?: boolean;
  regularizationReason?: string;
  regularizationStatus?: 'NONE' | 'PENDING' | 'APPROVED' | 'REJECTED';
  source?: 'BIOMETRIC' | 'MANUAL' | 'SYSTEM' | 'WEB' | string;
  isManualCorrection?: boolean;
  manualCorrectionReason?: string;
  correctedBy?: string;
  correctedAt?: string;
  previousPunchIn?: string | null;
  previousPunchOut?: string | null;
  // Multi-punch tracking (Requirement 1)
  punches?: PunchEvent[];
  totalPunchIns?: number;
  totalPunchOuts?: number;
  firstInTime?: string | null;
  lastOutTime?: string | null;
  validPunchPairsCount?: number;
  hasUnmatchedPunch?: boolean;
  unmatchedPunchNote?: string;
  // Salary-based per-minute late deduction (Requirement 5)
  chargeableLateMinutes?: number;
  perMinuteDeductionRate?: number;
  dailySalaryUsed?: number;
  monthlySalaryUsed?: number;
  salaryBasisUsed?: string;
  lateSalaryDeduction?: number;
  payrollAdjustmentStatus?: 'Calculated - Pending Approval' | 'Approved' | 'Adjusted in Payroll' | 'Exempted';
}

export type LeaveType = 'Casual' | 'Sick' | 'Earned' | 'Unpaid' | 'CASUAL' | 'SICK' | 'EARNED' | 'UNPAID' | 'COMP_OFF';

export type ApprovalWorkflowStatus =
  | 'PENDING_MANAGER'
  | 'PENDING_HR'
  | 'APPROVED'
  | 'REJECTED'
  | 'Pending'
  | 'Approved'
  | 'Rejected';

export interface ApprovalTimelineStep {
  stage: 'SUBMITTED' | 'MANAGER_REVIEW' | 'HR_FINAL_REVIEW';
  actorId?: string;
  actorName: string;
  actorRole: UserRole | Role;
  action: 'SUBMITTED' | 'APPROVED' | 'REJECTED';
  note: string;
  timestamp: string;
}

export interface LeaveRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  managerId?: string;
  uid?: string;
  managerUid?: string;
  leaveType: LeaveType | string;
  startDate: string;
  endDate: string;
  days: number;
  isHalfDay?: boolean;
  halfDaySession?: string;
  reason: string;
  appliedBy?: string;
  appliedOn?: string;
  status: ApprovalWorkflowStatus;
  decisionNote?: string;
  rejectionReason?: string;
  decidedBy?: string;
  decidedAt?: string;
  approvedBy?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  rejectedByRole?: UserRole | Role | string;
  managerApprovedBy?: string;
  managerApprovedAt?: string;
  managerDecisionNote?: string;
  hrApprovedBy?: string;
  hrApprovedAt?: string;
  hrDecisionNote?: string;
  submittedByManager?: boolean;
  submittedByManagerName?: string;
  submittedByManagerId?: string;
  approvalHistory?: ApprovalTimelineStep[];
  createdAt?: string;
}

export interface ConsiderationRequest {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  department: string;
  managerId?: string;
  uid?: string;
  managerUid?: string;
  date: string;
  type:
    | 'Late Arrival Waiver'
    | 'Missed Punch Regularization'
    | 'Half-Day Waiver'
    | 'Salary Deduction Waiver'
    | 'Work From Home'
    | 'Client Visit'
    | 'Attendance Regularization'
    | 'Other'
    | string;
  customType?: string;
  category?: string;
  title?: string;
  description?: string;
  reason: string;
  supportingNote?: string;
  supportingDocument?: string;
  origin?: 'EMPLOYEE_SUBMITTED' | 'MANAGER_ON_BEHALF' | 'HR_SUBMITTED';
  submittedById?: string;
  submittedByRole: UserRole | Role;
  submittedByName: string;
  submittedOnBehalfOfName?: string;
  submittedAt?: string;
  raisedBy?: string;
  raisedByRole?: Role;
  status: ApprovalWorkflowStatus;
  managerApprovedBy?: string;
  managerApprovedAt?: string;
  managerDecisionNote?: string;
  hrApprovedBy?: string;
  hrApprovedAt?: string;
  hrDecisionNote?: string;
  decisionNote?: string;
  rejectionReason?: string;
  rejectedBy?: string;
  rejectedAt?: string;
  rejectedByRole?: UserRole | Role | string;
  hrComment?: string;
  decidedBy?: string;
  decisionDate?: string;
  affectsAttendancePenalty?: boolean;
  affectsSalaryDeduction?: boolean;
  approvalHistory?: ApprovalTimelineStep[];
  deductionAmountSaved?: number;
  createdAt?: string;
}

export interface PayrollRecord {
  id: string;
  employeeId: string;
  employeeName: string;
  employeeCode?: string;
  designation: string;
  department: string;
  managerId?: string;
  uid?: string;
  managerUid?: string;
  month: string;
  workingDays?: number;
  presentDays?: number;
  paidDays?: number;
  paidLeaveDays?: number;
  unpaidLeaveDays?: number;
  lopDays?: number;
  lateOccurrences: number;
  baseSalary?: number;
  basicPay?: number;
  hra: number;
  specialAllowance: number;
  bonus?: number;
  overtimePay?: number;
  grossMonthly?: number;
  grossEarnings?: number;
  pfDeduction: number;
  taxDeduction?: number;
  tdsDeduction?: number;
  professionalTax: number;
  attendanceDeduction?: number;
  lopDeduction?: number;
  latePenaltyDeduction?: number;
  considerationAdjustment?: number;
  totalDeductions?: number;
  netSalary?: number;
  netPayable?: number;
  status: 'Processed' | 'Paid' | 'Pending' | 'PROCESSED' | 'DISBURSED' | 'DRAFT' | string;
  paidDate?: string;
  disbursedOn?: string;
}

export interface PolicyVersion {
  version: string;
  updatedAt: string;
  summary: string;
  updatedBy: string;
}

export interface PolicyAcknowledgement {
  employeeId: string;
  employeeName: string;
  version: string;
  acknowledgedAt: string;
}

export interface CompanyPolicy {
  id: string;
  title: string;
  category: 'Attendance' | 'Leave' | 'Payroll' | 'Code of Conduct' | 'IT & Security' | 'Benefits' | string;
  version: string;
  status: 'Active' | 'Draft' | 'Archived' | string;
  effectiveDate: string;
  targetDepartment: string;
  requiresAcknowledgement: boolean;
  summary: string;
  content: string;
  versions: PolicyVersion[];
  acknowledgements: PolicyAcknowledgement[];
}

export interface PolicyItem {
  id: string;
  code: string;
  title: string;
  category: string;
  version: string;
  effectiveDate: string;
  summary: string;
  clauses: string[];
  mandatoryAck?: boolean;
}

export interface Announcement {
  id: string;
  title: string;
  description: string;
  priority: 'Normal' | 'Important' | 'Urgent' | string;
  publishDate: string;
  expiryDate: string;
  targetAudience: 'Everyone' | 'Department' | 'Managers Only' | string;
  targetDepartment?: string;
  attachmentName?: string;
  createdBy: string;
  category?: string;
  body?: string;
  publishedOn?: string;
  publishedAt?: string;
  audience?: string;
}

export interface AnnouncementItem {
  id: string;
  title: string;
  body: string;
  category: string;
  priority: string;
  publishedBy: string;
  publishedOn: string;
  audience: string;
}

export interface EmployeeDocument {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  managerId: string;
  title: string;
  category: 'Identity' | 'Contracts' | 'Certificates' | 'Tax & Bank' | 'Letters' | 'Payslip' | string;
  fileName: string;
  fileSize: string;
  uploadedAt: string;
  expiryDate?: string;
  status: 'Verified' | 'Pending Review' | 'Expiring Soon' | 'Rejected' | string;
  uploadedBy: string;
}

export interface DocumentVaultItem {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  title: string;
  category: string;
  fileSize: string;
  uploadedOn: string;
  uploadedAt?: string;
  status: string;
  verified?: boolean;
  verifiedBy?: string;
}

export interface GeneratedLetter {
  id: string;
  employeeId: string;
  employeeName: string;
  department: string;
  designation: string;
  templateType:
    | 'Offer Letter'
    | 'Appointment Letter'
    | 'Salary Revision Letter'
    | 'Experience Letter'
    | 'Warning / Show Cause Notice'
    | 'Internship Completion Certificate'
    | string;
  subject: string;
  content: string;
  issuedDate: string;
  issuedBy: string;
}

export interface InternshipRecord {
  id: string;
  internCode: string;
  fullName: string;
  internName?: string;
  email: string;
  phone: string;
  college: string;
  department: string;
  mentorId: string;
  mentorName: string;
  startDate: string;
  endDate: string;
  duration?: string;
  stipend: number;
  status: 'Active' | 'Completed' | 'Converted to FTE' | string;
  projectTitle: string;
  performanceScore?: number;
  joiningDate?: string;
}

export interface HolidayRecord {
  id: string;
  name: string;
  date: string;
  dayOfWeek: string;
  day?: string;
  type: 'National' | 'Regional' | 'Floating' | string;
  applicableLocations: string;
  applicableBranches?: string;
  isOptional?: boolean;
}

export interface HolidayItem {
  id: string;
  name: string;
  date: string;
  day: string;
  type: string;
  isOptional?: boolean;
}

export interface NotificationItem {
  id: string;
  targetRoles: UserRole[];
  targetEmployeeId?: string;
  title: string;
  message: string;
  category: 'Leave' | 'Consideration' | 'Payroll' | 'Document' | 'Announcement' | 'Birthday' | string;
  createdAt: string;
  isRead: boolean;
  linkModule: PrimaryModuleId;
  linkSubModule?: MoreSubModuleId;
}

export interface ActivityLogEntry {
  id: string;
  actorUid: string;
  actorName: string;
  actorRole: UserRole;
  action: string;
  module: 'People' | 'Attendance' | 'Leave' | 'Payroll' | 'Considerations' | 'Policies' | 'Documents' | 'Letters' | 'Settings' | string;
  targetRecord: string;
  targetEmployeeId?: string;
  previousValue: string;
  newValue: string;
  timestamp: string;
  ipDevice: string;
}
